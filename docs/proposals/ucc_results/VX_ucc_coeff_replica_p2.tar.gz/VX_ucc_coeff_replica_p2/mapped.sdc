# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Fri Nov 06 13:46:20 PST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design VX_ucc_coeff_replica_p2

create_clock -name "virtual_clock" -period 5.0 -waveform {0.0 2.5} 
set_load -pin_load 0.005 [get_ports {coefficients[157]}]
set_load -pin_load 0.005 [get_ports {coefficients[156]}]
set_load -pin_load 0.005 [get_ports {coefficients[155]}]
set_load -pin_load 0.005 [get_ports {coefficients[154]}]
set_load -pin_load 0.005 [get_ports {coefficients[153]}]
set_load -pin_load 0.005 [get_ports {coefficients[152]}]
set_load -pin_load 0.005 [get_ports {coefficients[151]}]
set_load -pin_load 0.005 [get_ports {coefficients[150]}]
set_load -pin_load 0.005 [get_ports {coefficients[149]}]
set_load -pin_load 0.005 [get_ports {coefficients[148]}]
set_load -pin_load 0.005 [get_ports {coefficients[147]}]
set_load -pin_load 0.005 [get_ports {coefficients[146]}]
set_load -pin_load 0.005 [get_ports {coefficients[145]}]
set_load -pin_load 0.005 [get_ports {coefficients[144]}]
set_load -pin_load 0.005 [get_ports {coefficients[143]}]
set_load -pin_load 0.005 [get_ports {coefficients[142]}]
set_load -pin_load 0.005 [get_ports {coefficients[141]}]
set_load -pin_load 0.005 [get_ports {coefficients[140]}]
set_load -pin_load 0.005 [get_ports {coefficients[139]}]
set_load -pin_load 0.005 [get_ports {coefficients[138]}]
set_load -pin_load 0.005 [get_ports {coefficients[137]}]
set_load -pin_load 0.005 [get_ports {coefficients[136]}]
set_load -pin_load 0.005 [get_ports {coefficients[135]}]
set_load -pin_load 0.005 [get_ports {coefficients[134]}]
set_load -pin_load 0.005 [get_ports {coefficients[133]}]
set_load -pin_load 0.005 [get_ports {coefficients[132]}]
set_load -pin_load 0.005 [get_ports {coefficients[131]}]
set_load -pin_load 0.005 [get_ports {coefficients[130]}]
set_load -pin_load 0.005 [get_ports {coefficients[129]}]
set_load -pin_load 0.005 [get_ports {coefficients[128]}]
set_load -pin_load 0.005 [get_ports {coefficients[127]}]
set_load -pin_load 0.005 [get_ports {coefficients[126]}]
set_load -pin_load 0.005 [get_ports {coefficients[125]}]
set_load -pin_load 0.005 [get_ports {coefficients[124]}]
set_load -pin_load 0.005 [get_ports {coefficients[123]}]
set_load -pin_load 0.005 [get_ports {coefficients[122]}]
set_load -pin_load 0.005 [get_ports {coefficients[121]}]
set_load -pin_load 0.005 [get_ports {coefficients[120]}]
set_load -pin_load 0.005 [get_ports {coefficients[119]}]
set_load -pin_load 0.005 [get_ports {coefficients[118]}]
set_load -pin_load 0.005 [get_ports {coefficients[117]}]
set_load -pin_load 0.005 [get_ports {coefficients[116]}]
set_load -pin_load 0.005 [get_ports {coefficients[115]}]
set_load -pin_load 0.005 [get_ports {coefficients[114]}]
set_load -pin_load 0.005 [get_ports {coefficients[113]}]
set_load -pin_load 0.005 [get_ports {coefficients[112]}]
set_load -pin_load 0.005 [get_ports {coefficients[111]}]
set_load -pin_load 0.005 [get_ports {coefficients[110]}]
set_load -pin_load 0.005 [get_ports {coefficients[109]}]
set_load -pin_load 0.005 [get_ports {coefficients[108]}]
set_load -pin_load 0.005 [get_ports {coefficients[107]}]
set_load -pin_load 0.005 [get_ports {coefficients[106]}]
set_load -pin_load 0.005 [get_ports {coefficients[105]}]
set_load -pin_load 0.005 [get_ports {coefficients[104]}]
set_load -pin_load 0.005 [get_ports {coefficients[103]}]
set_load -pin_load 0.005 [get_ports {coefficients[102]}]
set_load -pin_load 0.005 [get_ports {coefficients[101]}]
set_load -pin_load 0.005 [get_ports {coefficients[100]}]
set_load -pin_load 0.005 [get_ports {coefficients[99]}]
set_load -pin_load 0.005 [get_ports {coefficients[98]}]
set_load -pin_load 0.005 [get_ports {coefficients[97]}]
set_load -pin_load 0.005 [get_ports {coefficients[96]}]
set_load -pin_load 0.005 [get_ports {coefficients[95]}]
set_load -pin_load 0.005 [get_ports {coefficients[94]}]
set_load -pin_load 0.005 [get_ports {coefficients[93]}]
set_load -pin_load 0.005 [get_ports {coefficients[92]}]
set_load -pin_load 0.005 [get_ports {coefficients[91]}]
set_load -pin_load 0.005 [get_ports {coefficients[90]}]
set_load -pin_load 0.005 [get_ports {coefficients[89]}]
set_load -pin_load 0.005 [get_ports {coefficients[88]}]
set_load -pin_load 0.005 [get_ports {coefficients[87]}]
set_load -pin_load 0.005 [get_ports {coefficients[86]}]
set_load -pin_load 0.005 [get_ports {coefficients[85]}]
set_load -pin_load 0.005 [get_ports {coefficients[84]}]
set_load -pin_load 0.005 [get_ports {coefficients[83]}]
set_load -pin_load 0.005 [get_ports {coefficients[82]}]
set_load -pin_load 0.005 [get_ports {coefficients[81]}]
set_load -pin_load 0.005 [get_ports {coefficients[80]}]
set_load -pin_load 0.005 [get_ports {coefficients[79]}]
set_load -pin_load 0.005 [get_ports {coefficients[78]}]
set_load -pin_load 0.005 [get_ports {coefficients[77]}]
set_load -pin_load 0.005 [get_ports {coefficients[76]}]
set_load -pin_load 0.005 [get_ports {coefficients[75]}]
set_load -pin_load 0.005 [get_ports {coefficients[74]}]
set_load -pin_load 0.005 [get_ports {coefficients[73]}]
set_load -pin_load 0.005 [get_ports {coefficients[72]}]
set_load -pin_load 0.005 [get_ports {coefficients[71]}]
set_load -pin_load 0.005 [get_ports {coefficients[70]}]
set_load -pin_load 0.005 [get_ports {coefficients[69]}]
set_load -pin_load 0.005 [get_ports {coefficients[68]}]
set_load -pin_load 0.005 [get_ports {coefficients[67]}]
set_load -pin_load 0.005 [get_ports {coefficients[66]}]
set_load -pin_load 0.005 [get_ports {coefficients[65]}]
set_load -pin_load 0.005 [get_ports {coefficients[64]}]
set_load -pin_load 0.005 [get_ports {coefficients[63]}]
set_load -pin_load 0.005 [get_ports {coefficients[62]}]
set_load -pin_load 0.005 [get_ports {coefficients[61]}]
set_load -pin_load 0.005 [get_ports {coefficients[60]}]
set_load -pin_load 0.005 [get_ports {coefficients[59]}]
set_load -pin_load 0.005 [get_ports {coefficients[58]}]
set_load -pin_load 0.005 [get_ports {coefficients[57]}]
set_load -pin_load 0.005 [get_ports {coefficients[56]}]
set_load -pin_load 0.005 [get_ports {coefficients[55]}]
set_load -pin_load 0.005 [get_ports {coefficients[54]}]
set_load -pin_load 0.005 [get_ports {coefficients[53]}]
set_load -pin_load 0.005 [get_ports {coefficients[52]}]
set_load -pin_load 0.005 [get_ports {coefficients[51]}]
set_load -pin_load 0.005 [get_ports {coefficients[50]}]
set_load -pin_load 0.005 [get_ports {coefficients[49]}]
set_load -pin_load 0.005 [get_ports {coefficients[48]}]
set_load -pin_load 0.005 [get_ports {coefficients[47]}]
set_load -pin_load 0.005 [get_ports {coefficients[46]}]
set_load -pin_load 0.005 [get_ports {coefficients[45]}]
set_load -pin_load 0.005 [get_ports {coefficients[44]}]
set_load -pin_load 0.005 [get_ports {coefficients[43]}]
set_load -pin_load 0.005 [get_ports {coefficients[42]}]
set_load -pin_load 0.005 [get_ports {coefficients[41]}]
set_load -pin_load 0.005 [get_ports {coefficients[40]}]
set_load -pin_load 0.005 [get_ports {coefficients[39]}]
set_load -pin_load 0.005 [get_ports {coefficients[38]}]
set_load -pin_load 0.005 [get_ports {coefficients[37]}]
set_load -pin_load 0.005 [get_ports {coefficients[36]}]
set_load -pin_load 0.005 [get_ports {coefficients[35]}]
set_load -pin_load 0.005 [get_ports {coefficients[34]}]
set_load -pin_load 0.005 [get_ports {coefficients[33]}]
set_load -pin_load 0.005 [get_ports {coefficients[32]}]
set_load -pin_load 0.005 [get_ports {coefficients[31]}]
set_load -pin_load 0.005 [get_ports {coefficients[30]}]
set_load -pin_load 0.005 [get_ports {coefficients[29]}]
set_load -pin_load 0.005 [get_ports {coefficients[28]}]
set_load -pin_load 0.005 [get_ports {coefficients[27]}]
set_load -pin_load 0.005 [get_ports {coefficients[26]}]
set_load -pin_load 0.005 [get_ports {coefficients[25]}]
set_load -pin_load 0.005 [get_ports {coefficients[24]}]
set_load -pin_load 0.005 [get_ports {coefficients[23]}]
set_load -pin_load 0.005 [get_ports {coefficients[22]}]
set_load -pin_load 0.005 [get_ports {coefficients[21]}]
set_load -pin_load 0.005 [get_ports {coefficients[20]}]
set_load -pin_load 0.005 [get_ports {coefficients[19]}]
set_load -pin_load 0.005 [get_ports {coefficients[18]}]
set_load -pin_load 0.005 [get_ports {coefficients[17]}]
set_load -pin_load 0.005 [get_ports {coefficients[16]}]
set_load -pin_load 0.005 [get_ports {coefficients[15]}]
set_load -pin_load 0.005 [get_ports {coefficients[14]}]
set_load -pin_load 0.005 [get_ports {coefficients[13]}]
set_load -pin_load 0.005 [get_ports {coefficients[12]}]
set_load -pin_load 0.005 [get_ports {coefficients[11]}]
set_load -pin_load 0.005 [get_ports {coefficients[10]}]
set_load -pin_load 0.005 [get_ports {coefficients[9]}]
set_load -pin_load 0.005 [get_ports {coefficients[8]}]
set_load -pin_load 0.005 [get_ports {coefficients[7]}]
set_load -pin_load 0.005 [get_ports {coefficients[6]}]
set_load -pin_load 0.005 [get_ports {coefficients[5]}]
set_load -pin_load 0.005 [get_ports {coefficients[4]}]
set_load -pin_load 0.005 [get_ports {coefficients[3]}]
set_load -pin_load 0.005 [get_ports {coefficients[2]}]
set_load -pin_load 0.005 [get_ports {coefficients[1]}]
set_load -pin_load 0.005 [get_ports {coefficients[0]}]
set_max_delay 5 -from [list \
  [get_ports {indices[11]}]  \
  [get_ports {indices[10]}]  \
  [get_ports {indices[9]}]  \
  [get_ports {indices[8]}]  \
  [get_ports {indices[7]}]  \
  [get_ports {indices[6]}]  \
  [get_ports {indices[5]}]  \
  [get_ports {indices[4]}]  \
  [get_ports {indices[3]}]  \
  [get_ports {indices[2]}]  \
  [get_ports {indices[1]}]  \
  [get_ports {indices[0]}] ] -to [list \
  [get_ports {coefficients[157]}]  \
  [get_ports {coefficients[156]}]  \
  [get_ports {coefficients[155]}]  \
  [get_ports {coefficients[154]}]  \
  [get_ports {coefficients[153]}]  \
  [get_ports {coefficients[152]}]  \
  [get_ports {coefficients[151]}]  \
  [get_ports {coefficients[150]}]  \
  [get_ports {coefficients[149]}]  \
  [get_ports {coefficients[148]}]  \
  [get_ports {coefficients[147]}]  \
  [get_ports {coefficients[146]}]  \
  [get_ports {coefficients[145]}]  \
  [get_ports {coefficients[144]}]  \
  [get_ports {coefficients[143]}]  \
  [get_ports {coefficients[142]}]  \
  [get_ports {coefficients[141]}]  \
  [get_ports {coefficients[140]}]  \
  [get_ports {coefficients[139]}]  \
  [get_ports {coefficients[138]}]  \
  [get_ports {coefficients[137]}]  \
  [get_ports {coefficients[136]}]  \
  [get_ports {coefficients[135]}]  \
  [get_ports {coefficients[134]}]  \
  [get_ports {coefficients[133]}]  \
  [get_ports {coefficients[132]}]  \
  [get_ports {coefficients[131]}]  \
  [get_ports {coefficients[130]}]  \
  [get_ports {coefficients[129]}]  \
  [get_ports {coefficients[128]}]  \
  [get_ports {coefficients[127]}]  \
  [get_ports {coefficients[126]}]  \
  [get_ports {coefficients[125]}]  \
  [get_ports {coefficients[124]}]  \
  [get_ports {coefficients[123]}]  \
  [get_ports {coefficients[122]}]  \
  [get_ports {coefficients[121]}]  \
  [get_ports {coefficients[120]}]  \
  [get_ports {coefficients[119]}]  \
  [get_ports {coefficients[118]}]  \
  [get_ports {coefficients[117]}]  \
  [get_ports {coefficients[116]}]  \
  [get_ports {coefficients[115]}]  \
  [get_ports {coefficients[114]}]  \
  [get_ports {coefficients[113]}]  \
  [get_ports {coefficients[112]}]  \
  [get_ports {coefficients[111]}]  \
  [get_ports {coefficients[110]}]  \
  [get_ports {coefficients[109]}]  \
  [get_ports {coefficients[108]}]  \
  [get_ports {coefficients[107]}]  \
  [get_ports {coefficients[106]}]  \
  [get_ports {coefficients[105]}]  \
  [get_ports {coefficients[104]}]  \
  [get_ports {coefficients[103]}]  \
  [get_ports {coefficients[102]}]  \
  [get_ports {coefficients[101]}]  \
  [get_ports {coefficients[100]}]  \
  [get_ports {coefficients[99]}]  \
  [get_ports {coefficients[98]}]  \
  [get_ports {coefficients[97]}]  \
  [get_ports {coefficients[96]}]  \
  [get_ports {coefficients[95]}]  \
  [get_ports {coefficients[94]}]  \
  [get_ports {coefficients[93]}]  \
  [get_ports {coefficients[92]}]  \
  [get_ports {coefficients[91]}]  \
  [get_ports {coefficients[90]}]  \
  [get_ports {coefficients[89]}]  \
  [get_ports {coefficients[88]}]  \
  [get_ports {coefficients[87]}]  \
  [get_ports {coefficients[86]}]  \
  [get_ports {coefficients[85]}]  \
  [get_ports {coefficients[84]}]  \
  [get_ports {coefficients[83]}]  \
  [get_ports {coefficients[82]}]  \
  [get_ports {coefficients[81]}]  \
  [get_ports {coefficients[80]}]  \
  [get_ports {coefficients[79]}]  \
  [get_ports {coefficients[78]}]  \
  [get_ports {coefficients[77]}]  \
  [get_ports {coefficients[76]}]  \
  [get_ports {coefficients[75]}]  \
  [get_ports {coefficients[74]}]  \
  [get_ports {coefficients[73]}]  \
  [get_ports {coefficients[72]}]  \
  [get_ports {coefficients[71]}]  \
  [get_ports {coefficients[70]}]  \
  [get_ports {coefficients[69]}]  \
  [get_ports {coefficients[68]}]  \
  [get_ports {coefficients[67]}]  \
  [get_ports {coefficients[66]}]  \
  [get_ports {coefficients[65]}]  \
  [get_ports {coefficients[64]}]  \
  [get_ports {coefficients[63]}]  \
  [get_ports {coefficients[62]}]  \
  [get_ports {coefficients[61]}]  \
  [get_ports {coefficients[60]}]  \
  [get_ports {coefficients[59]}]  \
  [get_ports {coefficients[58]}]  \
  [get_ports {coefficients[57]}]  \
  [get_ports {coefficients[56]}]  \
  [get_ports {coefficients[55]}]  \
  [get_ports {coefficients[54]}]  \
  [get_ports {coefficients[53]}]  \
  [get_ports {coefficients[52]}]  \
  [get_ports {coefficients[51]}]  \
  [get_ports {coefficients[50]}]  \
  [get_ports {coefficients[49]}]  \
  [get_ports {coefficients[48]}]  \
  [get_ports {coefficients[47]}]  \
  [get_ports {coefficients[46]}]  \
  [get_ports {coefficients[45]}]  \
  [get_ports {coefficients[44]}]  \
  [get_ports {coefficients[43]}]  \
  [get_ports {coefficients[42]}]  \
  [get_ports {coefficients[41]}]  \
  [get_ports {coefficients[40]}]  \
  [get_ports {coefficients[39]}]  \
  [get_ports {coefficients[38]}]  \
  [get_ports {coefficients[37]}]  \
  [get_ports {coefficients[36]}]  \
  [get_ports {coefficients[35]}]  \
  [get_ports {coefficients[34]}]  \
  [get_ports {coefficients[33]}]  \
  [get_ports {coefficients[32]}]  \
  [get_ports {coefficients[31]}]  \
  [get_ports {coefficients[30]}]  \
  [get_ports {coefficients[29]}]  \
  [get_ports {coefficients[28]}]  \
  [get_ports {coefficients[27]}]  \
  [get_ports {coefficients[26]}]  \
  [get_ports {coefficients[25]}]  \
  [get_ports {coefficients[24]}]  \
  [get_ports {coefficients[23]}]  \
  [get_ports {coefficients[22]}]  \
  [get_ports {coefficients[21]}]  \
  [get_ports {coefficients[20]}]  \
  [get_ports {coefficients[19]}]  \
  [get_ports {coefficients[18]}]  \
  [get_ports {coefficients[17]}]  \
  [get_ports {coefficients[16]}]  \
  [get_ports {coefficients[15]}]  \
  [get_ports {coefficients[14]}]  \
  [get_ports {coefficients[13]}]  \
  [get_ports {coefficients[12]}]  \
  [get_ports {coefficients[11]}]  \
  [get_ports {coefficients[10]}]  \
  [get_ports {coefficients[9]}]  \
  [get_ports {coefficients[8]}]  \
  [get_ports {coefficients[7]}]  \
  [get_ports {coefficients[6]}]  \
  [get_ports {coefficients[5]}]  \
  [get_ports {coefficients[4]}]  \
  [get_ports {coefficients[3]}]  \
  [get_ports {coefficients[2]}]  \
  [get_ports {coefficients[1]}]  \
  [get_ports {coefficients[0]}] ]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[11]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[10]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[9]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[8]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[7]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[6]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[5]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[4]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[3]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[2]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[1]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[0]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[157]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[156]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[155]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[154]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[153]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[152]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[151]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[150]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[149]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[148]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[147]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[146]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[145]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[144]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[143]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[142]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[141]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[140]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[139]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[138]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[137]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[136]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[135]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[134]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[133]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[132]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[131]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[130]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[129]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[128]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[127]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[126]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[125]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[124]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[123]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[122]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[121]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[120]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[119]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[118]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[117]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[116]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[115]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[114]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[113]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[112]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[111]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[110]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[109]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[108]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[107]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[106]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[105]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[104]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[103]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[102]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[101]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[100]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[99]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[98]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[97]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[96]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[95]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[94]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[93]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[92]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[91]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[90]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[89]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[88]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[87]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[86]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[85]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[84]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[83]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[82]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[81]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[80]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[79]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[78]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[77]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[76]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[75]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[74]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[73]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[72]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[71]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[70]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[69]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[68]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[67]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[66]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[65]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[64]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[63]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[62]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[61]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[60]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[59]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[58]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[57]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[56]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[55]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[54]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[53]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[52]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[51]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[50]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[49]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[48]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[47]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[46]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[45]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[44]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[43]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[42]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[41]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[40]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[39]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[38]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[37]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[36]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[35]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[34]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[33]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[32]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[31]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[30]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[29]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[28]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[27]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[26]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[25]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[24]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[23]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[22]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[21]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[20]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[19]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[18]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[17]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[16]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[15]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[14]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[13]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[12]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[11]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[10]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[9]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[8]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[7]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[6]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[5]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[4]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[3]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[2]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[1]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[0]}]
set_input_transition 0.05 [get_ports {indices[11]}]
set_input_transition 0.05 [get_ports {indices[10]}]
set_input_transition 0.05 [get_ports {indices[9]}]
set_input_transition 0.05 [get_ports {indices[8]}]
set_input_transition 0.05 [get_ports {indices[7]}]
set_input_transition 0.05 [get_ports {indices[6]}]
set_input_transition 0.05 [get_ports {indices[5]}]
set_input_transition 0.05 [get_ports {indices[4]}]
set_input_transition 0.05 [get_ports {indices[3]}]
set_input_transition 0.05 [get_ports {indices[2]}]
set_input_transition 0.05 [get_ports {indices[1]}]
set_input_transition 0.05 [get_ports {indices[0]}]
set_wire_load_mode "segmented"
