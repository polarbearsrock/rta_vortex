package VX_gpu_pkg;
    localparam NC_BITS = $clog2(1);
    localparam NW_BITS = $clog2(4);
    localparam NT_BITS = $clog2(64);
    localparam NB_BITS = $clog2(8);
    localparam NC_WIDTH = (((NC_BITS) > 0) ? (NC_BITS) : 1);
    localparam NW_WIDTH = (((NW_BITS) > 0) ? (NW_BITS) : 1);
    localparam NT_WIDTH = (((NT_BITS) > 0) ? (NT_BITS) : 1);
    localparam NB_WIDTH = (((NB_BITS) > 0) ? (NB_BITS) : 1);
    localparam NUM_CTA_MAX = 4;
    localparam NCTA_BITS  = $clog2(NUM_CTA_MAX);
    localparam NCTA_WIDTH = (((NCTA_BITS) > 0) ? (NCTA_BITS) : 1);
    localparam XLENB    = 32 / 8;
    localparam XLENB_W  = $clog2(XLENB);
    localparam BYTESEL_BITS = (XLENB_W + XLENB_W);
    localparam [BYTESEL_BITS-1:0] BYTESEL_DEFAULT = {XLENB_W'(XLENB-1), XLENB_W'(0)};
    localparam RV_REGS = 32;
    localparam RV_REGS_BITS = 5;
    localparam RV_RD  = 0;
    localparam RV_RS1 = 1;
    localparam RV_RS2 = 2;
    localparam RV_RS3 = 3;
    localparam REG_TYPE_I = 0;
    localparam REG_TYPE_F = 1;
    localparam REG_TYPES = 1 + 1;
    localparam NUM_REGS = (REG_TYPES * RV_REGS);
    localparam REG_TYPE_BITS = (((REG_TYPES) > 1) ? $clog2(REG_TYPES) : 1);
    localparam NUM_REGS_BITS = $clog2(NUM_REGS);
    localparam XREG_0      = 0;
    localparam XREG_1      = 1;
    localparam NUM_XREGS   = 2;
    localparam DV_STACK_SIZE = (((64-1) > 0) ? (64-1) : 1);
    localparam DV_STACK_SIZEW = (((DV_STACK_SIZE) > 1) ? $clog2(DV_STACK_SIZE) : 1);
    localparam PERF_CTR_BITS = 44;
    localparam SIMD_COUNT = 64 / 64;
    localparam SIMD_IDX_BITS = $clog2(SIMD_COUNT);
    localparam SIMD_IDX_W = (((SIMD_IDX_BITS) > 0) ? (SIMD_IDX_BITS) : 1);
    localparam NUM_OPCS_BITS = $clog2(1);
    localparam NUM_OPCS_W = (((NUM_OPCS_BITS) > 0) ? (NUM_OPCS_BITS) : 1);
    localparam BAR_ADDR_BITS = NW_BITS + NB_BITS;
    localparam BAR_ADDR_W = (((BAR_ADDR_BITS) > 0) ? (BAR_ADDR_BITS) : 1);
    localparam BAR_ID_SHIFT = 8;
    localparam BAR_SIZE_W = ((((((NW_WIDTH) > (NC_WIDTH)) ? (NW_WIDTH) : (NC_WIDTH))) > ($clog2(32))) ? ((((NW_WIDTH) > (NC_WIDTH)) ? (NW_WIDTH) : (NC_WIDTH))) : ($clog2(32)));
    localparam UOP_PACKLD = 0;
    localparam UOP_TCU = UOP_PACKLD + 1;
    localparam UOP_GFX = UOP_TCU + 1;
    localparam UOP_MAX = UOP_GFX + 0;
    localparam UOP_CTR_W = 8;
    localparam CTA_TID_WIDTH = (((NW_BITS + NT_BITS) > 0) ? (NW_BITS + NT_BITS) : 1);
    localparam UUID_WIDTH = 44;
    localparam PC_BITS = 32;
    function automatic logic [32-1:0] to_fullPC(input logic[PC_BITS-1:0] pc);
        to_fullPC = 32'(pc);
    endfunction
    function automatic logic [PC_BITS-1:0] from_fullPC(input logic[32-1:0] pc);
        from_fullPC = pc;
    endfunction
    localparam NUM_SRC_OPDS = 3;
    localparam SRC_OPD_BITS = $clog2(NUM_SRC_OPDS);
    localparam SRC_OPD_WIDTH = (((SRC_OPD_BITS) > 0) ? (SRC_OPD_BITS) : 1);
    localparam NUM_SOCKETS = (((1 / 1) > 0) ? (1 / 1) : 1);
    localparam NUM_STACKS = 1 * NUM_SOCKETS * 1 * 4 * 64;
    localparam [32-1:0] STACK_WINDOW_TOP    = 32'(32'hFFFF0000);
    localparam [32-1:0] STACK_WINDOW_SPAN   = 32'(NUM_STACKS) << 13;
    localparam [32-1:0] STACK_WINDOW_BOTTOM = STACK_WINDOW_TOP - STACK_WINDOW_SPAN;
    localparam HART_ID_BITS = NC_BITS + NW_BITS + NT_BITS;
    localparam HART_ID_WIDTH = (((HART_ID_BITS) > 0) ? (HART_ID_BITS) : 1);
    typedef enum logic [3:0] {
        AMO_OP_LR    = 4'h0,
        AMO_OP_SC    = 4'h1,
        AMO_OP_ADD   = 4'h2,
        AMO_OP_SWAP  = 4'h3,
        AMO_OP_XOR   = 4'h4,
        AMO_OP_OR    = 4'h5,
        AMO_OP_AND   = 4'h6,
        AMO_OP_MIN   = 4'h7,
        AMO_OP_MAX   = 4'h8,
        AMO_OP_CAS   = 4'h9
    } amo_op_e;
    typedef struct packed {
        logic [HART_ID_WIDTH-1:0]   hart_id;
        logic                        amo_unsigned;
        amo_op_e                     amo_op;
        logic                        amo_valid;
    } amo_req_t;
    localparam AMO_REQ_BITS = $bits(amo_req_t);
    typedef struct packed {
        amo_req_t                    amo;            
        logic                        is_addr_om;     
        logic                        is_addr_local;  
        logic                        is_addr_io;     
        logic                        is_flush;       
    } mem_bus_attr_t;
    localparam MEM_ATTR_FLUSH_OFFS  = 0;
    localparam MEM_ATTR_IO_OFFS     = 1;
    localparam MEM_ATTR_LOCAL_OFFS  = 2;
    localparam MEM_ATTR_OM_OFFS     = 3;
    localparam MEM_ATTR_AMO_OFFS    = 4;
    localparam MEM_ATTR_WIDTH = $bits(mem_bus_attr_t);
    localparam VX_DCR_ADDR_WIDTH = 12;
    localparam VX_DCR_DATA_WIDTH = 32;
    localparam STALL_TIMEOUT = 100000;
    localparam EX_ALU = 0;
    localparam EX_LSU = 1;
    localparam EX_SFU = 2;
    localparam EX_FPU = (EX_SFU + 1);
    localparam EX_TCU = (EX_FPU + 1);
    localparam NUM_EX_UNITS = EX_TCU + 1;
    localparam EX_BITS = $clog2(NUM_EX_UNITS);
    localparam EX_WIDTH = (((EX_BITS) > 0) ? (EX_BITS) : 1);
    localparam SFU_BITS = $clog2(2);
    localparam SFU_WIDTH = (((SFU_BITS) > 0) ? (SFU_BITS) : 1);
    localparam SFU_CSRS = 0;
    localparam SFU_WCTL = 1;
    localparam NUM_SFU_UNITS = (2);
    localparam INST_LUI =        7'b0110111;
    localparam INST_AUIPC =      7'b0010111;
    localparam INST_JAL =        7'b1101111;
    localparam INST_JALR =       7'b1100111;
    localparam INST_B =          7'b1100011;  
    localparam INST_L =          7'b0000011;  
    localparam INST_S =          7'b0100011;  
    localparam INST_I =          7'b0010011;  
    localparam INST_R =          7'b0110011;  
    localparam INST_V =          7'b1010111;  
    localparam INST_FENCE =      7'b0001111;  
    localparam INST_AMO =        7'b0101111;  
    localparam INST_SYS =        7'b1110011;  
    localparam INST_I_W =        7'b0011011;  
    localparam INST_R_W =        7'b0111011;  
    localparam INST_FL =         7'b0000111;  
    localparam INST_FS =         7'b0100111;  
    localparam INST_FMADD =      7'b1000011;
    localparam INST_FMSUB =      7'b1000111;
    localparam INST_FNMSUB =     7'b1001011;
    localparam INST_FNMADD =     7'b1001111;
    localparam INST_FCI =        7'b1010011;  
    localparam INST_EXT1 =       7'b0001011;  
    localparam INST_EXT2 =       7'b0101011;  
    localparam INST_EXT3 =       7'b1011011;  
    localparam INST_EXT4 =       7'b1111011;  
    localparam INST_R_F7_MUL =   7'b0000001;
    localparam INST_R_F7_ZICOND= 7'b0000111;
    localparam INST_FRM_RNE =    3'b000;   
    localparam INST_FRM_RTZ =    3'b001;   
    localparam INST_FRM_RDN =    3'b010;   
    localparam INST_FRM_RUP =    3'b011;   
    localparam INST_FRM_RMM =    3'b100;   
    localparam INST_FRM_DYN =    3'b111;   
    localparam INST_FRM_BITS =   3;
    localparam INST_OP_BITS =    4;
    localparam INST_FMT_BITS =   2;
    localparam INST_ALU_ADD =    4'b0000;
    localparam INST_ALU_LUI =    4'b0010;
    localparam INST_ALU_AUIPC =  4'b0011;
    localparam INST_ALU_SLTU =   4'b0100;
    localparam INST_ALU_SLT =    4'b0101;
    localparam INST_ALU_SUB =    4'b0111;
    localparam INST_ALU_SRL =    4'b1000;
    localparam INST_ALU_SRA =    4'b1001;
    localparam INST_ALU_CZEQ =   4'b1010;
    localparam INST_ALU_CZNE =   4'b1011;
    localparam INST_ALU_AND =    4'b1100;
    localparam INST_ALU_OR =     4'b1101;
    localparam INST_ALU_XOR =    4'b1110;
    localparam INST_ALU_SLL =    4'b1111;
    localparam INST_ALU_BITS =   4;
    localparam ALU_TYPE_BITS =   2;
    localparam ALU_TYPE_ARITH =  0;
    localparam ALU_TYPE_BRANCH = 1;
    localparam ALU_TYPE_MULDIV = 2;
    localparam ALU_TYPE_OTHER =  3;
    function automatic logic [1:0] inst_alu_class(input logic [INST_ALU_BITS-1:0] op);
        return op[3:2];
    endfunction
    function automatic logic inst_alu_signed(input logic [INST_ALU_BITS-1:0] op);
        return op[0];
    endfunction
    function automatic logic inst_alu_is_sub(input logic [INST_ALU_BITS-1:0] op);
        return op[1];
    endfunction
    function automatic logic inst_alu_is_czero(input logic [INST_ALU_BITS-1:0] op);
        return (op[3:1] == 3'b101);
    endfunction
    localparam INST_BR_BEQ =     4'b0000;
    localparam INST_BR_BNE =     4'b0010;
    localparam INST_BR_BLTU =    4'b0100;
    localparam INST_BR_BGEU =    4'b0110;
    localparam INST_BR_BLT =     4'b0101;
    localparam INST_BR_BGE =     4'b0111;
    localparam INST_BR_JAL =     4'b1000;
    localparam INST_BR_JALR =    4'b1001;
    localparam INST_BR_ECALL =   4'b1010;
    localparam INST_BR_EBREAK =  4'b1011;
    localparam INST_BR_URET =    4'b1100;
    localparam INST_BR_SRET =    4'b1101;
    localparam INST_BR_MRET =    4'b1110;
    localparam INST_BR_OTHER =   4'b1111;
    localparam INST_BR_BITS =    4;
    function automatic logic [1:0] inst_br_class(input logic [INST_BR_BITS-1:0] op);
        return {1'b0, ~op[3]};
    endfunction
    function automatic logic inst_br_is_neg(input logic [INST_BR_BITS-1:0] op);
        return op[1];
    endfunction
    function automatic logic inst_br_is_less(input logic [INST_BR_BITS-1:0] op);
        return op[2];
    endfunction
    function automatic logic inst_br_is_static(input logic [INST_BR_BITS-1:0] op);
        return op[3];
    endfunction
    localparam INST_VOTE_ALL =   2'b00;
    localparam INST_VOTE_ANY =   2'b01;
    localparam INST_VOTE_UNI =   2'b10;
    localparam INST_VOTE_BAL =   2'b11;
    localparam INST_SHFL_UP =    2'b00;
    localparam INST_SHFL_DOWN =  2'b01;
    localparam INST_SHFL_BFLY =  2'b10;
    localparam INST_SHFL_IDX =   2'b11;
    localparam INST_VOTE_BITS =  2;
    localparam INST_SHFL_BITS =  2;
    localparam INST_WGATHER =    4'h8;  
    localparam INST_M_MUL =      3'b000;
    localparam INST_M_MULHU =    3'b001;
    localparam INST_M_MULH =     3'b010;
    localparam INST_M_MULHSU =   3'b011;
    localparam INST_M_DIV =      3'b100;
    localparam INST_M_DIVU =     3'b101;
    localparam INST_M_REM =      3'b110;
    localparam INST_M_REMU =     3'b111;
    localparam INST_M_BITS =     3;
    function automatic logic inst_m_signed(input logic [INST_M_BITS-1:0] op);
        return (~op[0]);
    endfunction
    function automatic logic inst_m_is_mulx(input logic [INST_M_BITS-1:0] op);
        return (~op[2]);
    endfunction
    function automatic logic inst_m_is_mulh(input logic [INST_M_BITS-1:0] op);
        return (op[1:0] != 0);
    endfunction
    function automatic logic inst_m_signed_a(input logic [INST_M_BITS-1:0] op);
        return (op[1:0] != 1);
    endfunction
    function automatic logic inst_m_is_rem(input logic [INST_M_BITS-1:0] op);
        return op[1];
    endfunction
    localparam LSU_FMT_B =       3'b000;
    localparam LSU_FMT_H =       3'b001;
    localparam LSU_FMT_W =       3'b010;
    localparam LSU_FMT_D =       3'b011;
    localparam LSU_FMT_BU =      3'b100;
    localparam LSU_FMT_HU =      3'b101;
    localparam LSU_FMT_WU =      3'b110;
    localparam INST_LSU_LB =     4'b0000;
    localparam INST_LSU_LH =     4'b0001;
    localparam INST_LSU_LW =     4'b0010;
    localparam INST_LSU_LD =     4'b0011;  
    localparam INST_LSU_LBU =    4'b0100;
    localparam INST_LSU_LHU =    4'b0101;
    localparam INST_LSU_LWU =    4'b0110;  
    localparam INST_LSU_SB =     4'b1000;
    localparam INST_LSU_SH =     4'b1001;
    localparam INST_LSU_SW =     4'b1010;
    localparam INST_LSU_SD =     4'b1011;  
    localparam INST_LSU_FENCE =  4'b1111;
    localparam INST_LSU_BITS =   4;
    localparam INST_FENCE_BITS = 1;
    localparam INST_FENCE_D =    1'h0;
    localparam INST_FENCE_I =    1'h1;
    function automatic logic [2:0] inst_lsu_fmt(input logic [INST_LSU_BITS-1:0] op);
        return op[2:0];
    endfunction
    function automatic logic [1:0] inst_lsu_wsize(input logic [INST_LSU_BITS-1:0] op);
        return op[1:0];
    endfunction
    function automatic logic inst_lsu_is_fence(input logic [INST_LSU_BITS-1:0] op);
        return (op == INST_LSU_FENCE);
    endfunction
    localparam INST_FPU_ADD =    4'b0000;  
    localparam INST_FPU_MUL =    4'b0001;
    localparam INST_FPU_MADD =   4'b0010;  
    localparam INST_FPU_NMADD =  4'b0011;  
    localparam INST_FPU_DIV =    4'b0100;
    localparam INST_FPU_SQRT =   4'b0101;
    localparam INST_FPU_F2I =    4'b1000;  
    localparam INST_FPU_F2U =    4'b1001;  
    localparam INST_FPU_I2F =    4'b1010;  
    localparam INST_FPU_U2F =    4'b1011;  
    localparam INST_FPU_CMP =    4'b1100;  
    localparam INST_FPU_F2F =    4'b1101;  
    localparam INST_FPU_MISC =   4'b1110;  
    localparam INST_FPU_F2H =    4'b1111;
    localparam INST_FPU_BITS =   4;
    function automatic logic inst_fpu_is_class(input logic [INST_FPU_BITS-1:0] op, input logic [INST_FRM_BITS-1:0] frm);
        return (op == INST_FPU_MISC && frm == 3);
    endfunction
    function automatic logic inst_fpu_is_mvxw(input logic [INST_FPU_BITS-1:0] op, input logic [INST_FRM_BITS-1:0] frm);
        return (op == INST_FPU_MISC && frm == 4);
    endfunction
    localparam INST_SFU_TMC =    4'h0;
    localparam INST_SFU_WSPAWN = 4'h1;
    localparam INST_SFU_SPLIT =  4'h2;
    localparam INST_SFU_JOIN =   4'h3;
    localparam INST_SFU_BAR =    4'h4;
    localparam INST_SFU_PRED =   4'h5;
    localparam INST_SFU_CSRRW =  4'h6;
    localparam INST_SFU_CSRRS =  4'h7;
    localparam INST_SFU_CSRRC =  4'h8;
    localparam INST_SFU_WSYNC =  4'hA;
    localparam INST_SFU_BITS =   4;
    function automatic logic [3:0] inst_sfu_csr(input logic [2:0] funct3);
        return (4'h6 + 4'(funct3[1:0]) - 4'h1);
    endfunction
    function automatic logic inst_sfu_is_wctl(input logic [INST_SFU_BITS-1:0] op);
        return (op == INST_SFU_TMC)
            || (op == INST_SFU_WSPAWN)
            || (op == INST_SFU_SPLIT)
            || (op == INST_SFU_JOIN)
            || (op == INST_SFU_BAR)
            || (op == INST_SFU_PRED)
            || (op == INST_SFU_WSYNC);
    endfunction
    function automatic logic inst_sfu_is_csr(input logic [INST_SFU_BITS-1:0] op);
        return (op >= 6 && op <= 8);
    endfunction
    localparam ISSUE_ISW_BITS = $clog2(1);
    localparam ISSUE_ISW_SIZEW = $clog2(1 + 1);
    localparam ISSUE_ISW_W = (((ISSUE_ISW_BITS) > 0) ? (ISSUE_ISW_BITS) : 1);
    localparam PER_ISSUE_WARPS = 4 / 1;
    localparam ISSUE_WIS_BITS = $clog2(PER_ISSUE_WARPS);
    localparam ISSUE_WIS_W = (((ISSUE_WIS_BITS) > 0) ? (ISSUE_WIS_BITS) : 1);
    localparam NUM_TRAP_CSRS = 5;
    localparam DISPATCH_QSIZE = 4;
    localparam PER_OPC_WARPS = PER_ISSUE_WARPS / 1;
    localparam PER_OPC_NW_BITS = $clog2(PER_OPC_WARPS);
    localparam PER_OPC_NW_W = (((PER_OPC_NW_BITS) > 0) ? (PER_OPC_NW_BITS) : 1);
    function automatic logic [NW_WIDTH-1:0] wis_to_wid(
        input logic [ISSUE_WIS_W-1:0] wis,
        input logic [ISSUE_ISW_W-1:0] isw
    );
        if (ISSUE_WIS_BITS == 0) begin
            wis_to_wid = NW_WIDTH'(isw);
        end else if (ISSUE_ISW_BITS == 0) begin
            wis_to_wid = NW_WIDTH'(wis);
        end else begin
            wis_to_wid = NW_WIDTH'({wis, isw});
        end
    endfunction
    function automatic logic [ISSUE_ISW_W-1:0] wid_to_isw(
        input logic [NW_WIDTH-1:0] wid
    );
        if (ISSUE_ISW_BITS != 0) begin
            wid_to_isw = wid[ISSUE_ISW_W-1:0];
        end else begin
            wid_to_isw = 0;
        end
    endfunction
    function automatic logic [ISSUE_WIS_W-1:0] wid_to_wis(
        input logic [NW_WIDTH-1:0] wid
    );
        if (ISSUE_WIS_BITS != 0) begin
            wid_to_wis = ISSUE_WIS_W'(wid >> ISSUE_ISW_BITS);
        end else begin
            wid_to_wis = 0;
        end
    endfunction
    localparam INST_TCU_WMMA       = 4'h0;
    localparam INST_TCU_LD         = 4'h5;
    localparam INST_TCU_BITS = 4;
    typedef struct packed {
        logic [64-1:0] tmask;
    } tmc_t;
    typedef struct packed {
        logic [4-1:0]  wmask;
        logic [PC_BITS-1:0]     pc;
    } wspawn_t;
    typedef struct packed {
        logic                   is_dvg;
        logic [64-1:0] then_tmask;
        logic [64-1:0] else_tmask;
        logic [PC_BITS-1:0]     next_pc;
    } split_t;
    typedef struct packed {
        logic [64-1:0] tmask;
        logic [DV_STACK_SIZEW-1:0] stack_ptr;
    } join_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0]    id;
        logic                   is_event;
        logic                   is_global;
        logic                   is_arrive;
        logic                   is_sync;
        logic                   phase;
        logic [BAR_SIZE_W-1:0]  size_m1;
    } barrier_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0] id;
        logic [NC_WIDTH-1:0] size_m1;
        logic [NC_WIDTH-1:0] core_id;
    } gbar_req_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0] id;
    } gbar_rsp_t;
    typedef struct packed {
        logic [BAR_ADDR_W-1:0] addr;
        logic                  is_done;
    } txbar_t;
    typedef struct packed {
        logic                         rw;
        logic [VX_DCR_ADDR_WIDTH-1:0] addr;
        logic [VX_DCR_DATA_WIDTH-1:0] data;
    } dcr_req_t;
    typedef struct packed {
        logic [VX_DCR_DATA_WIDTH-1:0] data;
    } dcr_rsp_t;
    localparam FRAG_STAMP_BITS = 2 * (15 - 1) + 4 + 16;
    localparam FRAG_QUAD_LANES = 4;
    localparam FRAG_LANE_BITS  = FRAG_STAMP_BITS / FRAG_QUAD_LANES;
    localparam KMU_FRAG_BITS = 0;
    localparam KMU_FRAG_PAYLOAD_BITS = 0;
    localparam KMU_COMPUTE_BITS = 3*32                     
                                + 3*32                     
                                + 3*(CTA_TID_WIDTH+1)      
                                + (CTA_TID_WIDTH+1)        
                                + 3*CTA_TID_WIDTH          
                                + (NW_WIDTH+1)             
                                + 1;                       
    localparam KMU_ARGS_BITS = (((KMU_COMPUTE_BITS) > (KMU_FRAG_PAYLOAD_BITS)) ? (KMU_COMPUTE_BITS) : (KMU_FRAG_PAYLOAD_BITS)) + 1;
    typedef struct packed {
        logic [KMU_ARGS_BITS-KMU_COMPUTE_BITS-1:0] __padding;
        logic [2:0][31:0]              grid_dim;
        logic [2:0][31:0]              block_idx;
        logic [2:0][CTA_TID_WIDTH:0]   block_dim;
        logic [CTA_TID_WIDTH:0]        block_size;
        logic [2:0][CTA_TID_WIDTH-1:0] warp_step;
        logic [NW_WIDTH:0]             cluster_size;
        logic                          is_first_of_cluster;
    } kmu_compute_args_t;
    typedef union packed {
        kmu_compute_args_t  compute;
    } kmu_args_t;
    typedef struct packed {
        logic                              kind;    
        logic [PC_BITS-1:0]                PC;
        logic [PC_BITS-1:0]                entry;
        logic [32-1:0] param;
        logic [7:0]                        ctx_id;
        logic [17:0]    aligned_lmem_size;
        kmu_args_t                         args;    
    } kmu_req_t;
    localparam KMU_DATAW = $bits(kmu_req_t);
    localparam KMU_KIND_COMPUTE  = 1'b0;    
    localparam KMU_KIND_FRAGMENT = 1'b1;    
    localparam KMU_KIND_BITS     = 1;
    localparam KMU_DEST_W = ((($clog2(1 * 1)) > 0) ? ($clog2(1 * 1)) : 1);
    localparam KMU_DEST_LSB_SOCKET  = 0;
    localparam KMU_DEST_LSB_CLUSTER = $clog2(1);
    localparam KMU_DEST_LSB_DEVICE  = KMU_DEST_LSB_CLUSTER + $clog2(NUM_SOCKETS);
    typedef struct packed {
        logic [NCTA_WIDTH-1:0] cta_id;
        logic [NW_WIDTH-1:0] cta_rank;
        logic [NW_WIDTH:0] cta_size;
        logic [2:0][31:0] block_idx;
        logic [2:0][CTA_TID_WIDTH:0] block_dim;
        logic [2:0][31:0] grid_dim;
        logic [PC_BITS-1:0] entry;
        logic [32-1:0] param;
        logic [32-1:0] lmem_addr;
        logic [31:0] cluster_size;
    } cta_csrs_t;
    typedef struct packed {
        logic [NW_WIDTH:0]              cta_size;
        logic [2:0][31:0]               block_idx;
        logic [2:0][CTA_TID_WIDTH:0]    block_dim;
        logic [2:0][31:0]               grid_dim;
        logic [PC_BITS-1:0]             entry;
        logic [32-1:0] param;
        logic [32-1:0] lmem_addr;
        logic [31:0]                    cluster_size;
    } cta_ctx_t;
    localparam CTA_TID_LANE_BITS = 3 * CTA_TID_WIDTH;
    localparam LANE_LAUNCH_BITS = CTA_TID_LANE_BITS;
    typedef logic [LANE_LAUNCH_BITS-1:0] cta_lane_t;
    typedef struct packed {
        logic [NW_WIDTH-1:0]                     cta_rank;
        cta_lane_t [64-1:0]     lane_launch;
    } cta_warp_t;
    localparam INST_ARGS_BITS = 3 + ALU_TYPE_BITS + 20 + 2;
    typedef struct packed {
        logic [1:0] __padding;
        logic use_PC;
        logic use_imm;
        logic is_w;
        logic [ALU_TYPE_BITS-1:0] xtype;
        logic [19:0] imm20;
    } alu_args_t;
    typedef struct packed {
        logic [1:0] __padding;
        logic use_PC;
        logic use_imm;
        logic is_rvc;
        logic [ALU_TYPE_BITS-1:0] xtype;
        logic [19:0] imm20;
    } br_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-INST_FRM_BITS-INST_FMT_BITS)-1:0] __padding;
        logic [INST_FRM_BITS-1:0] frm;
        logic [INST_FMT_BITS-1:0] fmt;
    } fpu_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-1-1-12-2-1-1-$bits(amo_op_e)-2-2)-1:0] __padding;
        logic [1:0]                 export_mask;
        logic                       amo_valid;
        logic                       amo_unsigned;
        amo_op_e                    amo_op;
        logic                       amo_aq;
        logic                       amo_rl;
        logic [1:0]                 pack;
        logic                       is_store;
        logic                       is_float;
        logic [11:0]                offset;
    } lsu_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-1-12-5)-1:0] __padding;
        logic use_imm;
        logic [12-1:0] addr;
        logic [4:0] imm5;
    } csr_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-3)-1:0] __padding;
        logic is_cond_neg;
        logic is_sync_bar;
        logic is_bar_arrive;
    } wctl_args_t;
    typedef struct packed {
        logic is_last_uop;     
        logic is_first_uop;    
        logic a_from_smem;     
        logic [1:0] cd_nregs;  
        logic [4:0] fmt_d;
        logic [4:0] fmt_s;
        logic [3:0] step_k;
        logic [3:0] step_n;
        logic [3:0] step_m;
    } tcu_args_t;
    typedef union packed {
        alu_args_t  alu;
        br_args_t   br;
        fpu_args_t  fpu;
        lsu_args_t  lsu;
        csr_args_t  csr;
        wctl_args_t wctl;
        tcu_args_t  tcu;
    } op_args_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]  uuid;
        logic [NW_WIDTH-1:0]    wid;
        logic [NCTA_WIDTH-1:0]  cta_id;
        logic [64-1:0] tmask;
        logic [PC_BITS-1:0]     PC;
        logic [31:0]            instr;
    } fetch_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       rd_xregs;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
    } decode_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       rd_xregs;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
        logic                       fu_lock;
        logic                       fu_unlock;
    } ibuffer_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [ISSUE_WIS_W-1:0]     wis;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
    } scoreboard_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic [EX_BITS-1:0]                 ex_type;
        logic [INST_OP_BITS-1:0]            op_type;
        op_args_t                           op_args;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [64-1:0][32-1:0]  rs1_data;
        logic [64-1:0][32-1:0]  rs2_data;
        logic [64-1:0][32-1:0]  rs3_data;
        logic                               sop;
        logic                               eop;
    } operands_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [INST_OP_BITS-1:0]            op_type;
        op_args_t                           op_args;
        logic [64-1:0][32-1:0]  rs1_data;
        logic [64-1:0][32-1:0]  rs2_data;
        logic [64-1:0][32-1:0]  rs3_data;
        logic                               sop;
        logic                               eop;
    } dispatch_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [NW_WIDTH-1:0]                wid;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [64-1:0][32-1:0]  data;
        logic                               sop;
        logic                               eop;
    } commit_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [PER_ISSUE_WARPS-1:0]         eop_wis;  
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [64-1:0][XLENB-1:0]  byteen;
        logic [64-1:0][32-1:0]  data;
        logic                               sop;
        logic                               eop;
    } writeback_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [NW_WIDTH-1:0]                wid;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [64-1:0]            tmask;
        logic [PC_BITS-1:0]                 PC;
    } schedule_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } alu_header_t; 
    typedef struct packed { 
        alu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } alu_execute_t; 
    typedef struct packed { 
        alu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } alu_result_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } lsu_header_t; 
    typedef struct packed { 
        lsu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } lsu_execute_t; 
    typedef struct packed { 
        lsu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } lsu_result_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } sfu_header_t; 
    typedef struct packed { 
        sfu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } sfu_execute_t; 
    typedef struct packed { 
        sfu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } sfu_result_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] read_misses;
        logic [PERF_CTR_BITS-1:0] write_misses;
        logic [PERF_CTR_BITS-1:0] evictions;
        logic [PERF_CTR_BITS-1:0] bank_stalls;
        logic [PERF_CTR_BITS-1:0] mshr_stalls;
        logic [PERF_CTR_BITS-1:0] mem_stalls;
        logic [PERF_CTR_BITS-1:0] crsp_stalls;
    } cache_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] bank_stalls;
        logic [PERF_CTR_BITS-1:0] crsp_stalls;
    } lmem_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] misses;
    } coalescer_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] tlb_reads;
        logic [PERF_CTR_BITS-1:0] tlb_hits;
        logic [PERF_CTR_BITS-1:0] tlb_misses;
        logic [PERF_CTR_BITS-1:0] tlb_evictions;
        logic [PERF_CTR_BITS-1:0] ptw_walks;
        logic [PERF_CTR_BITS-1:0] ptw_latency;
    } mmu_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] lmem_reads;         
        logic [PERF_CTR_BITS-1:0] tbuf_cache_hits;    
        logic [PERF_CTR_BITS-1:0] wgmma_stalls;       
        logic [PERF_CTR_BITS-1:0] wgmma_instrs;       
        logic [PERF_CTR_BITS-1:0] tbuf_stalls;          
    } tcu_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] latency;
    } mem_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] idles;
        logic [PERF_CTR_BITS-1:0] active_warps;
        logic [PERF_CTR_BITS-1:0] stalled_warps;
        logic [PERF_CTR_BITS-1:0] issued_warps;
        logic [PERF_CTR_BITS-1:0] issued_threads;
        logic [PERF_CTR_BITS-1:0] branches;
        logic [PERF_CTR_BITS-1:0] divergence;
    } sched_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] stalls;
    } fetch_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] ibf_stalls;
        logic [PERF_CTR_BITS-1:0] scb_stalls;
        logic [PERF_CTR_BITS-1:0] opd_stalls;
        logic [NUM_EX_UNITS-1:0][PERF_CTR_BITS-1:0] dispatch_stalls;
        logic [NUM_EX_UNITS-1:0][PERF_CTR_BITS-1:0] dispatch_instrs;
    } issue_perf_t;
    typedef struct packed {
        cache_perf_t icache;
        cache_perf_t dcache;
        cache_perf_t l2cache;
        cache_perf_t l3cache;
        lmem_perf_t  lmem;
        coalescer_perf_t coalescer;
        mem_perf_t   mem;
    } sysmem_perf_t;
    typedef struct packed {
        sched_perf_t              sched;
        fetch_perf_t              fetch;
        issue_perf_t              issue;
        tcu_perf_t                tcu;
        logic [PERF_CTR_BITS-1:0] ifetches;
        logic [PERF_CTR_BITS-1:0] loads;
        logic [PERF_CTR_BITS-1:0] stores;
        logic [PERF_CTR_BITS-1:0] ifetch_latency;
        logic [PERF_CTR_BITS-1:0] load_latency;
   } pipeline_perf_t;
    localparam LSU_WORD_SIZE        = XLENB;
    localparam LSU_ADDR_WIDTH	    = (32 - $clog2(LSU_WORD_SIZE));
    localparam LSU_MEM_BATCHES      = 1;
    localparam LSU_TAG_ID_BITS      = ($clog2(8) + $clog2(LSU_MEM_BATCHES));
    localparam LSU_TAG_WIDTH        = (UUID_WIDTH + LSU_TAG_ID_BITS);
    localparam LSU_NUM_REQS	        = 1 * 64;
    localparam LSU_QUEUE_OUT_SIZE   = (((8) > (64 / LSU_WORD_SIZE)) ? (8) : (64 / LSU_WORD_SIZE));
    localparam LMEM_TAG_WIDTH_BASE  = LSU_TAG_WIDTH + $clog2(1);
    localparam LMEM_TAG_WIDTH       = LMEM_TAG_WIDTH_BASE;
    localparam LSU_CLIENT_TAG_WIDTH = $bits(lsu_header_t) + INST_LSU_BITS
                                    + (64 * $clog2(LSU_WORD_SIZE))
                                    + (((8) > 1) ? $clog2(8) : 1) + 1;
    typedef struct packed {
        logic                                                       rw;
        logic [64-1:0]                           mask;
        logic [64-1:0][LSU_WORD_SIZE-1:0]        byteen;
        logic [64-1:0][LSU_ADDR_WIDTH-1:0]       addr;
        logic [64-1:0][MEM_ATTR_WIDTH-1:0]       attr;
        logic [64-1:0][(LSU_WORD_SIZE*8)-1:0]    data;
        logic [LSU_CLIENT_TAG_WIDTH-1:0]                            tag;
    } lsu_req_data_t;
    typedef struct packed {
        logic [64-1:0]                           mask;
        logic [64-1:0][(LSU_WORD_SIZE*8)-1:0]    data;
        logic [LSU_CLIENT_TAG_WIDTH-1:0]                            tag;
        logic                                                       sop;
        logic                                                       eop;
    } lsu_rsp_data_t;
    localparam DXA_LMEM_ATTR_W = (BAR_ADDR_W + 1);
    localparam DXA_LMEM_ENGINE_TAG_W = UUID_WIDTH + 1;
    localparam DXA_LMEM_TAG_W = DXA_LMEM_ENGINE_TAG_W + NC_BITS;
    localparam DXA_LMEM_OUT_TAG_W = DXA_LMEM_TAG_W + ((1 > 1) ? $clog2(((1 + 1 - 1) / (1))) : 0);
    localparam TCU_LMEM_ATTR_W = 1;
    localparam TCU_LMEM_BLK_TAG_W = UUID_WIDTH + 1;
    localparam TCU_LMEM_NUM_MASTERS = 1 + 1;
    localparam TCU_LMEM_TAG_W = TCU_LMEM_BLK_TAG_W + ((TCU_LMEM_NUM_MASTERS > 1) ? $clog2(((TCU_LMEM_NUM_MASTERS + 1 - 1) / (1))) : 0);
    localparam LMEM_DMA_EN         = (0 + 0) != 0;
    localparam LMEM_DMA_DATA_SIZE  = 64 * LSU_WORD_SIZE;
    localparam LMEM_DMA_ADDR_WIDTH = 17 - $clog2(64 * LSU_WORD_SIZE);
    localparam LMEM_DMA_ATTR_W     = (((DXA_LMEM_ATTR_W) > (TCU_LMEM_ATTR_W)) ? (DXA_LMEM_ATTR_W) : (TCU_LMEM_ATTR_W));
    localparam LMEM_DMA_DXA_IDX    = 0;
    localparam LMEM_DMA_TCU_IDX    = LMEM_DMA_DXA_IDX + 0;
    localparam LMEM_DMA_INPUTS     = 0 + 0;
    localparam LMEM_DMA_IN_TAG_MAX = (((DXA_LMEM_OUT_TAG_W) > (TCU_LMEM_TAG_W)) ? (DXA_LMEM_OUT_TAG_W) : (TCU_LMEM_TAG_W));
    localparam LMEM_DMA_TAG_WIDTH  = LMEM_DMA_IN_TAG_MAX + ((LMEM_DMA_INPUTS > 1) ? $clog2(((LMEM_DMA_INPUTS + 1 - 1) / (1))) : 0);
    localparam ICACHE_WORD_SIZE	    = 4;
    localparam ICACHE_ADDR_WIDTH	= (32 - $clog2(ICACHE_WORD_SIZE));
    localparam ICACHE_LINE_SIZE	    = 64;
    localparam ICACHE_TAG_ID_BITS	= NW_WIDTH;
    localparam ICACHE_FETCH_TAG_WIDTH = (UUID_WIDTH + ICACHE_TAG_ID_BITS);
    localparam ICACHE_TAG_WIDTH_BASE = (ICACHE_FETCH_TAG_WIDTH + 1);
    localparam ICACHE_TAG_WIDTH       = ICACHE_TAG_WIDTH_BASE;
    localparam ICACHE_MEM_DATA_WIDTH = (ICACHE_LINE_SIZE * 8);
    localparam ICACHE_MEM_TAG_WIDTH = 
        (
        (UUID_WIDTH + $clog2(16) + $clog2(((1 + 1 - 1) / (1)))) + (((((1) > 0) ? (1) : 1) > 1) ? $clog2((((((1) > 0) ? (1) : 1) + 1 - 1) / (1))) : 0));
    localparam DCACHE_WORD_SIZE	    = 32;
    localparam DCACHE_ADDR_WIDTH	= (32 - $clog2(DCACHE_WORD_SIZE));
    localparam DCACHE_LINE_SIZE 	= 64;
    localparam DCACHE_SECTOR_SIZE   = 64;
    localparam DCACHE_CHANNELS	    = ((((64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE) > 0) ? ((64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE) : 1);
    localparam DCACHE_NUM_REQS	    = 1 * DCACHE_CHANNELS;
    localparam DCACHE_NUM_BANKS     = 1;
    localparam L1_MEM_PORTS         = 1;
    localparam DCACHE_MERGED_REQS   = (64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE;
    localparam DCACHE_MEM_BATCHES   = ((DCACHE_MERGED_REQS + DCACHE_CHANNELS - 1) / (DCACHE_CHANNELS));
    localparam DCACHE_TAG_ID_BITS   = ($clog2(LSU_QUEUE_OUT_SIZE) + $clog2(DCACHE_MEM_BATCHES));
    localparam DCACHE_CORE_TAG_WIDTH = (UUID_WIDTH + DCACHE_TAG_ID_BITS);
    localparam DCACHE_TAG_WIDTH_BASE = (DCACHE_CORE_TAG_WIDTH + 1);
    localparam DCACHE_TAG_WIDTH       = DCACHE_TAG_WIDTH_BASE;
    localparam DCACHE_MEM_DATA_WIDTH = (DCACHE_SECTOR_SIZE * 8);
    localparam DCACHE_MEM_TAG_WIDTH = 
        (
        ((((
        (UUID_WIDTH + $clog2(16) + $clog2(((DCACHE_NUM_BANKS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))))) > (
        ($clog2(((DCACHE_NUM_REQS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))) + $clog2(DCACHE_SECTOR_SIZE / DCACHE_WORD_SIZE) + 
        (DCACHE_TAG_WIDTH + ((1 > (((1) > 0) ? (1) : 1)) ? $clog2(((1 + (((1) > 0) ? (1) : 1) - 1) / ((((1) > 0) ? (1) : 1)))) : 0))))) ? (
        (UUID_WIDTH + $clog2(16) + $clog2(((DCACHE_NUM_BANKS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))))) : (
        ($clog2(((DCACHE_NUM_REQS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))) + $clog2(DCACHE_SECTOR_SIZE / DCACHE_WORD_SIZE) + 
        (DCACHE_TAG_WIDTH + ((1 > (((1) > 0) ? (1) : 1)) ? $clog2(((1 + (((1) > 0) ? (1) : 1) - 1) / ((((1) > 0) ? (1) : 1)))) : 0))))) + 1) + (((((1) > 0) ? (1) : 1) > 1) ? $clog2((((((1) > 0) ? (1) : 1) + 1 - 1) / (1))) : 0));
    localparam DCACHE_IS_LLC        = !0 && !0;
    localparam L1_MEM_TAG_WIDTH     = (((ICACHE_MEM_TAG_WIDTH) > (DCACHE_MEM_TAG_WIDTH)) ? (ICACHE_MEM_TAG_WIDTH) : (DCACHE_MEM_TAG_WIDTH));
    localparam ICACHE_MEM_ARB_IDX   = 0;
    localparam DCACHE_MEM_ARB_IDX   = ICACHE_MEM_ARB_IDX + 1;
    localparam TCACHE_MEM_ARB_IDX   = DCACHE_MEM_ARB_IDX + 1;
    localparam RTCACHE_MEM_ARB_IDX  = TCACHE_MEM_ARB_IDX + 0;
    localparam DXA_MEM_ARB_IDX      = RTCACHE_MEM_ARB_IDX + 0;
    localparam SOCKET_MEM_ARB_REQS  = 2 + 0 + 0 + 0;
    localparam SOCKET_MEM_TAG_W1    = L1_MEM_TAG_WIDTH;
    localparam SOCKET_MEM_TAG_WIDTH = SOCKET_MEM_TAG_W1;
    localparam SOCKET_MEM_ARB_TAG_WIDTH = (SOCKET_MEM_TAG_WIDTH + $clog2(SOCKET_MEM_ARB_REQS));
    localparam L2_WORD_SIZE	        = 64;
    localparam L2_SECTOR_SIZE       = 64;
    localparam L2_SOCKET_REQS       = NUM_SOCKETS * L1_MEM_PORTS;
    localparam L2_GFX_REQS          = 0 + 0;
    localparam L2_GFX_RASTER_IDX    = L2_SOCKET_REQS;
    localparam L2_GFX_OM_IDX        = L2_GFX_RASTER_IDX + 0;
    localparam PTW_ON_L2            = ((0 != 0)
                                    && (1 == 1)
                                    && (0 != 0)
                                    && (0 == 0)) ? 1 : 0;
    localparam L2_PTW_REQS          = PTW_ON_L2;
    localparam L2_PTW_IDX           = L2_SOCKET_REQS + L2_GFX_REQS;
    localparam L2_NUM_REQS          = L2_SOCKET_REQS + L2_GFX_REQS + L2_PTW_REQS;
    localparam L2_NUM_BANKS         = 1;
    localparam L2_MEM_PORTS         = 0;
    localparam L2_TAG_WIDTH         = SOCKET_MEM_ARB_TAG_WIDTH;
    localparam L1_TLB_ID_WIDTH       = $clog2(4);
    localparam TLB_SOCKET_ID_WIDTH   = L1_TLB_ID_WIDTH + ((2 > 1) ? $clog2(((2 + 1 - 1) / (1))) : 0);
    localparam TLB_CLUSTER_ID_WIDTH  = TLB_SOCKET_ID_WIDTH + ((NUM_SOCKETS > 1) ? $clog2(((NUM_SOCKETS + 1 - 1) / (1))) : 0);
    localparam L2_TLB_SLOT_WIDTH     = $clog2(8);
    localparam TLB_DEV_ID_WIDTH      = L2_TLB_SLOT_WIDTH + ((1 > 1) ? $clog2(((1 + 1 - 1) / (1))) : 0);
    localparam L2_MEM_DATA_WIDTH	= (L2_SECTOR_SIZE * 8);
    localparam L2_MEM_TAG_WIDTH     = 
        ($clog2(((L2_NUM_REQS + L2_MEM_PORTS - 1) / (L2_MEM_PORTS))) + $clog2(L2_SECTOR_SIZE / L2_WORD_SIZE) + L2_TAG_WIDTH);
    localparam L2_IS_LLC            = 0 && !0;
    localparam L3_WORD_SIZE	        = L2_SECTOR_SIZE;
    localparam L3_SECTOR_SIZE       = 64;
    localparam L3_PTW_IDX           = 1 * L2_MEM_PORTS;
    localparam L3_NUM_REQS	        = 1 * L2_MEM_PORTS
                                    + ((0 != 0) && (PTW_ON_L2 == 0) ? 1 : 0);
    localparam L3_NUM_BANKS         = 1;
    localparam L3_MEM_PORTS         = 0;
    localparam L3_TAG_WIDTH	        = L2_MEM_TAG_WIDTH;
    localparam L3_MEM_DATA_WIDTH	= (L3_SECTOR_SIZE * 8);
    localparam L3_MEM_TAG_WIDTH     = 
        ($clog2(((L3_NUM_REQS + L3_MEM_PORTS - 1) / (L3_MEM_PORTS))) + $clog2(L3_SECTOR_SIZE / L3_WORD_SIZE) + L3_TAG_WIDTH);
    localparam L3_IS_LLC            = 0;
    localparam VX_MEM_PORTS =           L3_MEM_PORTS;
    localparam VX_MEM_BYTEEN_WIDTH =    L3_SECTOR_SIZE;
    localparam VX_MEM_ADDR_WIDTH =      (32 - $clog2(L3_SECTOR_SIZE));
    localparam VX_MEM_DATA_WIDTH =      (L3_SECTOR_SIZE * 8);
    localparam VX_MEM_TAG_WIDTH =       L3_MEM_TAG_WIDTH;
    function automatic logic [SFU_WIDTH-1:0] op_to_sfu_type(
        input logic [INST_OP_BITS-1:0] op_type
    );
        case (op_type)
            INST_SFU_CSRRW,
            INST_SFU_CSRRS,
            INST_SFU_CSRRC: op_to_sfu_type = SFU_CSRS;
            default: op_to_sfu_type = SFU_WCTL;
        endcase
    endfunction
    function automatic logic [NUM_REGS_BITS-1:0] make_reg_num(input logic [REG_TYPE_BITS-1:0] rtype, logic [RV_REGS_BITS-1:0] idx);
        return (NUM_REGS_BITS'(rtype) << RV_REGS_BITS) | NUM_REGS_BITS'(idx);
    endfunction
    function automatic logic [REG_TYPE_BITS-1:0] get_reg_type(input logic [NUM_REGS_BITS-1:0] reg_num);
        return REG_TYPE_BITS'(reg_num >> RV_REGS_BITS);
    endfunction
    function automatic logic [RV_REGS_BITS-1:0] get_reg_idx(input logic [NUM_REGS_BITS-1:0] reg_num);
        return reg_num[RV_REGS_BITS-1:0];
    endfunction
    function automatic logic [UUID_WIDTH-1:0] get_uop_uuid(input logic [UUID_WIDTH-1:0] uuid, input logic [UOP_CTR_W-1:0] uop_idx);
        logic [31:0] uuid_lo = {uop_idx[0 +: UOP_CTR_W], uuid[0 +: (32 - UOP_CTR_W)]};
        return {uuid[UUID_WIDTH-1:32], uuid_lo};
    endfunction
endpackage
package VX_tcu_pkg;
    import VX_gpu_pkg::*;
    localparam TCU_FP32_ID  = 0;
    localparam TCU_TF32_ID  = 1;
    localparam TCU_FP16_ID  = 2;
    localparam TCU_BF16_ID  = 3;
    localparam TCU_FP8_ID   = 4;
    localparam TCU_BF8_ID   = 5;
    localparam TCU_MXFP8_ID = 8;
    localparam TCU_MXBF8_ID = 9;
    localparam TCU_MXFP4_ID = 10;
    localparam TCU_NVFP4_ID = 11;
    localparam TCU_I32_ID   = 16;
    localparam TCU_I8_ID    = 17;
    localparam TCU_U8_ID    = 18;
    localparam TCU_I4_ID    = 19;
    localparam TCU_U4_ID    = 20;
    localparam TCU_FMT_WIDTH= 5;
    localparam TCU_NT = 64;
    localparam TCU_WG_NRA = 4;   
    localparam TCU_WG_NR = 32;   
    localparam TCU_NR = 8;
    localparam TCU_DK = 0;
    localparam TCU_DP = 0;
    localparam TCU_TILE_CAP = TCU_NT * TCU_NR;
    localparam TCU_LG_TILE_CAP = $clog2(TCU_TILE_CAP);
    localparam TCU_TILE_EN = TCU_LG_TILE_CAP / 2;
    localparam TCU_TILE_EM = TCU_LG_TILE_CAP - TCU_TILE_EN;
    localparam TCU_TILE_M = 1 << TCU_TILE_EM;
    localparam TCU_TILE_N = 1 << TCU_TILE_EN;
    localparam TCU_TILE_K = (TCU_DK != 0) ? TCU_DK : (TCU_DP != 0) ? TCU_DP : (TCU_TILE_CAP / ((TCU_TILE_M > TCU_TILE_N) ? TCU_TILE_M : TCU_TILE_N));
    localparam TCU_BLOCK_CAP = TCU_NT;
    localparam TCU_LG_BLOCK_CAP = $clog2(TCU_BLOCK_CAP);
    localparam TCU_BLOCK_EN = TCU_LG_BLOCK_CAP / 2;
    localparam TCU_BLOCK_EM = TCU_LG_BLOCK_CAP - TCU_BLOCK_EN;
    localparam TCU_TC_M = 1 << TCU_BLOCK_EM;
    localparam TCU_TC_N = 1 << TCU_BLOCK_EN;
    localparam TCU_TC_K = (TCU_DP != 0) ? TCU_DP : (TCU_BLOCK_CAP / ((TCU_TC_M > TCU_TC_N) ? TCU_TC_M : TCU_TC_N));
    localparam TCU_M_STEPS = TCU_TILE_M / TCU_TC_M;
    localparam TCU_N_STEPS = TCU_TILE_N / TCU_TC_N;
    localparam TCU_K_STEPS = TCU_TILE_K / TCU_TC_K;
    localparam TCU_A_BLOCK_SIZE = TCU_TC_M * TCU_TC_K;
    localparam TCU_A_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_A_BLOCK_SIZE;
    localparam TCU_B_BLOCK_SIZE = TCU_TC_K * TCU_TC_N;
    localparam TCU_B_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_B_BLOCK_SIZE;
    localparam TCU_WG_TILE_M = 2 * TCU_TC_M;
    localparam TCU_WG_TILE_K = 2 * TCU_TC_K;
    localparam TCU_WG_FEDP_K = TCU_TC_K;
    localparam TCU_WG_TILE_N = (TCU_WG_NR * TCU_NT) / TCU_WG_TILE_M;
    localparam TCU_WG_M_STEPS = TCU_WG_TILE_M / TCU_TC_M;
    localparam TCU_WG_N_STEPS = TCU_WG_TILE_N / TCU_TC_N;
    localparam TCU_WG_K_STEPS = TCU_WG_TILE_K / TCU_WG_FEDP_K;
    localparam TCU_WG_UOPS = TCU_WG_M_STEPS * TCU_WG_N_STEPS * TCU_WG_K_STEPS;
    localparam TCU_WG_A_BLOCK_SIZE = TCU_TC_M * TCU_TC_K;
    localparam TCU_WG_A_DATA_SIZE  = TCU_TC_M * TCU_WG_FEDP_K;
    localparam TCU_WG_A_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_WG_A_BLOCK_SIZE;
    localparam TCU_WG_B_BLOCK_SIZE = TCU_WG_FEDP_K * TCU_TC_N;
    localparam TCU_WG_B_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_WG_B_BLOCK_SIZE;
    localparam SYM_SPARSE = 0 ? 0 : (TCU_BLOCK_EM == TCU_BLOCK_EN);
    localparam TCU_B_BLOCK_SIZE_SP    = SYM_SPARSE ? TCU_BLOCK_CAP : (TCU_TC_K * TCU_TC_N) * 2;
    localparam TCU_B_SUB_BLOCKS_SP    = TCU_BLOCK_CAP / TCU_B_BLOCK_SIZE_SP;
    localparam TCU_WG_B_BLOCK_SIZE_SP = TCU_TC_K * TCU_TC_N * 2;
    localparam TCU_WG_RS2_WIDTH_DENSE =
        (TCU_WG_B_BLOCK_SIZE > TCU_BLOCK_CAP) ? TCU_WG_B_BLOCK_SIZE : TCU_BLOCK_CAP;
    localparam TCU_WG_RS2_WIDTH = 0
        ? ((TCU_WG_B_BLOCK_SIZE_SP > TCU_WG_RS2_WIDTH_DENSE) ? TCU_WG_B_BLOCK_SIZE_SP : TCU_WG_RS2_WIDTH_DENSE)
        : TCU_WG_RS2_WIDTH_DENSE;
    localparam TCU_MIN_FMT_WIDTH = 4;  
    localparam TCU_MAX_ELT_RATIO = 32 / TCU_MIN_FMT_WIDTH;
    localparam TCU_MAX_META_ROW_WIDTH   = TCU_TC_K * 2 * TCU_MAX_ELT_RATIO;
    localparam TCU_MAX_META_BLOCK_WIDTH = TCU_NT   * 2 * TCU_MAX_ELT_RATIO;
    localparam TCU_META_PER_WARP_DEPTH = TCU_M_STEPS * (TCU_K_STEPS / 2);
    localparam TCU_META_COLS_PER_LOAD  = (TCU_BLOCK_CAP >= TCU_META_PER_WARP_DEPTH)
        ? (TCU_BLOCK_CAP / TCU_META_PER_WARP_DEPTH) : 1;
    localparam TCU_BANKS_PER_STORE = (TCU_NT < TCU_META_PER_WARP_DEPTH)
        ? TCU_NT : TCU_META_PER_WARP_DEPTH;
    localparam TCU_STORES_PER_COL = (TCU_META_PER_WARP_DEPTH + TCU_NT - 1) / TCU_NT;
    localparam TCU_NRA = (TCU_TILE_M * TCU_TILE_K) / TCU_NT;
    localparam TCU_NRB = (TCU_TILE_N * TCU_TILE_K) / TCU_NT;
    localparam TCU_NRC = (TCU_TILE_M * TCU_TILE_N) / TCU_NT;
    localparam TCU_RC    = 0;
    localparam TCU_WG_RC = TCU_RC;   
    localparam TCU_WG_RA = 24;      
    localparam TCU_RA = 10;
    localparam TCU_RB = (TCU_NRB == 4) ? 28 : 24;
    localparam TCU_UOPS = TCU_M_STEPS * TCU_N_STEPS * TCU_K_STEPS;
    localparam TCU_MAX_INPUTS = TCU_TC_K * TCU_MAX_ELT_RATIO;
    function automatic int unsigned mx_fedp_sf_count(
        input int unsigned data_bits,
        input int unsigned block_elems
    );
        automatic int unsigned sparse_ratio = 0 ? 2 : 1;
        automatic int unsigned fedp_elems = TCU_WG_FEDP_K * (32 / data_bits) * sparse_ratio;
        return (fedp_elems + block_elems - 1) / block_elems;
    endfunction
    localparam TCU_MX_SF_FP8 = mx_fedp_sf_count(8, 32);
    localparam TCU_MX_SF_MXFP4 = mx_fedp_sf_count(4, 32);
    localparam TCU_MX_SF_NVFP4 = mx_fedp_sf_count(4, 16);
    localparam TCU_MX_MAX_SF = 
((((((TCU_MX_SF_FP8) > (TCU_MX_SF_MXFP4)) ? (TCU_MX_SF_FP8) : (TCU_MX_SF_MXFP4))) > (TCU_MX_SF_NVFP4)) ? ((((TCU_MX_SF_FP8) > (TCU_MX_SF_MXFP4)) ? (TCU_MX_SF_FP8) : (TCU_MX_SF_MXFP4))) : (TCU_MX_SF_NVFP4));
        localparam TCU_EXP_BITS = 10;
    typedef struct packed {
        logic is_zero;
        logic is_sub;
        logic is_inf;
        logic is_nan;
    } fedp_class_t;
    typedef struct packed {
        logic is_inf;
        logic is_nan;
        logic sign;
    } fedp_excep_t;
    function automatic int exp_bits(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 8;
            TCU_FP16_ID: return 5;
            TCU_BF16_ID: return 8;
            TCU_FP8_ID:  return 4;
            TCU_BF8_ID:  return 5;
            TCU_TF32_ID: return 8;
            default:     return 0;
        endcase
    endfunction
    function automatic int sig_bits(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 23;
            TCU_FP16_ID: return 10;
            TCU_BF16_ID: return 7;
            TCU_FP8_ID:  return 3;
            TCU_BF8_ID:  return 2;
            TCU_TF32_ID: return 10;
            default:     return 0;
        endcase
    endfunction
    function automatic int sign_pos(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 31;
            TCU_FP16_ID: return 15;
            TCU_BF16_ID: return 15;
            TCU_FP8_ID:  return 7;
            TCU_BF8_ID:  return 7;
            TCU_TF32_ID: return 18;
            default:     return 0;
        endcase
    endfunction
    function automatic int unsigned tcu_fmt_width(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_FP16_ID, TCU_BF16_ID:
                return 16;
            TCU_MXFP4_ID, TCU_NVFP4_ID, TCU_I4_ID, TCU_U4_ID:
                return 4;
            TCU_FP8_ID,
            TCU_BF8_ID,
            TCU_I8_ID,
            TCU_U8_ID,
            TCU_MXFP8_ID,
            TCU_MXBF8_ID:
                return 8;
            TCU_FP32_ID,
            TCU_I32_ID,
            TCU_TF32_ID:
                return 32;
            default:
                return 0;
        endcase
    endfunction
    function automatic logic tcu_fmt_is_int(input logic [TCU_FMT_WIDTH-1:0] fmt);
        return fmt[TCU_FMT_WIDTH-1];
    endfunction
    function automatic logic tcu_fmt_is_signed_int(input logic [TCU_FMT_WIDTH-2:0] int_fmt);
        return int_fmt[0];
    endfunction
    function automatic logic tcu_fmt_is_bfloat(input logic [TCU_FMT_WIDTH-2:0] float_fmt);
        return float_fmt[0];
    endfunction
    function automatic logic tcu_fmt_is_mx(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_MXFP8_ID, TCU_MXBF8_ID, TCU_MXFP4_ID, TCU_NVFP4_ID:
                return 1'b1;
            default:
                return 1'b0;
        endcase
    endfunction
    function automatic int unsigned mx_scale_block_size(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_MXFP8_ID, TCU_MXBF8_ID, TCU_MXFP4_ID: return 32;
            TCU_NVFP4_ID:                                          return 16;
            default:                                               return 1;
        endcase
    endfunction
    function automatic int unsigned mx_scale_blocks_k_words(
        input logic [TCU_FMT_WIDTH-1:0] fmt,
        input int unsigned tile_k_words
    );
        automatic int unsigned data_bits = tcu_fmt_width(fmt);
        automatic int unsigned block_elems = mx_scale_block_size(fmt);
        automatic int unsigned tile_elems = (data_bits != 0) ? tile_k_words * (32 / data_bits) : 0;
        return (tile_elems + block_elems - 1) / block_elems;
    endfunction
    function automatic int unsigned mx_scale_blocks_k(input logic [TCU_FMT_WIDTH-1:0] fmt);
        return mx_scale_blocks_k_words(fmt, TCU_TILE_K);
    endfunction
    function automatic logic [4:0] meta_num_cols(input logic [TCU_FMT_WIDTH-1:0] fmt);
        automatic int hw = tcu_fmt_width(fmt) / 2;
        return 5'((TCU_BLOCK_CAP + hw - 1) / hw);
    endfunction
    function automatic int unsigned tcu_meta_stride_words(input logic [TCU_FMT_WIDTH-1:0] fmt);
        automatic int unsigned fb   = tcu_fmt_width(fmt);
        automatic int unsigned elr  = (fb != 0) ? (32 / fb) : 1;  
        automatic int unsigned rowb = TCU_TC_K * 2 * elr;
        return (TCU_TC_M * rowb + 31) / 32;
    endfunction
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } tcu_header_t; 
    typedef struct packed { 
        tcu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } tcu_execute_t; 
    typedef struct packed { 
        tcu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } tcu_result_t;
    typedef struct packed {
        logic                       valid;
        logic [UUID_WIDTH-1:0]      uuid;    
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [3:0]                 step_m;
        logic [3:0]                 step_n;
        logic [3:0]                 step_k;
        logic [1:0]                 cd_nregs;
        logic [32-1:0]    desc_a;
        logic [32-1:0]    desc_b;
        logic                       a_is_smem;
        logic                       is_first_uop;
        logic                       is_last_uop;
        logic                       setup_fire;
    } tcu_tbuf_req_t;
endpackage
module FullAdder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    assign sum = a ^ b ^ cin;
    assign cout = (a & b) | ((a ^ b) & cin);
endmodule
module VX_csa_32 #(
    parameter N = 3,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N-1:0] carry_int;
    for (genvar i = 0; i < N; i++) begin : g_compress_3_2
        FullAdder FA (
            .a    (a[i]),
            .b    (b[i]),
            .cin  (c[i]),
            .sum  (sum_int[i]),
            .cout (carry_int[i])
        );
    end
    assign sum = WIDTH_O'(sum_int);
    assign carry = WIDTH_O'({1'b0, carry_int, 1'b0});
endmodule
module counter_5to3(
    input wire x1, x2, x3, x4, cin,
    output wire sum, carry, cout
);
    wire s1 = x1 ^ x2 ^ x3;
    assign cout = (x1 & x2) | (x2 & x3) | (x1 & x3);
    assign sum = s1 ^ x4 ^ cin;
    assign carry = (s1 & x4) | (x4 & cin) | (s1 & cin);
endmodule
module VX_csa_42 #(
    parameter N = 4,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    input  wire [N-1:0] d,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N:0]   cin;
    wire [N-1:0] cout;
    wire [N-1:0] carry_int;
    assign cin[0] = 1'b0;
    for (genvar i = 0; i < N; i++) begin : g_compress_4_2
        counter_5to3 u_counter_5to3(
            .x1(a[i]),
            .x2(b[i]),
            .x3(c[i]),
            .x4(d[i]),
            .cin(cin[i]),
            .sum(sum_int[i]),
            .carry(carry_int[i]),
            .cout(cout[i])
        );
        assign cin[i+1] = cout[i];
    end
    wire [1:0] carry_temp;
    assign sum = WIDTH_O'(sum_int);
    assign carry_temp = {carry_int[N-1] & cin[N], carry_int[N-1] ^ cin[N]};
    assign carry = WIDTH_O'({carry_temp, carry_int[N-2:0], 1'b0});
endmodule
module VX_csa_block #(
    parameter N = 4,
    parameter W = 8,
    parameter S = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    ;
    function automatic integer calc_4to2_levels(integer n);
        integer remaining = n;
        integer levels_4to2 = 0;
        while (remaining >= 4) begin
            levels_4to2 = levels_4to2 + 1;
            remaining = remaining - 2;
        end
        return levels_4to2;
    endfunction
    localparam LEVELS_4TO2 = calc_4to2_levels(N);
    localparam TOTAL_LEVELS = LEVELS_4TO2 + ((N - LEVELS_4TO2 * 2) == 3 ? 1 : 0);
    localparam WN_CALC = W + TOTAL_LEVELS + 2;
    localparam WN = (WN_CALC > S) ? WN_CALC : S;
    wire [WN-1:0] St [0:TOTAL_LEVELS];
    wire [WN-1:0] Ct [0:TOTAL_LEVELS];
    assign St[0] = WN'(operands[0]);
    assign Ct[0] = WN'(operands[1]);
    for (genvar i = 0; i < LEVELS_4TO2; i++) begin : g_4to2_levels
        localparam WI = W + i;
        localparam WO = WI + 2;
        localparam OP_A_IDX = 2 + (i * 2);
        localparam OP_B_IDX = 3 + (i * 2);
        wire [WO-1:0] st, ct;
        VX_csa_42 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_42 (
            .a(WI'(St[i])),
            .b(WI'(Ct[i])),
            .c(WI'(operands[OP_A_IDX])),
            .d(WI'(operands[OP_B_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[i+1] = WN'(st);
        assign Ct[i+1] = WN'(ct);
    end
    if ((N - LEVELS_4TO2 * 2) == 3) begin : g_final_3to2
        localparam FINAL_OP_IDX = 2 + (LEVELS_4TO2 * 2);
        localparam WI = W + LEVELS_4TO2;
        localparam WO = WI + 2;
        wire [WO-1:0] st, ct;
        VX_csa_32 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_32 (
            .a(WI'(St[LEVELS_4TO2])),
            .b(WI'(Ct[LEVELS_4TO2])),
            .c(WI'(operands[FINAL_OP_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[LEVELS_4TO2+1] = WN'(st);
        assign Ct[LEVELS_4TO2+1] = WN'(ct);
    end
    else begin : g_no_final_3to2
        if (LEVELS_4TO2 < TOTAL_LEVELS) begin : g_pass_through
            assign St[LEVELS_4TO2+1] = St[LEVELS_4TO2];
            assign Ct[LEVELS_4TO2+1] = Ct[LEVELS_4TO2];
        end
    end
    assign sum  = St[TOTAL_LEVELS][S-1:0];
    assign carry = Ct[TOTAL_LEVELS][S-1:0];
endmodule
module VX_csa_tree #(
    parameter N   = 16,  
    parameter W   = 8,   
    parameter K   = 6,   
    parameter BAL = 1,   
    parameter S   = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    localparam CLUSTER_W    = (K == 1) ? W : (W + K + 2);
    localparam NUM_CLUSTERS = (K == 1) ? N : ((N + K - 1) / K);
    localparam TOP_N        = (K == 1) ? N : (NUM_CLUSTERS * 2);
    function automatic integer next_lev_ragged(integer n_in);
        integer n_rem = n_in % 4;
        return (n_rem == 3) ? ((n_in/4)*2 + 2) : ((n_in/4)*2 + n_rem);
    endfunction
    function automatic integer next_lev_balanced(integer n_in);
        integer n_rem = n_in % 4;
        if (n_in <= 3) return (n_rem == 3) ? 2 : n_rem;
        if (n_rem == 0) return (n_in/4) * 2;
        if (n_rem == 1 || n_rem == 2) return ((n_in/4)-1)*2 + 4;
        return ((n_in/4)*2) + 2;
    endfunction
    function automatic integer get_next_sz(integer n, integer use_bal);
        return (use_bal != 0) ? next_lev_balanced(n) : next_lev_ragged(n);
    endfunction
    function automatic integer calc_depth(integer n_in);
        integer d = 0;
        integer count = n_in;
        while (count > 2) begin
            count = get_next_sz(count, BAL);
            d = d + 1;
        end
        return d;
    endfunction
    function automatic integer get_cnt_at_lev(integer l, integer start_n);
        integer c = start_n;
        for(integer k=0; k<l; k++) c = get_next_sz(c, BAL);
        return c;
    endfunction
    wire [TOP_N-1:0][CLUSTER_W-1:0] tree_inputs;
    if (K == 1) begin : g_no_cluster
        for (genvar i = 0; i < N; ++i) begin : g_map
            assign tree_inputs[i] = CLUSTER_W'(operands[i]);
        end
    end else begin : g_do_cluster
        for (genvar i = 0; i < NUM_CLUSTERS; ++i) begin : g_clusters
            localparam C_SIZE = (i == NUM_CLUSTERS - 1) ? (N - i*K) : K;
            if (C_SIZE == 1) begin : g_c1
                assign tree_inputs[2*i]     = CLUSTER_W'(operands[i*K]);
                assign tree_inputs[2*i + 1] = '0;
            end else begin : g_lin
                wire [CLUSTER_W-1:0] s_loc, c_loc;
                wire [C_SIZE-1:0][W-1:0] sub_ops;
                for(genvar j=0; j<C_SIZE; ++j) begin : g_slice
                    assign sub_ops[j] = operands[i*K + j];
                end
                VX_csa_block #(
                    .N(C_SIZE),
                    .W(W),
                    .S(CLUSTER_W)
                ) cluster_linear (
                    .operands(sub_ops),
                    .sum(s_loc),
                    .carry(c_loc)
                );
                assign tree_inputs[2*i]     = s_loc;
                assign tree_inputs[2*i + 1] = c_loc;
            end
        end
    end
    localparam DEPTH = calc_depth(TOP_N);
    localparam MAX_WN = CLUSTER_W + (DEPTH * 2) + 4;
    localparam WN = (S < MAX_WN) ? S : MAX_WN;
    wire [DEPTH:0][TOP_N-1:0][WN-1:0] tree_sig;
    for (genvar i = 0; i < TOP_N; i++) begin : g_init_l0
        assign tree_sig[0][i] = WN'(tree_inputs[i]);
    end
    for (genvar lev = 0; lev < DEPTH; lev++) begin : g_levels
        localparam integer NUM_IN = get_cnt_at_lev(lev, TOP_N);
        localparam integer WI = CLUSTER_W + (lev * 2);
        localparam integer WO = WI + 2;
        if (BAL == 1) begin : g_balanced
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            localparam integer CORE = (REM == 1 || REM == 2) ? (N_42 - 1) : N_42;
            for (genvar i = 0; i < CORE; i++) begin : g_core
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 1) begin : g_r1
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
                assign tree_sig[lev+1][OB+2] = tree_sig[lev][B+3]; assign tree_sig[lev+1][OB+3] = tree_sig[lev][B+4];
            end
            else if (REM == 2) begin : g_r2
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s1, c1, s2, c2;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cA (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s1),
                    .carry(c1)
                );
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cB (
                    .a(WI'(tree_sig[lev][B+3])),
                    .b(WI'(tree_sig[lev][B+4])),
                    .c(WI'(tree_sig[lev][B+5])),
                    .sum(s2),
                    .carry(c2)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s1); assign tree_sig[lev+1][OB+1] = WN'(c1);
                assign tree_sig[lev+1][OB+2] = WN'(s2); assign tree_sig[lev+1][OB+3] = WN'(c2);
            end
            else if (REM == 3) begin : g_r3
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
            end
        end
        else begin : g_ragged
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            for (genvar i = 0; i < N_42; i++) begin : g_csa42
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 3) begin : g_rem3
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][N_42*4])),
                    .b(WI'(tree_sig[lev][N_42*4+1])),
                    .c(WI'(tree_sig[lev][N_42*4+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][N_42*2] = WN'(s);
                assign tree_sig[lev+1][N_42*2+1] = WN'(c);
            end
            else begin : g_pass
                for(genvar p=0; p<REM; p++) begin : g_rem
                    assign tree_sig[lev+1][N_42*2+p] = tree_sig[lev][N_42*4+p];
                end
            end
        end
    end
    assign sum   = S'(tree_sig[DEPTH][0]);
    assign carry = (get_cnt_at_lev(DEPTH, TOP_N) > 1) ? S'(tree_sig[DEPTH][1]) : '0;
endmodule
module VX_ks_adder #(
    parameter N = 16,
    parameter BYPASS = 0
) (
    input  wire [N-1:0] dataa,
    input  wire [N-1:0] datab,
    input  wire         cin,
    output wire [N-1:0] sum,
    output wire         cout
);
    if (BYPASS) begin : g_bypass
        assign {cout, sum} = dataa + datab + N'(cin);
    end else begin : g_KS
        localparam LEVELS = $clog2(N);
        wire [LEVELS:0][N-1:0] G;
        wire [LEVELS:0][N-1:0] P;
        for (genvar i = 0; i < N; i++) begin : g_initial_gp
            assign G[0][i] = dataa[i] & datab[i];
            assign P[0][i] = dataa[i] ^ datab[i];
        end
        for (genvar k = 1; k <= LEVELS; k++) begin : g_ks_levels
            localparam STEP = 1 << (k - 1);
            for (genvar i = 0; i < N; i++) begin : g_ks_nodes
                if (i >= STEP) begin : g_compute_gp
                    assign G[k][i] = G[k-1][i] | (P[k-1][i] & G[k-1][i-STEP]);
                    assign P[k][i] = P[k-1][i] & P[k-1][i-STEP];
                end else begin : g_passthrough_gp
                    assign G[k][i] = G[k-1][i];
                    assign P[k][i] = P[k-1][i];
                end
            end
        end
        assign sum[0] = P[0][0] ^ cin;
        for (genvar i = 1; i < N; i++) begin : g_sum
            wire carry_in_i = G[LEVELS][i-1] | (P[LEVELS][i-1] & cin);
            assign sum[i] = P[0][i] ^ carry_in_i;
        end
        assign cout = G[LEVELS][N-1] | (P[LEVELS][N-1] & cin);
    end
endmodule
module VX_popcount63(
    input  wire [5:0] data_in,
    output wire [2:0] data_out
);
    reg [2:0] sum;
    always @(*) begin
        case (data_in)
         6'd0: sum=3'd0;   6'd1: sum=3'd1;   6'd2: sum=3'd1;   6'd3: sum=3'd2;
         6'd4: sum=3'd1;   6'd5: sum=3'd2;   6'd6: sum=3'd2;   6'd7: sum=3'd3;
         6'd8: sum=3'd1;   6'd9: sum=3'd2;  6'd10: sum=3'd2;  6'd11: sum=3'd3;
        6'd12: sum=3'd2;  6'd13: sum=3'd3;  6'd14: sum=3'd3;  6'd15: sum=3'd4;
        6'd16: sum=3'd1;  6'd17: sum=3'd2;  6'd18: sum=3'd2;  6'd19: sum=3'd3;
        6'd20: sum=3'd2;  6'd21: sum=3'd3;  6'd22: sum=3'd3;  6'd23: sum=3'd4;
        6'd24: sum=3'd2;  6'd25: sum=3'd3;  6'd26: sum=3'd3;  6'd27: sum=3'd4;
        6'd28: sum=3'd3;  6'd29: sum=3'd4;  6'd30: sum=3'd4;  6'd31: sum=3'd5;
        6'd32: sum=3'd1;  6'd33: sum=3'd2;  6'd34: sum=3'd2;  6'd35: sum=3'd3;
        6'd36: sum=3'd2;  6'd37: sum=3'd3;  6'd38: sum=3'd3;  6'd39: sum=3'd4;
        6'd40: sum=3'd2;  6'd41: sum=3'd3;  6'd42: sum=3'd3;  6'd43: sum=3'd4;
        6'd44: sum=3'd3;  6'd45: sum=3'd4;  6'd46: sum=3'd4;  6'd47: sum=3'd5;
        6'd48: sum=3'd2;  6'd49: sum=3'd3;  6'd50: sum=3'd3;  6'd51: sum=3'd4;
        6'd52: sum=3'd3;  6'd53: sum=3'd4;  6'd54: sum=3'd4;  6'd55: sum=3'd5;
        6'd56: sum=3'd3;  6'd57: sum=3'd4;  6'd58: sum=3'd4;  6'd59: sum=3'd5;
        6'd60: sum=3'd4;  6'd61: sum=3'd5;  6'd62: sum=3'd5;  6'd63: sum=3'd6;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_popcount32(
    input  wire [2:0] data_in,
    output wire [1:0] data_out
);
    reg [1:0] sum;
    always @(*) begin
        case (data_in)
        3'd0: sum=2'd0;   3'd1: sum=2'd1;   3'd2: sum=2'd1;   3'd3: sum=2'd2;
        3'd4: sum=2'd1;   3'd5: sum=2'd2;   3'd6: sum=2'd2;   3'd7: sum=2'd3;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_sum33(
    input  wire [2:0] data_in1,
    input  wire [2:0] data_in2,
    output wire [3:0] data_out
);
    reg [3:0] sum;
    always @(*) begin
        case ({data_in1, data_in2})
        6'd0:  sum=4'd0;   6'd1: sum=4'd1;   6'd2: sum=4'd2;   6'd3: sum=4'd3;
        6'd4:  sum=4'd4;   6'd5: sum=4'd5;   6'd6: sum=4'd6;   6'd7: sum=4'd7;
        6'd8:  sum=4'd1;   6'd9: sum=4'd2;  6'd10: sum=4'd3;  6'd11: sum=4'd4;
        6'd12: sum=4'd5;  6'd13: sum=4'd6;  6'd14: sum=4'd7;  6'd15: sum=4'd8;
        6'd16: sum=4'd2;  6'd17: sum=4'd3;  6'd18: sum=4'd4;  6'd19: sum=4'd5;
        6'd20: sum=4'd6;  6'd21: sum=4'd7;  6'd22: sum=4'd8;  6'd23: sum=4'd9;
        6'd24: sum=4'd3;  6'd25: sum=4'd4;  6'd26: sum=4'd5;  6'd27: sum=4'd6;
        6'd28: sum=4'd7;  6'd29: sum=4'd8;  6'd30: sum=4'd9;  6'd31: sum=4'd10;
        6'd32: sum=4'd4;  6'd33: sum=4'd5;  6'd34: sum=4'd6;  6'd35: sum=4'd7;
        6'd36: sum=4'd8;  6'd37: sum=4'd9;  6'd38: sum=4'd10; 6'd39: sum=4'd11;
        6'd40: sum=4'd5;  6'd41: sum=4'd6;  6'd42: sum=4'd7;  6'd43: sum=4'd8;
        6'd44: sum=4'd9;  6'd45: sum=4'd10; 6'd46: sum=4'd11; 6'd47: sum=4'd12;
        6'd48: sum=4'd6;  6'd49: sum=4'd7;  6'd50: sum=4'd8;  6'd51: sum=4'd9;
        6'd52: sum=4'd10; 6'd53: sum=4'd11; 6'd54: sum=4'd12; 6'd55: sum=4'd13;
        6'd56: sum=4'd7;  6'd57: sum=4'd8;  6'd58: sum=4'd9;  6'd59: sum=4'd10;
        6'd60: sum=4'd11; 6'd61: sum=4'd12; 6'd62: sum=4'd13; 6'd63: sum=4'd14;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_popcount #(
    parameter MODEL = 1,
    parameter N     = 1,
    parameter M     = $clog2(N+1)
) (
    input  wire [N-1:0] data_in,
    output wire [M-1:0] data_out
);
    if (N == 1) begin : g_passthru
        assign data_out = data_in;
    end else if (N <= 3) begin : g_popcount3
        reg [2:0] t_in;
        wire [1:0] t_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount32 pc32(t_in, t_out);
        assign data_out = t_out[M-1:0];
    end else if (N <= 6) begin : g_popcount6
        reg [5:0] t_in;
        wire [2:0] t_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63(t_in, t_out);
        assign data_out = t_out[M-1:0];
    end else if (N <= 9) begin : g_popcount9
        reg [8:0] t_in;
        wire [4:0] t1_out;
        wire [3:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63(t_in[5:0], t1_out[2:0]);
        VX_popcount32 pc32(t_in[8:6], t1_out[4:3]);
        VX_sum33 sum33(t1_out[2:0], {1'b0, t1_out[4:3]}, t2_out);
        assign data_out = t2_out[M-1:0];
    end else if (N <= 12) begin : g_popcount12
        reg [11:0] t_in;
        wire [5:0] t1_out;
        wire [3:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63a(t_in[5:0],  t1_out[2:0]);
        VX_popcount63 pc63b(t_in[11:6], t1_out[5:3]);
        VX_sum33 sum33(t1_out[2:0], t1_out[5:3], t2_out);
        assign data_out = t2_out[M-1:0];
    end else if (N <= 18) begin : g_popcount18
        reg [17:0] t_in;
        wire [8:0] t1_out;
        wire [5:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63a(t_in[5:0],   t1_out[2:0]);
        VX_popcount63 pc63b(t_in[11:6],  t1_out[5:3]);
        VX_popcount63 pc63c(t_in[17:12], t1_out[8:6]);
        VX_popcount32 pc32a({t1_out[0], t1_out[3], t1_out[6]}, t2_out[1:0]);
        VX_popcount32 pc32b({t1_out[1], t1_out[4], t1_out[7]}, t2_out[3:2]);
        VX_popcount32 pc32c({t1_out[2], t1_out[5], t1_out[8]}, t2_out[5:4]);
        assign data_out = {2'b0,t2_out[1:0]} + {1'b0,t2_out[3:2],1'b0} + {t2_out[5:4],2'b0};
    end else if (MODEL == 1) begin : g_model1
        localparam PN = 1 << $clog2(N);
        localparam LOGPN = $clog2(PN);
        wire [M-1:0] tmp [LOGPN-1:0][PN-1:0];
        for (genvar j = 0; j < LOGPN; ++j) begin
            localparam D = j + 1;
            localparam Q = (D < LOGPN) ? (D + 1) : M;
            for (genvar i = 0; i < (1 << (LOGPN-j-1)); ++i) begin
                localparam l = i * 2;
                localparam r = i * 2 + 1;
                wire [Q-1:0] res;
                if (j == 0) begin
                    if (r < N) begin
                        assign res = data_in[l] + data_in[r];
                    end else if (l < N) begin
                        assign res = 2'(data_in[l]);
                    end else begin
                        assign res = 2'b0;
                    end
                end else begin
                    assign res = D'(tmp[j-1][l]) + D'(tmp[j-1][r]);
                end
                assign tmp[j][i] = M'(res);
            end
        end
        assign data_out = tmp[LOGPN-1][0];
    end else begin : g_model2
        reg [M-1:0] cnt_w;
        always @(*) begin
            cnt_w = '0;
            for (integer i = 0; i < N; ++i) begin
                cnt_w = cnt_w + M'(data_in[i]);
            end
        end
        assign data_out = cnt_w;
    end
endmodule
module VX_tcu_tfr_acc import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N  = 5,
    parameter WO = 30,
    parameter POST_REDUCE = 0
) (
    input  wire                 clk,
    input  wire                 valid_in,
    input  wire [31:0]          req_id,
    input  wire [N-1:0][WO-1:0] sigs_in,
    input  wire [N-1:0]         sticky_in,
    input  wire [N-1:0]         fp_negs,
    input  wire                 post_enable,
    input  wire [2:0][WO-1:0]   post_operands,
    input  wire [2:0]           post_negatives,
    output wire [1:0][WO-1:0]   reduced_sigs,
    output wire [WO-1:0]        sum_out,
    output wire [WO-1:0]        sig_out,    
    output wire                 sign_out,   
    output wire                 sticky_out
);
    wire [$clog2(N+1)-1:0] fp_neg_count;
    VX_popcount #(
        .N (N)
    ) fp_neg_popcount (
        .data_in  (fp_negs),
        .data_out (fp_neg_count)
    );
    wire [N:0][WO-1:0] sig_operands;
    for (genvar i = 0; i < N; ++i) begin : g_ops
        assign sig_operands[i] = sigs_in[i];
    end
    assign sig_operands[N] = WO'(fp_neg_count);
    wire [WO-1:0] sum_vec;
    wire [WO-1:0] carry_vec;
    VX_csa_tree #(
        .N (N+1),
        .W (WO),
        .S (WO)
    ) sig_csa (
        .operands (sig_operands),
        .sum      (sum_vec),
        .carry    (carry_vec)
    );
    assign reduced_sigs = {carry_vec, sum_vec};
    wire [WO-1:0] final_sum, final_carry;
    if (POST_REDUCE) begin : g_post_reduction
        wire [1:0] correction = 2'(post_negatives[0]) + 2'(post_negatives[1]) + 2'(post_negatives[2]);
        wire [3:0][WO-1:0] terms = {WO'(correction), post_operands};
        wire [WO-1:0] post_sum, post_carry;
        VX_csa_tree #(.N (4), .W (WO), .S (WO)) reduction (
            .operands (terms), .sum (post_sum), .carry (post_carry)
        );
        assign final_sum = post_enable ? post_sum : sum_vec;
        assign final_carry = post_enable ? post_carry : carry_vec;
    end else begin : g_direct_reduction
        assign final_sum = sum_vec;
        assign final_carry = carry_vec;
    end
    wire [WO-1:0] sig_pos;
    VX_ks_adder #(
        .N (WO),
        .BYPASS (0)
    ) final_adder (
        .cin   (1'b0),
        .dataa (final_sum),
        .datab (final_carry),
        .sum   (sig_pos),
        . cout ()
    );
    wire [WO-1:0] sig_neg_raw;
    VX_ks_adder #(
        .N (WO),
        .BYPASS (0)
    ) neg_adder (
        .cin   (1'b1),
        .dataa (~final_sum),
        .datab (~final_carry),
        .sum   (sig_neg_raw),
        . cout ()
    );
    wire [WO-1:0] sig_neg = sig_neg_raw + WO'(1);
    assign sign_out = sig_pos[WO-1];
    assign sum_out  = sig_pos;
    assign sig_out  = sign_out ? sig_neg : sig_pos;
    assign sticky_out = |sticky_in;
endmodule
module VX_paired_shift_jam #(
    parameter LW = 26,
    parameter AW = 8
) (
    input  wire [2*LW-1:0]   data_in,
    input  wire [1:0][AW-1:0] amount,
    input  wire              joined,
    output wire [2*LW-1:0]   data_out,
    output wire [1:0]        sticky
);
    localparam W = 2 * LW;
    localparam LEVELS = $clog2(W);
    wire [LEVELS:0][W-1:0] stage;
    wire [LEVELS:0][1:0] lost;
    assign stage[0] = data_in;
    assign lost[0] = '0;
    for (genvar s = 0; s < LEVELS; ++s) begin : g_stage
        localparam D = 1 << s;
        for (genvar i = 0; i < W; ++i) begin : g_bit
            localparam LANE = i / LW;
            wire control = joined ? amount[0][s] : amount[LANE][s];
            wire incoming;
            if (i+D >= W) begin : g_outside
                assign incoming = 1'b0;
            end else if (i/LW != (i+D)/LW) begin : g_boundary
                assign incoming = joined && stage[s][i+D];
            end else begin : g_inside
                assign incoming = stage[s][i+D];
            end
            assign stage[s+1][i] = control ? incoming : stage[s][i];
        end
        for (genvar q = 0; q < 2; ++q) begin : g_sticky
            localparam LOST_W = D < LW ? D : LW;
            wire lane_lost = |stage[s][q*LW +: LOST_W];
            wire full_lost = |stage[s][D-1:0];
            assign lost[s+1][q] = joined
                               ? ((q == 0) && (lost[s][0] || (amount[0][s] && full_lost)))
                               : (lost[s][q] || (amount[q][s] && lane_lost));
        end
    end
    for (genvar q = 0; q < 2; ++q) begin : g_output
        wire over = joined ? amount[0] >= AW'(W) : amount[q] >= AW'(LW);
        assign data_out[q*LW +: LW] = over ? '0 : stage[LEVELS][q*LW +: LW];
        assign sticky[q] = joined ? ((q == 0) && (over ? (|data_in) : lost[LEVELS][0]))
                                 : (over ? (|data_in[q*LW +: LW]) : lost[LEVELS][q]);
    end
endmodule
module VX_tcu_tfr_align import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N     = 5,
    parameter WI    = 25,
    parameter WO    = WI + 5,
    parameter SHARED_SHIFT = 0
) (
    input  wire                 clk,
    input  wire                 valid_in,
    input  wire [31:0]          req_id,
    input  wire [N-1:0][TCU_EXP_BITS-1:0] exponents,
    input  wire [N-1:0]         sel_exp,
    input  wire [N-2:0]         lane_mask,
    input  wire [N-1:0][WI-1:0] sigs_in,
    input  wire                 is_int,
    input  wire                 external_shift,
    input  wire [51:0]          external_data,
    input  wire [7:0]           external_amount,
    output wire [51:0]          external_result,
    output wire                 external_sticky,
    output logic [TCU_EXP_BITS-1:0] max_exp,
    output wire [N-1:0][WO-1:0] sigs_out,
    output wire [N-1:0]         sticky_bits,
    output wire [N-1:0]         fp_negs
);
    localparam MAX_PRE_SHIFT = WI - 23;
    localparam SHIFT_MAG_W   = (WI - 1) + MAX_PRE_SHIFT;
    wire [N:0][TCU_EXP_BITS-1:0] or_red;
    wire [N-1:0][7:0] shift_amts;
    wire [N-1:0][SHIFT_MAG_W-1:0] preshift_magnitudes;
    wire [51:0] paired_result;
    wire [1:0] paired_sticky;
    if (SHARED_SHIFT) begin : g_shared_shift
        VX_paired_shift_jam shifter (
            .data_in  (external_shift ? external_data : {preshift_magnitudes[N-2], preshift_magnitudes[N-3]}),
            .amount   (external_shift ? {external_amount, external_amount} : {shift_amts[N-2], shift_amts[N-3]}),
            .joined   (external_shift),
            .data_out (paired_result),
            .sticky   (paired_sticky)
        );
    end else begin : g_no_shared_shift
        assign paired_result = '0;
        assign paired_sticky = '0;
    end
    assign external_result = paired_result;
    assign external_sticky = paired_sticky[0];
    assign or_red[0] = {TCU_EXP_BITS{1'b0}};
    for (genvar i = 0; i < N; i++) begin : g_or_red
        assign or_red[i+1] = or_red[i] | (sel_exp[i] ? exponents[i] : {TCU_EXP_BITS{1'b0}});
    end
    assign max_exp = or_red[N];
    for (genvar i = 0; i < N; i++) begin : g_shift_amts
        wire [TCU_EXP_BITS-1:0] shift_full = max_exp - exponents[i];
        if (TCU_EXP_BITS > 8) begin : g_sat
            assign shift_amts[i] = (|shift_full[TCU_EXP_BITS-1:8]) ? 8'hFF : shift_full[7:0];
        end else begin : g_no_sat
            assign shift_amts[i] = 8'(shift_full);
        end
    end
    for (genvar i = 0; i < N; ++i) begin : g_align_lanes
        wire [7:0] shift_amt = shift_amts[i];
        wire lane_en;
        if (i == N-1) begin : g_c_en
            assign lane_en = 1'b1;  
        end else begin : g_lane_en
            assign lane_en = lane_mask[i];
        end
        wire in_sign = sigs_in[i][WI-1];
        wire [WI-2:0] in_mag = sigs_in[i][WI-2:0];
        wire [SHIFT_MAG_W-1:0] mag_shifted;
        assign preshift_magnitudes[i] = mag_shifted;
        if (i == N-1) begin : g_c_term
            assign mag_shifted = { {(MAX_PRE_SHIFT - (WI - 24)){1'b0}}, in_mag, {(WI - 24){1'b0}} };
        end else begin : g_prod_term
            assign mag_shifted = { in_mag, {(WI - 23){1'b0}} };
        end
        wire is_overshift = (shift_amt >= 8'(SHIFT_MAG_W));
        wire [SHIFT_MAG_W-1:0] shift_res_full;
        if (SHARED_SHIFT && (i == N-3 || i == N-2)) begin : g_paired
            assign shift_res_full = paired_result[(i-(N-3))*SHIFT_MAG_W +: SHIFT_MAG_W];
            assign sticky_bits[i] = lane_en && paired_sticky[i-(N-3)];
        end else begin : g_ordinary
            assign shift_res_full = mag_shifted >> shift_amt;
            wire [SHIFT_MAG_W-1:0] sticky_check_shift = mag_shifted << (8'(SHIFT_MAG_W) - shift_amt);
            assign sticky_bits[i] = lane_en & (is_overshift ? (|mag_shifted) : (|sticky_check_shift));
        end
        wire [WI:0] adj_mag = is_overshift ? '0 : shift_res_full[WI:0];
        wire fp_neg = in_sign & lane_en & ~is_int;
        wire [WO-1:0] fp_mag  = WO'(adj_mag) & {WO{lane_en}};
        wire [WO-1:0] fp_form = fp_neg ? ~fp_mag : fp_mag;
        wire [WO-1:0] int_form = WO'($signed(sigs_in[i])) & {WO{lane_en}};
        assign sigs_out[i] = is_int ? int_form : fp_form;
        assign fp_negs[i]  = fp_neg;
    end
endmodule
module VX_pipe_register #(
    parameter DATAW  = 1,
    parameter RESETW = 0,
    parameter DEPTH  = 1,
    parameter [(((RESETW) > 0) ? (RESETW) : 1)-1:0] INIT_VALUE = {(((RESETW) > 0) ? (RESETW) : 1){1'b0}}
) (
    input wire              clk,
    input wire              reset,
    input wire              enable,
    input wire [DATAW-1:0]  data_in,
    output wire [DATAW-1:0] data_out
);
    if (DEPTH == 0) begin : g_passthru
        assign data_out = data_in;
    end else begin : g_pipe
        wire [DEPTH-1:0][DATAW-1:0] pipe_out;
        if (RESETW == DATAW) begin : g_full_reset
            reg [DEPTH-1:0][DATAW-1:0] pipe;
            always_ff @(posedge clk) begin
                if (reset) begin
                    pipe <= {DEPTH{INIT_VALUE}};
                end else if (enable) begin
                    pipe[0] <= data_in;
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe[i] <= pipe[i-1];
                    end
                end
            end
            assign pipe_out = pipe;
        end else if (RESETW != 0) begin : g_partial_reset
            localparam FREEW = DATAW - RESETW;
            reg [DEPTH-1:0][RESETW-1:0] pipe_rst;
            reg [DEPTH-1:0][FREEW-1:0]  pipe_free;
            always_ff @(posedge clk) begin
                if (reset) begin
                    for (int i = 0; i < DEPTH; ++i) begin
                        pipe_rst[i] <= INIT_VALUE;
                    end
                end else if (enable) begin
                    pipe_rst[0] <= data_in[DATAW-1 : FREEW];
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe_rst[i] <= pipe_rst[i-1];
                    end
                end
            end
            always_ff @(posedge clk) begin
                if (enable) begin
                    pipe_free[0] <= data_in[FREEW-1 : 0];
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe_free[i] <= pipe_free[i-1];
                    end
                end
            end
            for (genvar i = 0; i < DEPTH; ++i) begin : g_join
                assign pipe_out[i] = {pipe_rst[i], pipe_free[i]};
            end
        end else begin : g_no_reset
            reg [DEPTH-1:0][DATAW-1:0] pipe;
            always_ff @(posedge clk) begin
                if (enable) begin
                    pipe[0] <= data_in;
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe[i] <= pipe[i-1];
                    end
                end
            end
            assign pipe_out = pipe;
        end
        assign data_out = pipe_out[DEPTH-1];
    end
endmodule
module VX_tcu_tfr_exc_reduce import VX_tcu_pkg::*; #(
    parameter TCK = 4
) (
    input  fedp_excep_t [TCK:0] exc_in,
    output fedp_excep_t         exc_out
);
    logic [TCK-1:0] lane_nan;
    logic [TCK-1:0] lane_inf;
    logic [TCK-1:0] lane_sign;
    for (genvar i = 0; i < TCK; ++i) begin : g_unpack
        assign lane_nan[i]  = exc_in[i].is_nan;
        assign lane_inf[i]  = exc_in[i].is_inf;
        assign lane_sign[i] = exc_in[i].sign;
    end
    wire c_is_nan = exc_in[TCK].is_nan;
    wire c_is_inf = exc_in[TCK].is_inf;
    wire c_sign   = exc_in[TCK].sign;
    wire [TCK-1:0] p_pos_inf = lane_inf & ~lane_sign;
    wire [TCK-1:0] p_neg_inf = lane_inf &  lane_sign;
    wire has_pos = (|p_pos_inf) | (c_is_inf & ~c_sign);
    wire has_neg = (|p_neg_inf) | (c_is_inf &  c_sign);
    wire res_nan = (|lane_nan) | c_is_nan | (has_pos & has_neg);
    wire res_inf = (has_pos | has_neg) & ~res_nan;
    assign exc_out.is_nan = res_nan;
    assign exc_out.is_inf = res_inf;
    assign exc_out.sign   = has_neg & ~has_pos;
endmodule
module VX_tcu_tfr_lane_mask import VX_tcu_pkg::*; #(
    parameter N   = 2,
    parameter TCK = 2 * N
) (
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [4:0]                fmt_s,
    output logic [TCK-1:0]          lane_mask
);
    wire [TCK-1:0] mask_32;
    wire [TCK-1:0] mask_16;
    wire [TCK-1:0] mask_8;
    wire [TCK-1:0] mask_4;
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_32
        if ((i % 2) == 0) begin : g_even_lane
            assign mask_32[i] = vld_mask[i * 4];
        end else begin : g_odd_lane
            assign mask_32[i] = 1'b0;
        end
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_16
        assign mask_16[i] = vld_mask[i * 4];
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_8
        assign mask_8[i] = vld_mask[i * 4 + 0] | vld_mask[i * 4 + 2];
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_4
        assign mask_4[i] = vld_mask[i * 4 + 0]
                         | vld_mask[i * 4 + 1]
                         | vld_mask[i * 4 + 2]
                         | vld_mask[i * 4 + 3];
    end
    always_comb begin
        case (fmt_s)
            TCU_FP16_ID,
            TCU_BF16_ID: lane_mask = mask_16;
            TCU_TF32_ID: lane_mask = mask_32;
            TCU_FP8_ID,
            TCU_BF8_ID:  lane_mask = mask_8;
            TCU_MXFP8_ID,
            TCU_MXBF8_ID:lane_mask = mask_8;
            TCU_MXFP4_ID:lane_mask = mask_4;
            TCU_NVFP4_ID:lane_mask = mask_4;
            default:     lane_mask = '0;
        endcase
    end
endmodule
module VX_tcu_tfr_max_exp import VX_tcu_pkg::*; #(
    parameter N     = 5,
    parameter WIDTH = 8
) (
    input  wire [N-1:0][WIDTH-1:0] exponents,
    output wire [N-1:0]            sel_exp
);
    wire [N-2:0][N-2:0] sign_mat;
    for (genvar i = 0; i < N-1; i++) begin : g_row
        for (genvar j = 0; j < N-1; j++) begin : g_col
            if (j < i) begin : g_lower
                assign sign_mat[i][j] = ~sign_mat[j][i];
            end else begin : g_upper
                assign sign_mat[i][j] = (exponents[i] < exponents[j+1]);
            end
        end
    end
    for (genvar i = 0; i < N; i++) begin : g_index
        wire and_left, or_right;
        if (i == 0) begin : g_first
            assign and_left = 1'b1;
        end else begin : g_and_left
            wire [i-1:0] left_signals;
            for (genvar jl = 0; jl < i; jl++) begin : g_left
                assign left_signals[jl] = sign_mat[jl][i-1];
            end
            assign and_left = &left_signals;
        end
        if (i == N-1) begin : g_last
            assign or_right = 1'b0;
        end else begin : g_or_right
            wire [N-2-i:0] right_signals;
            for (genvar jr = i+1; jr < N; jr++) begin : g_right
                assign right_signals[jr-i-1] = sign_mat[i][jr-1];
            end
            assign or_right = |right_signals;
        end
        assign sel_exp[i] = and_left & (~or_right);
    end
endmodule
module VX_tcu_tfr_classifier import VX_tcu_pkg::*; #(
    parameter EXP_W = 8,
    parameter MAN_W = 23
) (
    input wire [EXP_W-1:0] exp,
    input wire [MAN_W-1:0] man,
    output fedp_class_t    cls
);
    wire exp_zero = ~|exp;
    wire exp_ones = &exp;
    wire man_non_zero = |man;
    wire man_zero     = ~man_non_zero;
    assign cls.is_zero = exp_zero & man_zero;
    assign cls.is_sub  = exp_zero & man_non_zero;
    assign cls.is_inf  = exp_ones & man_zero;
    assign cls.is_nan  = exp_ones & man_non_zero;
endmodule
module VX_wallace_mul #(
    parameter N = 8,
    parameter P = 2 * N,
    parameter CPA_KS = 1  
) (
    input wire [N-1:0]  a,
    input wire [N-1:0]  b,
    output wire [P-1:0] p
);
    wire [N-1:0][2*N-1:0] pp;     
    for (genvar g = 0; g < N; g++) begin: g_pp_loop
        for (genvar h = 0; h < N; h++) begin: g_and_loop
            assign pp[g][h+g] = a[h] & b[g];
        end
        if (g != 0) begin : g_bit_fill
            assign pp[g][g-1:0] = {g{1'b0}};     
        end
        assign pp[g][2*N-1:N+g] = {(N-g){1'b0}};     
    end
    wire [P-1:0] sum_vec, carry_vec;
    VX_csa_tree #(
        .N (N),
        .W (2*N),
        .S (P)
    ) pp_acc (
        .operands (pp),
        .sum  (sum_vec),
        .carry(carry_vec)
    );
    VX_ks_adder #(
        .N(P),
        .BYPASS(CPA_KS == 0)
    ) final_add (
        .dataa(sum_vec),
        .datab(carry_vec),
        .cin(1'b0),
        .sum(p),
        . cout ()
    );
endmodule
module VX_tcu_tfr_wmul #(
    parameter N        = 4,        
    parameter M        = N,        
    parameter LANES    = 1,        
    parameter SHARED_B = 0,        
    parameter P        = N + M,    
    parameter USE_DSP  = 0,
    parameter OUT_REG  = 0         
) (
    input  wire                    clk,
    input  wire                    enable,
    input  wire [LANES-1:0][N-1:0] a,
    input  wire [LANES-1:0][M-1:0] b,
    output wire [LANES-1:0][P-1:0] p
);
    if (USE_DSP == 0) begin : g_lut
        wire [LANES-1:0][P-1:0] p_w;
        for (genvar i = 0; i < LANES; ++i) begin : g_mul
            localparam BI = (SHARED_B != 0) ? 0 : i;
            if (N == M) begin : g_wal
                VX_wallace_mul #(
                    .N (N),
                    .P (P),
                    .CPA_KS (!0)
                ) u_mul (
                    .a (a[i]),
                    .b (b[BI]),
                    .p (p_w[i])
                );
            end else begin : g_inf
                assign p_w[i] = a[i] * b[BI];
            end
        end
        if (SHARED_B != 0 && LANES > 1) begin : g_unused
        end
        VX_pipe_register #(
            .DATAW (LANES * P),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (p_w),
            .data_out (p)
        );
    end else if (LANES == 1) begin : g_dsp1
        (* use_dsp = "yes" *) wire [P-1:0] prod = a[0] * b[0];
        VX_pipe_register #(
            .DATAW (P),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (prod),
            .data_out (p[0])
        );
    end else if (SHARED_B != 0) begin : g_dsp_shared
        localparam K  = P;                   
        localparam AW = K + N;
        wire [AW-1:0]      pa   = {a[1], {(K-N){1'b0}}, a[0]};
        (* use_dsp = "yes" *) wire [AW+M-1:0] prod = pa * b[0];
        wire [AW+M-1:0] prod_r;
        VX_pipe_register #(
            .DATAW (AW + M),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (prod),
            .data_out (prod_r)
        );
        assign p[0] = prod_r[P-1:0];
        assign p[1] = prod_r[K +: P];
    end else begin : g_dsp_indep
        localparam K  = P + 1;               
        localparam AW = K + N;
        localparam BW = K + M;
        wire [AW-1:0]      pa   = {a[1], {(K-N){1'b0}}, a[0]};
        wire [BW-1:0]      pb   = {b[1], {(K-M){1'b0}}, b[0]};
        (* use_dsp = "yes" *) wire [AW+BW-1:0] prod = pa * pb;
        wire [AW+BW-1:0] prod_r;
        VX_pipe_register #(
            .DATAW (AW + BW),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (prod),
            .data_out (prod_r)
        );
        assign p[0] = prod_r[P-1:0];
        assign p[1] = prod_r[2*K +: P];
    end
endmodule
module VX_tcu_tfr_mul_f16 import VX_tcu_pkg::*;
#(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0,  
    parameter EXTERNAL_MUL = 0
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output wire [TCK-1:0][10:0]     mantissa_a,
    output wire [TCK-1:0][10:0]     mantissa_b,
    input wire [TCK-1:0][21:0]      external_products,
    output wire  [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions
);
    if (!EXTERNAL_MUL) begin : g_unused_external
    end
    logic sig_en;
    always_comb begin
        case (fmt_f)
            TCU_FP16_ID,
            TCU_BF16_ID: sig_en = 1'b1;
            TCU_TF32_ID: sig_en = 1'b1;
            default:     sig_en = 1'b0;
        endcase
    end
    wire sig_en_r;
    VX_pipe_register #(
        .DATAW (1),
        .DEPTH (PROD_REG)
    ) pipe_sig_en (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (sig_en),
        .data_out (sig_en_r)
    );
    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + S_FP32 - S_SUPER - W + WA - 1 + 128;
    localparam E_TF32 = VX_tcu_pkg::exp_bits(TCU_TF32_ID);
    localparam S_TF32 = VX_tcu_pkg::sign_pos(TCU_TF32_ID);
    localparam B_TF32 = (1 << (E_TF32 - 1)) - 1;
    localparam [7:0] BIAS_CONST_TF32 = 8'(BIAS_BASE - 2*B_TF32);
    localparam E_FP16 = VX_tcu_pkg::exp_bits(TCU_FP16_ID);
    localparam S_FP16 = VX_tcu_pkg::sign_pos(TCU_FP16_ID);
    localparam B_FP16 = (1 << (E_FP16 - 1)) - 1;
    localparam [7:0] BIAS_CONST_FP16 = 8'(BIAS_BASE - 2*B_FP16);
    localparam E_BF16 = VX_tcu_pkg::exp_bits(TCU_BF16_ID);
    localparam S_BF16 = VX_tcu_pkg::sign_pos(TCU_BF16_ID);
    localparam B_BF16 = (1 << (E_BF16 - 1)) - 1;
    localparam [7:0] BIAS_CONST_BF16 = 8'(BIAS_BASE - 2*B_BF16);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire lane_valid = vld_mask[i*4];
        localparam OFF_16 = (i % 2) * 16;
        logic [7:0] raw_ea, raw_eb;
        logic [9:0] raw_ma, raw_mb;
        logic       raw_sa, raw_sb;
        logic [7:0] bias_sel;
        always_comb begin
            case (fmt_f)
                TCU_FP16_ID: begin
                    raw_ea    = 8'(a_row[i/2][S_FP16-1+OFF_16 -: E_FP16]);
                    raw_eb    = 8'(b_col[i/2][S_FP16-1+OFF_16 -: E_FP16]);
                    raw_ma    = a_row[i/2][9+OFF_16 -: 10];
                    raw_mb    = b_col[i/2][9+OFF_16 -: 10];
                    raw_sa    = a_row[i/2][15+OFF_16];
                    raw_sb    = b_col[i/2][15+OFF_16];
                    bias_sel  = BIAS_CONST_FP16;
                end
                TCU_BF16_ID: begin
                    raw_ea    = a_row[i/2][S_BF16-1+OFF_16 -: E_BF16];
                    raw_eb    = b_col[i/2][S_BF16-1+OFF_16 -: E_BF16];
                    raw_ma    = {a_row[i/2][6+OFF_16 -: 7], 3'b0};
                    raw_mb    = {b_col[i/2][6+OFF_16 -: 7], 3'b0};
                    raw_sa    = a_row[i/2][15+OFF_16];
                    raw_sb    = b_col[i/2][15+OFF_16];
                    bias_sel  = BIAS_CONST_BF16;
                end
                TCU_TF32_ID: begin
                    if ((i % 2) == 0) begin
                        raw_ea    = a_row[i/2][S_TF32-1 -: E_TF32];
                        raw_eb    = b_col[i/2][S_TF32-1 -: E_TF32];
                        raw_ma    = a_row[i/2][9:0];
                        raw_mb    = b_col[i/2][9:0];
                        raw_sa    = a_row[i/2][18];
                        raw_sb    = b_col[i/2][18];
                        bias_sel  = BIAS_CONST_TF32;
                    end else begin
                        raw_ea    = '0;
                        raw_eb    = '0;
                        raw_ma    = '0;
                        raw_mb    = '0;
                        raw_sa    = '0;
                        raw_sb    = '0;
                        bias_sel  = '0;
                    end
                end
                default: begin
                    raw_ea    = '0;
                    raw_eb    = '0;
                    raw_ma    = '0;
                    raw_mb    = '0;
                    raw_sa    = '0;
                    raw_sb    = '0;
                    bias_sel  = '0;
                end
            endcase
        end
        fedp_class_t cls_a_f16;
        VX_tcu_tfr_classifier #(
            .EXP_W (E_FP16),
            .MAN_W (10)
        ) class_a_f16 (
            .exp (raw_ea[E_FP16-1:0]),
            .man (raw_ma),
            .cls (cls_a_f16)
        );
        fedp_class_t cls_b_f16;
        VX_tcu_tfr_classifier #(
            .EXP_W (E_FP16),
            .MAN_W (10)
        ) class_b_f16 (
            .exp (raw_eb[E_FP16-1:0]),
            .man (raw_mb),
            .cls (cls_b_f16)
        );
        fedp_class_t cls_a_wide;
        VX_tcu_tfr_classifier #(
            .EXP_W (8),
            .MAN_W (10)
        ) class_a_wide (
            .exp (raw_ea),
            .man (raw_ma),
            .cls (cls_a_wide)
        );
        fedp_class_t cls_b_wide;
        VX_tcu_tfr_classifier #(
            .EXP_W (8),
            .MAN_W (10)
        ) class_b_wide (
            .exp (raw_eb),
            .man (raw_mb),
            .cls (cls_b_wide)
        );
        fedp_class_t cls_a;
        fedp_class_t cls_b;
        always_comb begin
            if (fmt_f == TCU_FP16_ID) begin
                cls_a = cls_a_f16;
                cls_b = cls_b_f16;
            end else begin
                cls_a = cls_a_wide;
                cls_b = cls_b_wide;
            end
        end
        wire is_ea_zero = ~|raw_ea;
        wire is_eb_zero = ~|raw_eb;
        wire [7:0] ea_sel = is_ea_zero ? 8'b1 : raw_ea;
        wire [7:0] eb_sel = is_eb_zero ? 8'b1 : raw_eb;
        wire [10:0] ma_sel = {~is_ea_zero, raw_ma};
        wire [10:0] mb_sel = {~is_eb_zero, raw_mb};
        wire sign_sel = raw_sa ^ raw_sb;
        wire zero_sel = cls_a.is_zero | cls_b.is_zero;
        wire nan_in = cls_a.is_nan | cls_b.is_nan;
        wire inf_z  = (cls_a.is_inf & cls_b.is_zero) | (cls_a.is_zero & cls_b.is_inf);
        wire inf_op = cls_a.is_inf | cls_b.is_inf;
        wire nan_sel = nan_in | inf_z;
        wire inf_sel = inf_op & ~inf_z;
        wire [EXP_W-1:0] exp_final = EXP_W'(bias_sel) + EXP_W'(ea_sel) + EXP_W'(eb_sel);
        assign result_exp[i] = (~zero_sel && lane_valid) ? exp_final : '0;
        wire [21:0] man_prod;
        assign mantissa_a[i] = ma_sel;
        assign mantissa_b[i] = mb_sel;
        if (EXTERNAL_MUL) begin : g_external
            assign man_prod = external_products[i];
        end else begin : g_internal
            VX_tcu_tfr_wmul #(
                .N       (11),
                .USE_DSP (USE_DSP),
                .OUT_REG (PROD_REG)
            ) wtmul (
                .clk    (clk),
                .enable (enable),
                .a      (ma_sel),
                .b      (mb_sel),
                .p      (man_prod)
            );
        end
        wire sign_sel_r;
        VX_pipe_register #(
            .DATAW (1),
            .DEPTH (PROD_REG)
        ) pipe_sign (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (sign_sel),
            .data_out (sign_sel_r)
        );
        assign result_sig[i] = sig_en_r ? {sign_sel_r, man_prod, 2'b0} : '0;
        assign exceptions[i].is_nan = nan_sel && lane_valid;
        assign exceptions[i].is_inf = inf_sel && lane_valid;
        assign exceptions[i].sign   = sign_sel;
    end
endmodule
module VX_tcu_tfr_mul_f4 import VX_tcu_pkg::*;
#(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0   
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    input wire [7:0]                sf_a,
    input wire [7:0]                sf_b,
    output logic [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions,
    output logic [TCK-1:0]            sig_zero
);
    wire [3:0] fmt_f_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_f),
        .data_out (fmt_f_r)
    );
    wire [TCK-1:0][24:0]      result_sig_mxfp4;
    wire [TCK-1:0][EXP_W-1:0] result_exp_mxfp4;
    fedp_excep_t [TCK-1:0]    exceptions_mxfp4;
    wire [TCK-1:0]            sig_zero_mxfp4;
    localparam F32_BIAS_MXFP4  = 127;
    localparam S_FP32_MXFP4    = 23;
    localparam S_SUPER_MXFP4   = 22;
    localparam BIAS_BASE_MXFP4 = F32_BIAS_MXFP4 + 2*(S_FP32_MXFP4 - S_SUPER_MXFP4) - W + WA - 1 + 128;
    localparam SIG_SHIFT_MXFP4 = 11;
    localparam F4_EXP_BIAS_MXFP4   = 1;
    localparam EXP_TERM_W_MXFP4    = 6;
    localparam EXP_TERM_BIAS_MXFP4 = 1 << (EXP_TERM_W_MXFP4 - 1);
    localparam EXP_COMP_MXFP4      = -(2 * F4_EXP_BIAS_MXFP4 + 10);
    localparam [EXP_TERM_W_MXFP4-1:0] EXP_ADJ_MXFP4 = EXP_TERM_W_MXFP4'(EXP_TERM_BIAS_MXFP4 + EXP_COMP_MXFP4);
    localparam [EXP_W-1:0] EXP_BASE_BIASED_MXFP4 = EXP_W'(BIAS_BASE_MXFP4 + EXP_COMP_MXFP4);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane_mxfp4
        localparam K_WORD = i / 2;
        wire [3:0][23:0] term_mag_shifted;
        wire [3:0][EXP_TERM_W_MXFP4-1:0] term_exp_biased;
        wire [3:0] term_valid;
        wire [3:0] term_sign;
        wire [3:0][1:0] a_man, b_man;
        wire [3:0][3:0] f4_man_prod;
        for (genvar j = 0; j < 4; ++j) begin : g_term
            localparam OFF = (i % 2) * 16 + j * 4;
            wire lane_valid = vld_mask[i * 4 + j];
            wire [3:0] raw_a = a_row[K_WORD][OFF +: 4];
            wire [3:0] raw_b = b_col[K_WORD][OFF +: 4];
            wire a_zero = ~|raw_a[2:0];
            wire b_zero = ~|raw_b[2:0];
            assign term_valid[j] = lane_valid && !a_zero && !b_zero;
            assign term_sign[j]  = raw_a[3] ^ raw_b[3];
            assign a_man[j] = ~|raw_a[2:1] ? 2'b01 : {1'b1, raw_a[0]};
            assign b_man[j] = ~|raw_b[2:1] ? 2'b01 : {1'b1, raw_b[0]};
            wire [1:0] a_exp, b_exp;
            assign a_exp[0] = raw_a[2] & ~raw_a[1];
            assign a_exp[1] = raw_a[2] & raw_a[1];
            assign b_exp[0] = raw_b[2] & ~raw_b[1];
            assign b_exp[1] = raw_b[2] & raw_b[1];
            wire signed [5:0] exp_biased_raw = 6'(10'(EXP_ADJ_MXFP4)
                                                + 10'(a_exp)
                                                + 10'(b_exp));
            assign term_exp_biased[j] = term_valid[j] ? exp_biased_raw : '0;
        end
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP),
            .OUT_REG (PROD_REG)
        ) f4m01 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[1:0]),
            .b (b_man[1:0]),
            .p (f4_man_prod[1:0])
        );
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP),
            .OUT_REG (PROD_REG)
        ) f4m23 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[3:2]),
            .b (b_man[3:2]),
            .p (f4_man_prod[3:2])
        );
        wire [EXP_TERM_W_MXFP4-1:0] max_exp_01 = (term_exp_biased[0] >= term_exp_biased[1]) ? term_exp_biased[0] : term_exp_biased[1];
        wire [EXP_TERM_W_MXFP4-1:0] max_exp_23 = (term_exp_biased[2] >= term_exp_biased[3]) ? term_exp_biased[2] : term_exp_biased[3];
        wire [EXP_TERM_W_MXFP4-1:0] max_exp_biased = (max_exp_01 >= max_exp_23) ? max_exp_01 : max_exp_23;
        wire [3:0] term_valid_r, term_sign_r;
        wire [3:0][EXP_TERM_W_MXFP4-1:0] shift_amt_r;
        wire [3:0][EXP_TERM_W_MXFP4-1:0] shift_amt_w;
        VX_pipe_register #(
            .DATAW (4 + 4 + 4 * EXP_TERM_W_MXFP4),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({term_valid,   term_sign,   shift_amt_w}),
            .data_out ({term_valid_r, term_sign_r, shift_amt_r})
        );
        wire [3:0][26:0] term_signed;
        for (genvar j = 0; j < 4; ++j) begin : g_align
            VX_ks_adder #(
                .N(EXP_TERM_W_MXFP4),
                .BYPASS(0)
            ) shift_ksa (
                .dataa(max_exp_biased),
                .datab(~term_exp_biased[j]),
                .cin(1'b1),
                .sum(shift_amt_w[j]),
                . cout ()
            );
            assign term_mag_shifted[j] = term_valid_r[j] ? (24'(f4_man_prod[j]) << SIG_SHIFT_MXFP4) : 24'd0;
            wire [23:0] aligned_mag = (shift_amt_r[j] >= EXP_TERM_W_MXFP4'(24)) ? 24'd0 : (term_mag_shifted[j] >> shift_amt_r[j][4:0]);
            wire [26:0] aligned_ext = {3'b0, aligned_mag};
            wire [26:0] neg_term;
            VX_ks_adder #(
                .N(27),
                .BYPASS(0)
            ) term_neg_ksa (
                .dataa(~aligned_ext),
                .datab(27'd0),
                .cin(1'b1),
                .sum(neg_term),
                . cout ()
            );
            assign term_signed[j] = term_sign_r[j] ? neg_term : aligned_ext;
        end
        wire [26:0] sum_vec, carry_vec;
        VX_csa_tree #(
            .N(4),
            .W(27),
            .S(27)
        ) term_csa (
            .operands (term_signed),
            .sum      (sum_vec),
            .carry    (carry_vec)
        );
        wire [26:0] signed_sum;
        VX_ks_adder #(
            .N(27),
            .BYPASS(0)
        ) sum_ksa (
            .dataa(sum_vec),
            .datab(carry_vec),
            .cin(1'b0),
            .sum(signed_sum),
            . cout ()
        );
        wire sum_sign = signed_sum[26];
        wire [25:0] neg_sum_raw;
        VX_ks_adder #(
            .N(26),
            .BYPASS(0)
        ) sum_neg_ksa (
            .dataa(~signed_sum[25:0]),
            .datab(26'd0),
            .cin(1'b1),
            .sum(neg_sum_raw),
            . cout ()
        );
        wire [25:0] abs_sum = sum_sign ? neg_sum_raw : signed_sum[25:0];
        wire is_zero_out = ~|abs_sum;
        assign result_sig_mxfp4[i] = {sum_sign & ~is_zero_out, abs_sum[23:0]};
        assign sig_zero_mxfp4[i]   = is_zero_out;
        assign result_exp_mxfp4[i] = EXP_W'(max_exp_biased) + EXP_W'(EXP_BASE_BIASED_MXFP4)
                                  + EXP_W'(sf_a) + EXP_W'(sf_b) - EXP_W'(254);
        assign exceptions_mxfp4[i].is_nan = (sf_a == 8'hff || sf_b == 8'hff) && (|vld_mask[i*4 +: 4]);
        assign exceptions_mxfp4[i].is_inf = 1'b0;
        assign exceptions_mxfp4[i].sign   = 1'b0;
    end
    wire [TCK-1:0][24:0]      result_sig_nvfp4;
    wire [TCK-1:0][EXP_W-1:0] result_exp_nvfp4;
    fedp_excep_t [TCK-1:0]    exceptions_nvfp4;
    wire [TCK-1:0]            sig_zero_nvfp4;
    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + 2*(S_FP32 - S_SUPER) - W + WA - 1 + 128;
    localparam SIG_SHIFT = 11;
    localparam F4_EXP_BIAS     = 1;
    localparam SF_EXP_BIAS     = 7;
    localparam SF_MAN_BITS     = 3;
    localparam EXP_TERM_W      = 6;
    localparam EXP_TERM_BIAS   = 1 << (EXP_TERM_W - 1);
    localparam EXP_COMP_NVFP4  = -(2 * F4_EXP_BIAS + 2 * (SF_EXP_BIAS + SF_MAN_BITS));
    localparam [5:0] EXP_ADJ_NVFP4 = 6'(EXP_TERM_BIAS + EXP_COMP_NVFP4);
    localparam [EXP_W-1:0] EXP_BASE_BIASED = EXP_W'(BIAS_BASE + EXP_COMP_NVFP4);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane_nvfp4
        localparam K_WORD = i / 2;
        wire [3:0] sf_man_a = {(|sf_a[6:3]), sf_a[2:0]};
        wire [3:0] sf_man_b = {(|sf_b[6:3]), sf_b[2:0]};
        wire [3:0] sf_exp_a = (|sf_a[6:3]) ? sf_a[6:3] : 4'd1;
        wire [3:0] sf_exp_b = (|sf_b[6:3]) ? sf_b[6:3] : 4'd1;
        wire [7:0] sf_man_prod;
        VX_tcu_tfr_wmul #(
            .N(4),
            .USE_DSP(USE_DSP)
        ) sf_wtmul (
            .clk    (clk),
            .enable (enable),
            .a(sf_man_a),
            .b(sf_man_b),
            .p(sf_man_prod)
        );
        wire [3:0][23:0] term_mag_shifted;
        wire [3:0][5:0]  term_exp_biased;
        wire [3:0]       term_valid;
        wire [3:0]       term_sign;
        wire [3:0][1:0]  a_man, b_man;
        wire [3:0][3:0]  f4_man_prod;
        wire [3:0][11:0] term_man_prod;
        for (genvar j = 0; j < 4; ++j) begin : g_term
            localparam OFF = (i % 2) * 16 + j * 4;
            wire lane_valid = vld_mask[i * 4 + j];
            wire [3:0] raw_a = a_row[K_WORD][OFF +: 4];
            wire [3:0] raw_b = b_col[K_WORD][OFF +: 4];
            wire a_zero = ~|raw_a[2:0];
            wire b_zero = ~|raw_b[2:0];
            assign term_valid[j] = lane_valid && !a_zero && !b_zero;
            assign term_sign[j]  = raw_a[3] ^ raw_b[3];
            assign a_man[j] = ~|raw_a[2:1] ? 2'b01 : {1'b1, raw_a[0]};
            assign b_man[j] = ~|raw_b[2:1] ? 2'b01 : {1'b1, raw_b[0]};
            wire [1:0] a_exp, b_exp;
            assign a_exp[0] = raw_a[2] & ~raw_a[1];
            assign a_exp[1] = raw_a[2] & raw_a[1];
            assign b_exp[0] = raw_b[2] & ~raw_b[1];
            assign b_exp[1] = raw_b[2] & raw_b[1];
            wire [5:0] exp_sum_vec, exp_carry_vec;
            VX_csa_tree #(
                .N(5),
                .W(6),
                .S(6)
            ) exp_csa (
                .operands ({EXP_ADJ_NVFP4, 6'(sf_exp_a), 6'(sf_exp_b), 6'(a_exp), 6'(b_exp)}),
                .sum      (exp_sum_vec),
                .carry    (exp_carry_vec)
            );
            wire [5:0] exp_biased_raw;
            VX_ks_adder #(
                .N(6),
                .BYPASS(0)
            ) exp_ksa (
                .dataa(exp_sum_vec),
                .datab(exp_carry_vec),
                .cin(1'b0),
                .sum(exp_biased_raw),
                . cout ()
            );
            assign term_exp_biased[j] = term_valid[j] ? exp_biased_raw : 6'd0;
        end
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP)
        ) f4m01 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[1:0]),
            .b (b_man[1:0]),
            .p (f4_man_prod[1:0])
        );
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP)
        ) f4m23 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[3:2]),
            .b (b_man[3:2]),
            .p (f4_man_prod[3:2])
        );
        VX_tcu_tfr_wmul #(
            .N        (4),
            .M        (8),
            .LANES    (2),
            .SHARED_B (1),
            .USE_DSP  (USE_DSP),
            .OUT_REG  (PROD_REG)
        ) tm01 (
            .clk    (clk),
            .enable (enable),
            .a (f4_man_prod[1:0]),
            .b ({8'b0, sf_man_prod}),
            .p (term_man_prod[1:0])
        );
        VX_tcu_tfr_wmul #(
            .N        (4),
            .M        (8),
            .LANES    (2),
            .SHARED_B (1),
            .USE_DSP  (USE_DSP),
            .OUT_REG  (PROD_REG)
        ) tm23 (
            .clk    (clk),
            .enable (enable),
            .a (f4_man_prod[3:2]),
            .b ({8'b0, sf_man_prod}),
            .p (term_man_prod[3:2])
        );
        wire [5:0] max_exp_01 = (term_exp_biased[0] >= term_exp_biased[1]) ? term_exp_biased[0] : term_exp_biased[1];
        wire [5:0] max_exp_23 = (term_exp_biased[2] >= term_exp_biased[3]) ? term_exp_biased[2] : term_exp_biased[3];
        wire [5:0] max_exp_biased = (max_exp_01 >= max_exp_23) ? max_exp_01 : max_exp_23;
        wire [3:0] term_valid_r, term_sign_r;
        wire [3:0][5:0] shift_amt_r;
        wire [3:0][5:0] shift_amt_w;
        VX_pipe_register #(
            .DATAW (4 + 4 + 4 * 6),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({term_valid,   term_sign,   shift_amt_w}),
            .data_out ({term_valid_r, term_sign_r, shift_amt_r})
        );
        wire [3:0][26:0] term_signed;
        for (genvar j = 0; j < 4; ++j) begin : g_align
            VX_ks_adder #(
                .N(6),
                .BYPASS(0)
            ) shift_ksa (
                .dataa(max_exp_biased),
                .datab(~term_exp_biased[j]),
                .cin(1'b1),
                .sum(shift_amt_w[j]),
                . cout ()
            );
            assign term_mag_shifted[j] = term_valid_r[j] ? (24'(term_man_prod[j][10:0]) << SIG_SHIFT) : 24'd0;
            wire [23:0] aligned_mag = (shift_amt_r[j] >= 6'd24) ? 24'd0 : (term_mag_shifted[j] >> shift_amt_r[j][4:0]);
            wire [26:0] aligned_ext = {3'b0, aligned_mag};
            wire [26:0] neg_term;
            VX_ks_adder #(
                .N(27),
                .BYPASS(0)
            ) term_neg_ksa (
                .dataa(~aligned_ext),
                .datab(27'd0),
                .cin(1'b1),
                .sum(neg_term),
                . cout ()
            );
            assign term_signed[j] = term_sign_r[j] ? neg_term : aligned_ext;
        end
        wire [26:0] sum_vec, carry_vec;
        VX_csa_tree #(
            .N(4),
            .W(27),
            .S(27)
        ) term_csa (
            .operands (term_signed),
            .sum      (sum_vec),
            .carry    (carry_vec)
        );
        wire [26:0] signed_sum;
        VX_ks_adder #(
            .N(27),
            .BYPASS(0)
        ) sum_ksa (
            .dataa(sum_vec),
            .datab(carry_vec),
            .cin(1'b0),
            .sum(signed_sum),
            . cout ()
        );
        wire sum_sign = signed_sum[26];
        wire [25:0] neg_sum_raw;
        VX_ks_adder #(
            .N(26),
            .BYPASS(0)
        ) sum_neg_ksa (
            .dataa(~signed_sum[25:0]),
            .datab(26'd0),
            .cin(1'b1),
            .sum(neg_sum_raw),
            . cout ()
        );
        wire [25:0] abs_sum = sum_sign ? neg_sum_raw : signed_sum[25:0];
        wire is_zero_out = ~|abs_sum;
        assign result_sig_nvfp4[i] = {sum_sign & ~is_zero_out, abs_sum[23:0]};
        assign sig_zero_nvfp4[i]   = is_zero_out;
        assign result_exp_nvfp4[i] = EXP_W'(max_exp_biased) + EXP_W'(EXP_BASE_BIASED);
        assign exceptions_nvfp4[i].is_nan = ((&sf_a[6:0]) || (&sf_b[6:0])) && (|vld_mask[i*4 +: 4]);
        assign exceptions_nvfp4[i].is_inf = 1'b0;
        assign exceptions_nvfp4[i].sign   = 1'b0;
    end
    always_comb begin
        result_exp = '0;
        exceptions = '0;
        case (fmt_f)
            4'(TCU_MXFP4_ID): begin
                result_exp = result_exp_mxfp4;
                exceptions = exceptions_mxfp4;
            end
            4'(TCU_NVFP4_ID): begin
                result_exp = result_exp_nvfp4;
                exceptions = exceptions_nvfp4;
            end
            default: begin
                result_exp = '0;
                exceptions = '0;
            end
        endcase
    end
    always_comb begin
        result_sig = '0;
        sig_zero   = '0;
        case (fmt_f_r)
            4'(TCU_MXFP4_ID): begin
                result_sig = result_sig_mxfp4;
                sig_zero   = sig_zero_mxfp4;
            end
            4'(TCU_NVFP4_ID): begin
                result_sig = result_sig_nvfp4;
                sig_zero   = sig_zero_nvfp4;
            end
            default: begin
                result_sig = '0;
                sig_zero   = '0;
            end
        endcase
    end
endmodule
module VX_tcu_tfr_mul_f8 import VX_tcu_pkg::*;
#(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0,   
    parameter EXTERNAL_MUL = 0
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output wire [TCK-1:0][1:0][3:0] mantissa_a,
    output wire [TCK-1:0][1:0][3:0] mantissa_b,
    input wire [TCK-1:0][1:0][7:0] external_products,
    input wire [7:0]                sf_a,
    input wire [7:0]                sf_b,
    output logic [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions,
    output wire  [TCK-1:0]            sig_zero
);
    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + 2*(S_FP32 - S_SUPER) - W + WA - 1 + 128;
    localparam E_FP8 = VX_tcu_pkg::exp_bits(TCU_FP8_ID);
    localparam S_FP8 = VX_tcu_pkg::sign_pos(TCU_FP8_ID);
    localparam B_FP8 = (1 << (E_FP8 - 1)) - 1;
    localparam [7:0] BIAS_CONST_FP8  = 8'(BIAS_BASE - 2*B_FP8);
    localparam E_BF8 = VX_tcu_pkg::exp_bits(TCU_BF8_ID);
    localparam S_BF8 = VX_tcu_pkg::sign_pos(TCU_BF8_ID);
    localparam B_BF8 = (1 << (E_BF8 - 1)) - 1;
    localparam [7:0] BIAS_CONST_BF8  = 8'(BIAS_BASE - 2*B_BF8);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire [1:0] lane_valid = {vld_mask[i * 4 + 2], vld_mask[i * 4 + 0]};
        wire is_bfloat = tcu_fmt_is_bfloat(fmt_f);
        wire [1:0][4:0] ea_sel, eb_sel;
        wire [1:0][3:0] ma_sel, mb_sel;
        wire [1:0]      zero_sel, sign_sel, nan_sel, inf_sel;
        for (genvar j = 0; j < 2; ++j) begin : g_extract
            localparam OFF = (i % 2) * 16 + j * 8;
            wire [7:0] raw_a = a_row[i/2][OFF +: 8];
            wire [7:0] raw_b = b_col[i/2][OFF +: 8];
            logic [4:0] raw_ea, raw_eb;
            logic [2:0] raw_ma, raw_mb;
            logic       raw_sa, raw_sb;
            always_comb begin
                if (is_bfloat) begin  
                    raw_ea  = 5'(raw_a[S_BF8-1 -: E_BF8]);
                    raw_eb  = 5'(raw_b[S_BF8-1 -: E_BF8]);
                    raw_ma  = {raw_a[1:0], 1'b0};
                    raw_mb  = {raw_b[1:0], 1'b0};
                    raw_sa  = raw_a[7];
                    raw_sb  = raw_b[7];
                end else begin        
                    raw_ea  = 5'(raw_a[S_FP8-1 -: E_FP8]);
                    raw_eb  = 5'(raw_b[S_FP8-1 -: E_FP8]);
                    raw_ma  = raw_a[2:0];
                    raw_mb  = raw_b[2:0];
                    raw_sa  = raw_a[7];
                    raw_sb  = raw_b[7];
                end
            end
            fedp_class_t cls_a;
            VX_tcu_tfr_classifier #(
                .EXP_W (5),
                .MAN_W (3)
            ) class_a (
                .exp (raw_ea),
                .man (raw_ma),
                .cls (cls_a)
            );
            fedp_class_t cls_b;
            VX_tcu_tfr_classifier #(
                .EXP_W (5),
                .MAN_W (3)
            ) class_b (
                .exp (raw_eb),
                .man (raw_mb),
                .cls (cls_b)
            );
            wire is_ea_zero = (raw_ea == 0);
            wire is_eb_zero = (raw_eb == 0);
            assign ea_sel[j] = is_ea_zero ? 5'b1 : raw_ea;
            assign eb_sel[j] = is_eb_zero ? 5'b1 : raw_eb;
            assign ma_sel[j] = lane_valid[j] ? {~is_ea_zero, raw_ma} : 4'b0;
            assign mb_sel[j] = {~is_eb_zero, raw_mb};
            assign sign_sel[j] = raw_sa ^ raw_sb;
            assign zero_sel[j] = cls_a.is_zero | cls_b.is_zero;
            wire a_is_inf = is_bfloat ? cls_a.is_inf : 1'b0;
            wire b_is_inf = is_bfloat ? cls_b.is_inf : 1'b0;
            wire a_is_nan = is_bfloat ? cls_a.is_nan : (raw_ea == 5'h0F) && (raw_ma == 3'b111);
            wire b_is_nan = is_bfloat ? cls_b.is_nan : (raw_eb == 5'h0F) && (raw_mb == 3'b111);
            wire nan_in = a_is_nan | b_is_nan;
            wire inf_z  = (a_is_inf & cls_b.is_zero) | (cls_a.is_zero & b_is_inf);
            wire inf_op = a_is_inf | b_is_inf;
            assign nan_sel[j] = nan_in | inf_z;
            assign inf_sel[j] = inf_op & ~inf_z;
        end
        wire [5:0] pre_sum_0, pre_sum_1;
        VX_ks_adder #(
            .N(6),
            .BYPASS(0)
        ) exp_add1_0 (
            .dataa(6'(ea_sel[0])),
            .datab(6'(eb_sel[0])),
            .cin(1'b0),
            .sum(pre_sum_0),
            . cout ()
        );
        VX_ks_adder #(
            .N(6),
            .BYPASS(0)
        ) exp_add1_1 (
            .dataa(6'(ea_sel[1])),
            .datab(6'(eb_sel[1])),
            .cin(1'b0),
            .sum(pre_sum_1),
            . cout ()
        );
        wire v0 = ~zero_sel[0] && lane_valid[0];
        wire v1 = ~zero_sel[1] && lane_valid[1];
        wire [6:0] diff_0_minus_1 = {1'b0, pre_sum_0} - {1'b0, pre_sum_1};
        wire [6:0] diff_1_minus_0 = {1'b0, pre_sum_1} - {1'b0, pre_sum_0};
        wire term0_ge_term1 = ~diff_0_minus_1[6];
        wire term0_is_max = v0 && (!v1 || term0_ge_term1);
        wire diff_sign = term0_is_max;
        wire [5:0] diff_abs = term0_is_max ? diff_0_minus_1[5:0] : diff_1_minus_0[5:0];
        wire [5:0] max_pre_sum = term0_is_max ? pre_sum_0 : pre_sum_1;
        wire [7:0] bias_sel = is_bfloat ? BIAS_CONST_BF8 : BIAS_CONST_FP8;
        wire [EXP_W-1:0] max_pre_sum_cpa, bias_sel_cpa;
        wire [EXP_W-1:0] final_exp;
        wire [EXP_W-1:0] bias_cpa_sum, bias_cpa_carry;
        wire [3*EXP_W-1:0] sf_comp = fmt_f[3] ? {EXP_W'(sf_a), EXP_W'(sf_b), -EXP_W'(254)} : (3*EXP_W)'(0);
        VX_csa_tree #(
            .N(4),
            .W(EXP_W),
            .S(EXP_W)
        ) exp_sf_csa (
            .operands ({EXP_W'(bias_sel), sf_comp}),
            .sum      (bias_cpa_sum),
            .carry    (bias_cpa_carry)
        );
        VX_ks_adder #(
            .N(EXP_W),
            .BYPASS(0)
        ) exp_bias_add (
            .dataa(bias_cpa_sum),
            .datab(bias_cpa_carry),
            .cin(1'b0),
            .sum(bias_sel_cpa),
            . cout ()
        );
        assign max_pre_sum_cpa = EXP_W'(max_pre_sum);
        VX_ks_adder #(
            .N(EXP_W),
            .BYPASS(0)
        ) exp_final_add (
            .dataa(EXP_W'(max_pre_sum_cpa)),
            .datab(EXP_W'(bias_sel_cpa)),
            .cin(1'b0),
            .sum(final_exp),
            . cout ()
        );
        wire [1:0][7:0] man_prod;
        assign mantissa_a[i] = ma_sel;
        assign mantissa_b[i] = mb_sel;
        if (EXTERNAL_MUL) begin : g_external
            assign man_prod = external_products[i];
        end else begin : g_internal
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (USE_DSP),
                .OUT_REG (PROD_REG)
            ) wtmul (
                .clk    (clk),
                .enable (enable),
                .a (ma_sel),
                .b (mb_sel),
                .p (man_prod)
            );
        end
        wire       diff_sign_r;
        wire       diff_ge_32_r;
        wire [4:0] shamt_r;
        wire [1:0] sign_sel_r;
        wire       pre_sum_eq_r;
        VX_pipe_register #(
            .DATAW (1 + 1 + 5 + 2 + 1),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({diff_sign,   diff_abs[5],  diff_abs[4:0], sign_sel,   (pre_sum_0 == pre_sum_1)}),
            .data_out ({diff_sign_r, diff_ge_32_r, shamt_r,       sign_sel_r, pre_sum_eq_r})
        );
        wire [7:0] prod_max = diff_sign_r ? man_prod[0] : man_prod[1];
        wire [7:0] prod_min = diff_sign_r ? man_prod[1] : man_prod[0];
        wire       sign_max = diff_sign_r ? sign_sel_r[0] : sign_sel_r[1];
        wire       sign_min = diff_sign_r ? sign_sel_r[1] : sign_sel_r[0];
        wire [23:0] sig_max = {prod_max, 16'b0};
        wire [23:0] sig_min_shifted = diff_ge_32_r ? 24'b0 : ({prod_min, 16'b0} >> shamt_r);
        wire [24:0] sig_max_ext = {1'b0, sig_max};
        wire [24:0] sig_min_ext = {1'b0, sig_min_shifted};
        wire do_sub = sign_sel_r[0] ^ sign_sel_r[1];
        wire [24:0] add_raw;
        VX_ks_adder #(
            .N(25),
            .BYPASS(0)
        ) add_adder (
            .dataa(sig_max_ext),
            .datab(sig_min_ext),
            .cin(1'b0),
            .sum(add_raw),
            . cout ()
        );
        wire [24:0] sub_raw;
        VX_ks_adder #(
            .N(25),
            .BYPASS(0)
        ) sub_adder (
            .dataa(sig_max_ext),
            .datab(~sig_min_ext),
            .cin(1'b1),
            .sum(sub_raw),
            . cout ()
        );
        wire sub_neg = sub_raw[24];
        wire [24:0] sub_abs = sub_neg ? -sub_raw : sub_raw;
        wire [24:0] sig_add_raw = do_sub ? sub_abs : add_raw;
        wire [23:0] sig_add = sig_add_raw[24:1];
        wire mag_is_equal = pre_sum_eq_r && (man_prod[0] == man_prod[1]);
        wire is_zero_out = do_sub && mag_is_equal;
        wire sig_sign_raw = sub_neg ? sign_min : sign_max;
        wire sig_sign = is_zero_out ? 1'b0 : sig_sign_raw;
        assign result_sig[i] = {sig_sign, sig_add};
        assign sig_zero[i]   = is_zero_out;
        assign result_exp[i] = (v0 || v1) ? final_exp : '0;
        wire pos_inf_0 = inf_sel[0] && ~sign_sel[0] && lane_valid[0];
        wire neg_inf_0 = inf_sel[0] &&  sign_sel[0] && lane_valid[0];
        wire pos_inf_1 = inf_sel[1] && ~sign_sel[1] && lane_valid[1];
        wire neg_inf_1 = inf_sel[1] &&  sign_sel[1] && lane_valid[1];
        wire add_nan = (pos_inf_0 && neg_inf_1) || (neg_inf_0 && pos_inf_1);
        wire any_nan = (|(nan_sel & lane_valid)) || add_nan;
        wire any_inf = (|(inf_sel & lane_valid)) && ~any_nan;
        wire final_sign_inf = inf_sel[0] && lane_valid[0] ? sign_sel[0] : sign_sel[1];
        assign exceptions[i].is_nan = any_nan;
        assign exceptions[i].is_inf = any_inf;
        assign exceptions[i].sign   = final_sign_inf;
    end
endmodule
module VX_tcu_tfr_mul_i4 import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N   = 2,
    parameter TCK = 2 * N,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0   
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_i,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output logic [TCK-1:0][24:0]    result
);
    wire is_signed_int = fmt_i[3] || tcu_fmt_is_signed_int(fmt_i);
    wire [3:0] fmt_i_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_i),
        .data_out (fmt_i_r)
    );
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire signed [3:0][9:0] y_prod_i4;
        wire [3:0][3:0] raw_a, raw_b;
        wire [3:0]      pvalid;
        for (genvar j = 0; j < 4; ++j) begin : g_ext
            assign raw_a[j]  = a_row[i/2][(i%2)*16 + j*4 +: 4];
            assign raw_b[j]  = b_col[i/2][(i%2)*16 + j*4 +: 4];
            assign pvalid[j] = vld_mask[i * 4 + j];
        end
        wire [3:0] pvalid_r;
        VX_pipe_register #(
            .DATAW (4),
            .DEPTH (PROD_REG)
        ) pipe_valid (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (pvalid),
            .data_out (pvalid_r)
        );
        if (USE_DSP != 0) begin : g_dsp
            wire [3:0][3:0] mag_a, mag_b;
            wire [3:0]      psign;
            for (genvar j = 0; j < 4; ++j) begin : g_mag
                wire sgn_a = is_signed_int & raw_a[j][3];
                wire sgn_b = is_signed_int & raw_b[j][3];
                assign mag_a[j] = sgn_a ? (4'(~raw_a[j]) + 4'b1) : raw_a[j];   
                assign mag_b[j] = sgn_b ? (4'(~raw_b[j]) + 4'b1) : raw_b[j];   
                assign psign[j] = sgn_a ^ sgn_b;
            end
            wire [3:0][7:0] magp;
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (1),
                .OUT_REG (PROD_REG)
            ) m01 (
                .clk    (clk),
                .enable (enable),
                .a (mag_a[1:0]),
                .b (mag_b[1:0]),
                .p (magp[1:0])
            );
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (1),
                .OUT_REG (PROD_REG)
            ) m23 (
                .clk    (clk),
                .enable (enable),
                .a (mag_a[3:2]),
                .b (mag_b[3:2]),
                .p (magp[3:2])
            );
            wire [3:0] psign_r;
            VX_pipe_register #(
                .DATAW (4),
                .DEPTH (PROD_REG)
            ) pipe_sign (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (psign),
                .data_out (psign_r)
            );
            for (genvar j = 0; j < 4; ++j) begin : g_sign
                wire signed [9:0] pf = psign_r[j] ? -$signed({2'b0, magp[j]})
                                                  :  $signed({2'b0, magp[j]});
                assign y_prod_i4[j] = pf & {10{pvalid_r[j]}};
            end
        end else begin : g_lut
            for (genvar j = 0; j < 4; ++j) begin : g_mul
                wire signed [4:0] s_a = is_signed_int ? $signed({raw_a[j][3], raw_a[j]}) : $signed({1'b0, raw_a[j]});
                wire signed [4:0] s_b = is_signed_int ? $signed({raw_b[j][3], raw_b[j]}) : $signed({1'b0, raw_b[j]});
                wire signed [9:0] prod_full = s_a * s_b;
                wire [9:0] prod_r;
                VX_pipe_register #(
                    .DATAW (10),
                    .DEPTH (PROD_REG)
                ) pipe_prod (
                    .clk      (clk),
                    .reset    (1'b0),
                    .enable   (enable),
                    .data_in  (prod_full),
                    .data_out (prod_r)
                );
                assign y_prod_i4[j] = prod_r & {10{pvalid_r[j]}};
            end
        end
        wire [9:0] y_i4_sum, y_i4_carry;
        VX_csa_tree #(
            .N (4),
            .W (10),
            .S (10)
        ) i4_csa (
            .operands (y_prod_i4),
            .sum      (y_i4_sum),
            .carry    (y_i4_carry)
        );
        wire [9:0] y_i4_add_res;
        VX_ks_adder #(
            .N (10),
            .BYPASS (0)
        ) i4_ksa (
            .cin   (1'b0),
            .dataa (y_i4_sum),
            .datab (y_i4_carry),
            .sum   (y_i4_add_res),
            . cout ()
        );
        always_comb begin
            case ({1'b1, fmt_i_r})
                TCU_I4_ID: result[i] = 25'($signed(y_i4_add_res));
                TCU_U4_ID: result[i] = {15'b0, y_i4_add_res};
                default:   result[i] = '0;
            endcase
        end
    end
endmodule
module VX_tcu_tfr_mul_i8 import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N   = 2,
    parameter TCK = 2 * N,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0   
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_i,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output logic [TCK-1:0][24:0]    result
);
    for (genvar i = 1; i < TCU_MAX_INPUTS; i += 2) begin : g_unused_vld
    end
    wire is_signed_int = fmt_i[3] || tcu_fmt_is_signed_int(fmt_i);
    wire [3:0] fmt_i_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_i),
        .data_out (fmt_i_r)
    );
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire signed [16:0] y_prod_i8 [2];
        for (genvar j = 0; j < 2; ++j) begin : g_i8
            wire lane_valid = vld_mask[i * 4 + j * 2];
            wire [7:0] raw_a = a_row[i/2][(i%2)*16 + j*8 +: 8];
            wire [7:0] raw_b = b_col[i/2][(i%2)*16 + j*8 +: 8];
            wire signed [8:0] s_a = is_signed_int ? $signed({raw_a[7], raw_a}) : $signed({1'b0, raw_a});
            wire signed [8:0] s_b = is_signed_int ? $signed({raw_b[7], raw_b}) : $signed({1'b0, raw_b});
            wire signed [16:0] prod_full;
            if (USE_DSP != 0) begin : g_dsp
                (* use_dsp = "yes" *) wire signed [16:0] dsp_prod = s_a * s_b;
                assign prod_full = dsp_prod;
            end else begin : g_lut
                assign prod_full = s_a * s_b;
            end
            wire [16:0] prod_r;
            VX_pipe_register #(
                .DATAW (17),
                .DEPTH (PROD_REG)
            ) pipe_prod (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (prod_full),
                .data_out (prod_r)
            );
            wire lane_valid_r;
            VX_pipe_register #(
                .DATAW (1),
                .DEPTH (PROD_REG)
            ) pipe_valid (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (lane_valid),
                .data_out (lane_valid_r)
            );
            assign y_prod_i8[j] = prod_r & {17{lane_valid_r}};
        end
        wire [16:0] y_i8_add_res;
        VX_ks_adder #(
            .N(17),
            .BYPASS (0)
        ) i8_ksa (
            .cin   (1'b0),
            .dataa (y_prod_i8[0]),
            .datab (y_prod_i8[1]),
            .sum   (y_i8_add_res),
            . cout ()
        );
        always_comb begin
            case ({1'b1, fmt_i_r})
                TCU_I8_ID: result[i] = 25'($signed(y_i8_add_res));
                TCU_U8_ID: result[i] = {8'b0, y_i8_add_res};
                default:   result[i] = '0;
            endcase
        end
    end
endmodule
module VX_tcu_tfr_mul_join import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10
) (
    input wire                      clk,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [4:0]                fmt_s,
    input wire [31:0]               c_val,
    input wire [TCK-1:0][EXP_W-1:0] exp_f16,
    input fedp_excep_t [TCK-1:0]    exc_f16,
    input wire [TCK-1:0][EXP_W-1:0] exp_f8,
    input fedp_excep_t [TCK-1:0]    exc_f8,
    input wire [TCK-1:0][EXP_W-1:0] exp_f4,
    input fedp_excep_t [TCK-1:0]    exc_f4,
    output logic [TCK:0][EXP_W-1:0] exp_out,
    output fedp_excep_t [TCK:0]     exc_out,
    output wire [24:0]              c_sig
);
    logic [TCK-1:0][EXP_W-1:0] exp_sel;
    fedp_excep_t [TCK-1:0]     exc_sel;
    always_comb begin
        case (fmt_s)
            TCU_FP16_ID,
            TCU_BF16_ID: begin
                exp_sel = exp_f16;
                exc_sel = exc_f16;
            end
            TCU_TF32_ID: begin
                exp_sel = exp_f16;
                exc_sel = exc_f16;
            end
            TCU_FP8_ID, TCU_BF8_ID
            , TCU_MXFP8_ID, TCU_MXBF8_ID
            : begin
                exp_sel = exp_f8;
                exc_sel = exc_f8;
            end
            TCU_MXFP4_ID: begin
                exp_sel = exp_f4;
                exc_sel = exc_f4;
            end
            TCU_NVFP4_ID: begin
                exp_sel = exp_f4;
                exc_sel = exc_f4;
            end
            default: begin
                exp_sel = '0;
                exc_sel = '0;
            end
        endcase
    end
    wire c_is_int = tcu_fmt_is_int(fmt_s);
    fedp_class_t cls_c;
    VX_tcu_tfr_classifier #(
        .EXP_W (8),
        .MAN_W (23)
    ) class_c (
        .exp (c_val[30:23]),
        .man (c_val[22:0]),
        .cls (cls_c)
    );
    wire c_sign = c_val[31];
    assign c_sig = c_is_int ? c_val[24:0] : (cls_c.is_zero ? 25'd0 : {c_val[31], (cls_c.is_sub ? 1'b0 : 1'b1), c_val[22:0]});
    wire [7:0] c_exp_raw = (cls_c.is_sub || cls_c.is_zero) ? 8'd1 : c_val[30:23];
    wire [EXP_W-1:0] c_exp_adj = EXP_W'(c_exp_raw) - EXP_W'(W-1) + EXP_W'(WA-1) + 128;
    wire [EXP_W-1:0] c_exp_final = cls_c.is_zero ? '0 : c_exp_adj;
    assign exp_out = {c_exp_final, exp_sel};
    for (genvar i = 0; i < TCK; ++i) begin : g_exc
        assign exc_out[i] = exc_sel[i];
    end
    assign exc_out[TCK].is_nan = cls_c.is_nan;
    assign exc_out[TCK].is_inf = cls_c.is_inf;
    assign exc_out[TCK].sign   = c_sign;
endmodule
module VX_tcu_tfr_shared_mul import VX_tcu_pkg::*;  #(
    parameter  INSTANCE_ID = "",
    parameter N = 2,             
    parameter W = 25,            
    parameter WA = 28,           
    parameter EXP_W = 10,        
    parameter TCK = 2 * N,       
    parameter SF = 1,            
    parameter USE_DSP = 0,       
    parameter PROD_REG = 0,      
    parameter EXTERNAL_MUL = 0,
    parameter EXTERNAL_EXP = 0,
    parameter EXTERNAL_F8 = 0
) (
    input wire              clk,
    input wire              enable,
    input wire              valid_in,
    input wire [31:0]       req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [4:0]        fmt_s,
    input wire [N-1:0][31:0] a_row,
    input wire [N-1:0][31:0] b_col,
    input wire [31:0]        c_val,
    output wire [TCK-1:0][10:0] mantissa_a,
    output wire [TCK-1:0][10:0] mantissa_b,
    input wire [TCK-1:0][21:0] external_products,
    input wire                external_exp_enable,
    input wire [TCK:0][EXP_W-1:0] external_exponents,
    output wire [TCK-1:0][1:0][3:0] f8_mantissa_a,
    output wire [TCK-1:0][1:0][3:0] f8_mantissa_b,
    input wire [TCK-1:0][1:0][7:0] external_f8_products,
    input wire [SF-1:0][7:0] sf_a,
    input wire [SF-1:0][7:0] sf_b,
    output wire [TCK:0][EXP_W-1:0] exponents,
    output wire [TCK:0]            exp_sel,
    output wire [TCK:0][24:0] raw_sigs,
    output fedp_excep_t       exceptions,
    output wire [TCK-1:0]     lane_mask
);
    if (!1 && !1) begin : g_sf_unused
    end
    wire [TCK-1:0][24:0]      mul_f16_sig;
    wire [TCK-1:0][EXP_W-1:0] mul_f16_exp;
    fedp_excep_t [TCK-1:0]    mul_f16_exc;
    VX_tcu_tfr_mul_f16 #(
        .N(N),
        .TCK(TCK),
        .W(W),
        .WA(WA),
        .EXP_W(EXP_W),
        .USE_DSP(USE_DSP),
        .PROD_REG(PROD_REG),
        .EXTERNAL_MUL(EXTERNAL_MUL)
    ) mul_f16 (
        .clk        (clk),
        .enable     (enable),
        .valid_in   (valid_in),
        .req_id     (req_id),
        .vld_mask   (vld_mask),
        .fmt_f      (fmt_s[3:0]),
        .a_row      (a_row),
        .b_col      (b_col),
        .mantissa_a (mantissa_a),
        .mantissa_b (mantissa_b),
        .external_products (external_products),
        .result_sig (mul_f16_sig),
        .result_exp (mul_f16_exp),
        .exceptions (mul_f16_exc)
    );
    wire [TCK-1:0][24:0]      mul_f8_sig;
    wire [TCK-1:0][EXP_W-1:0] mul_f8_exp;
    fedp_excep_t [TCK-1:0]    mul_f8_exc;
    wire [TCK-1:0]            mul_f8_zero;
    wire [SF-1:0][TCK-1:0][24:0]      mul_f8_sig_s;
    wire [SF-1:0][TCK-1:0][EXP_W-1:0] mul_f8_exp_s;
    fedp_excep_t [SF-1:0][TCK-1:0]    mul_f8_exc_s;
    wire [SF-1:0][TCK-1:0]            mul_f8_zero_s;
    wire [SF-1:0][TCK-1:0][1:0][3:0] f8_ma, f8_mb;
    assign f8_mantissa_a = f8_ma[0];
    assign f8_mantissa_b = f8_mb[0];
    for (genvar s = 0; s < SF; ++s) begin : g_mul_f8_sf
        VX_tcu_tfr_mul_f8 #(
            .N(N),
            .TCK(TCK),
            .W(W),
            .WA(WA),
            .EXP_W(EXP_W),
            .USE_DSP(USE_DSP),
            .PROD_REG(PROD_REG),
            .EXTERNAL_MUL(EXTERNAL_F8)
        ) mul_f8 (
            .clk        (clk),
            .enable     (enable),
            .valid_in   (valid_in),
            .req_id     (req_id),
            .vld_mask   (vld_mask),
            .fmt_f      (fmt_s[3:0]),
            .a_row      (a_row),
            .b_col      (b_col),
            .mantissa_a (f8_ma[s]),
            .mantissa_b (f8_mb[s]),
            .external_products (external_f8_products),
            .sf_a       (sf_a[s]),
            .sf_b       (sf_b[s]),
            .result_sig (mul_f8_sig_s[s]),
            .result_exp (mul_f8_exp_s[s]),
            .exceptions (mul_f8_exc_s[s]),
            .sig_zero   (mul_f8_zero_s[s])
        );
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mul_f8_lane
        localparam SF_SLOT = (i * SF) / TCK;
        assign mul_f8_sig[i]  = mul_f8_sig_s[SF_SLOT][i];
        assign mul_f8_exp[i]  = mul_f8_exp_s[SF_SLOT][i];
        assign mul_f8_exc[i]  = mul_f8_exc_s[SF_SLOT][i];
        assign mul_f8_zero[i] = mul_f8_zero_s[SF_SLOT][i];
    end
    wire [TCK-1:0][24:0]      mul_f4_sig;
    wire [TCK-1:0][EXP_W-1:0] mul_f4_exp;
    fedp_excep_t [TCK-1:0]    mul_f4_exc;
    wire [TCK-1:0]            mul_f4_zero;
    wire [SF-1:0][TCK-1:0][24:0]      mul_f4_sig_s;
    wire [SF-1:0][TCK-1:0][EXP_W-1:0] mul_f4_exp_s;
    fedp_excep_t [SF-1:0][TCK-1:0]    mul_f4_exc_s;
    wire [SF-1:0][TCK-1:0]            mul_f4_zero_s;
    for (genvar s = 0; s < SF; ++s) begin : g_mul_f4_sf
        VX_tcu_tfr_mul_f4 #(
            .N(N),
            .TCK(TCK),
            .W(W),
            .WA(WA),
            .EXP_W(EXP_W),
            .USE_DSP(USE_DSP),
            .PROD_REG(PROD_REG)
        ) mul_f4 (
            .clk        (clk),
            .enable     (enable),
            .valid_in   (valid_in),
            .req_id     (req_id),
            .vld_mask   (vld_mask),
            .fmt_f      (fmt_s[3:0]),
            .a_row      (a_row),
            .b_col      (b_col),
            .sf_a       (sf_a[s]),
            .sf_b       (sf_b[s]),
            .result_sig (mul_f4_sig_s[s]),
            .result_exp (mul_f4_exp_s[s]),
            .exceptions (mul_f4_exc_s[s]),
            .sig_zero   (mul_f4_zero_s[s])
        );
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mul_f4_lane
        localparam SF_SLOT = (i * SF) / TCK;
        assign mul_f4_sig[i]  = mul_f4_sig_s[SF_SLOT][i];
        assign mul_f4_exp[i]  = mul_f4_exp_s[SF_SLOT][i];
        assign mul_f4_exc[i]  = mul_f4_exc_s[SF_SLOT][i];
        assign mul_f4_zero[i] = mul_f4_zero_s[SF_SLOT][i];
    end
    wire [TCK:0][EXP_W-1:0] join_exp;
    fedp_excep_t [TCK:0]    join_exc;
    wire [24:0]             c_sig;
    VX_tcu_tfr_mul_join #(
        .N(N),
        .TCK(TCK),
        .W(W),
        .WA(WA),
        .EXP_W(EXP_W)
    ) join_stage (
        .clk        (clk),
        .valid_in   (valid_in),
        .req_id     (req_id),
        .fmt_s      (fmt_s),
        .c_val      (c_val),
        .exp_f16    (mul_f16_exp),
        .exc_f16    (mul_f16_exc),
        .exp_f8     (mul_f8_exp),
        .exc_f8     (mul_f8_exc),
        .exp_f4     (mul_f4_exp),
        .exc_f4     (mul_f4_exc),
        .exp_out    (join_exp),
        .exc_out    (join_exc),
        .c_sig      (c_sig)
    );
    fedp_excep_t exceptions_w;
    VX_tcu_tfr_exc_reduce #(
        .TCK (TCK)
    ) exc_reduce (
        .exc_in  (join_exc),
        .exc_out (exceptions_w)
    );
    wire [TCK-1:0] lane_mask_w;
    VX_tcu_tfr_lane_mask #(
        .N   (N),
        .TCK (TCK)
    ) lane_mask_inst (
        .vld_mask (vld_mask),
        .fmt_s    (fmt_s),
        .lane_mask(lane_mask_w)
    );
    localparam EXC_W = $bits(fedp_excep_t);
    wire [TCK:0][EXP_W-1:0] join_exp_r;
    wire [24:0]             c_sig_r;
    fedp_excep_t            exceptions_r;
    wire [TCK-1:0]          lane_mask_r;
    wire [4:0]              fmt_s_r;
    VX_pipe_register #(
        .DATAW ((TCK+1)*EXP_W + 25 + EXC_W + TCK + 5),
        .DEPTH (PROD_REG)
    ) pipe_seam (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  ({join_exp,   c_sig,   exceptions_w, lane_mask_w, fmt_s}),
        .data_out ({join_exp_r, c_sig_r, exceptions_r, lane_mask_r, fmt_s_r})
    );
    logic [TCK-1:0][24:0] sig_sel;
    logic [TCK-1:0]       sig_zero;
    always_comb begin
        case (fmt_s_r)
            TCU_FP16_ID,
            TCU_BF16_ID: begin
                sig_sel  = mul_f16_sig;
                sig_zero = '0;
            end
            TCU_TF32_ID: begin
                sig_sel  = mul_f16_sig;
                sig_zero = '0;
            end
            TCU_FP8_ID, TCU_BF8_ID
            , TCU_MXFP8_ID, TCU_MXBF8_ID
            : begin
                sig_sel  = mul_f8_sig;
                sig_zero = mul_f8_zero;
            end
            TCU_MXFP4_ID: begin
                sig_sel  = mul_f4_sig;
                sig_zero = mul_f4_zero;
            end
            TCU_NVFP4_ID: begin
                sig_sel  = mul_f4_sig;
                sig_zero = mul_f4_zero;
            end
            default: begin
                sig_sel  = '0;
                sig_zero = '0;
            end
        endcase
    end
    assign raw_sigs = {c_sig_r, sig_sel};
    for (genvar i = 0; i < TCK; ++i) begin : g_exp_kill
        assign exponents[i] = EXTERNAL_EXP && external_exp_enable ? external_exponents[i]
                            : sig_zero[i] ? '0 : join_exp_r[i];
    end
    assign exponents[TCK] = EXTERNAL_EXP && external_exp_enable ? external_exponents[TCK] : join_exp_r[TCK];
    VX_tcu_tfr_max_exp #(
        .N     (TCK+1),
        .WIDTH (EXP_W)
    ) find_max_exp (
        .exponents (exponents),
        .sel_exp   (exp_sel)
    );
    assign exceptions = exceptions_r;
    assign lane_mask  = lane_mask_r;
endmodule
module VX_ucc_bf16x9_prepare (
    input  wire [31:0]       a,
    input  wire [31:0]       b,
    input  wire [31:0]       c,
    input  wire [1:0]        op,
    output wire [8:0][10:0]  mul_a,
    output wire [8:0][10:0]  mul_b,
    input  wire [8:0][21:0]  products,
    output wire [16:0][9:0]  exponents,
    output wire [16:0][24:0] significands,
    output wire              zero_sign,
    output wire              special,
    output wire [31:0]       special_result,
    output wire [4:0]        flags
);
    wire [31:0] x = a;
    wire [31:0] y = op[1] ? 32'h3f800000 : b;
    wire psign = x[31] ^ y[31];
    wire [31:0] z = op[1] ? {b[31] ^ op[0], b[30:0]} : op[0] ? {psign, 31'd0} : c;
    wire [7:0] ex = x[30:23], ey = y[30:23], ez = z[30:23];
    wire [23:0] mx = {(|ex), x[22:0]}, my = {(|ey), y[22:0]}, mz = {(|ez), z[22:0]};
    wire xzero = !(|x[30:0]), yzero = !(|y[30:0]), zzero = !(|z[30:0]);
    wire xnan = (&ex) && (|x[22:0]), ynan = (&ey) && (|y[22:0]), znan = (&ez) && (|z[22:0]);
    wire xinf = (&ex) && !(|x[22:0]), yinf = (&ey) && !(|y[22:0]), zinf = (&ez) && !(|z[22:0]);
    wire snan = (xnan && !x[22]) || (ynan && !y[22]) || (znan && !z[22]);
    wire bad_product = (xinf && yzero) || (yinf && xzero);
    wire pinf = (xinf || yinf) && !(xnan || ynan || bad_product);
    wire invalid = snan || bad_product || (pinf && zinf && psign != z[31]);
    wire nan_result = xnan || ynan || znan || invalid;
    assign special = nan_result || pinf || zinf;
    assign special_result = nan_result ? 32'h7fc00000 : {pinf ? psign : z[31], 8'hff, 23'd0};
    assign flags = {invalid, 4'd0};
    assign zero_sign = (xzero || yzero) && zzero && (psign == z[31]) && psign;
    wire [9:0] xe = ex == 0 ? 10'd1 : 10'(ex);
    wire [9:0] ye = ey == 0 ? 10'd1 : 10'(ey);
    wire [9:0] ze = ez == 0 ? 10'd1 : 10'(ez);
    wire [9:0] product_exponent = xe + ye + 10'd8;
    for (genvar i = 0; i < 9; ++i) begin : g_product
        assign mul_a[i] = {3'd0, mx[(i/3)*8 +: 8]};
        assign mul_b[i] = {3'd0, my[(i%3)*8 +: 8]};
        assign exponents[i] = (|mul_a[i]) && (|mul_b[i])
                            ? product_exponent + 10'(8*((i/3)+(i%3))) : '0;
        assign significands[i] = {psign, products[i][15:0], 8'd0};
    end
    assign exponents[15:9] = '0;
    assign significands[15:9] = '0;
    assign exponents[16] = zzero ? 10'd0 : ze + 10'd167;
    assign significands[16] = {z[31], mz};
endmodule
module VX_ucc_boolean (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [31:0] c,
    input  wire [7:0]  immediate,
    input  wire [2:0]  op,
    output logic [31:0] result
);
    wire [31:0] lop3;
    for (genvar i = 0; i < 32; ++i) begin : g_lop3
        assign lop3[i] = immediate[{a[i], b[i], c[i]}];
    end
    always_comb begin
        case (op)
            3'd0: result = a & b;
            3'd1: result = a | b;
            3'd2: result = a ^ b;
            3'd3: result = ~a;
            3'd4: result = lop3;
            3'd5: result = c[0] ? a : b;
            3'd6: result = a;
            default: result = '0;
        endcase
    end
endmodule
module VX_rom #(
    parameter DATAW                      = 1,
    parameter SIZE                       = 1,
    parameter OUT_REG                    = 0,
    parameter [SIZE*DATAW-1:0] INIT_DATA = '0,
    parameter ADDRW                      = (((SIZE) > 1) ? $clog2(SIZE) : 1)
) (
    input  wire             clk,
    input  wire             read,
    input  wire [ADDRW-1:0] addr,
    output wire [DATAW-1:0] rdata
);
    localparam BLOCK = (OUT_REG != 0) && (((SIZE) >= 64) && (((SIZE) * (DATAW)) >= 2048));
    if (BLOCK) begin : g_block
         reg [DATAW-1:0] mem [0:SIZE-1];
        reg [DATAW-1:0] rdata_r;
        initial begin
            for (integer i = 0; i < SIZE; ++i) begin
                mem[i] = INIT_DATA[i * DATAW +: DATAW];
            end
        end
        always @(posedge clk) begin
            if (read) begin
                rdata_r <= mem[addr];
            end
        end
        assign rdata = rdata_r;
    end else begin : g_logic
        wire [DATAW-1:0] mem [0:SIZE-1];
        for (genvar i = 0; i < SIZE; ++i) begin : g_word
            assign mem[i] = INIT_DATA[i * DATAW +: DATAW];
        end
        if (OUT_REG != 0) begin : g_out_reg
            reg [DATAW-1:0] rdata_r;
            always @(posedge clk) begin
                if (read) begin
                    rdata_r <= mem[addr];
                end
            end
            assign rdata = rdata_r;
        end else begin : g_no_out_reg
            assign rdata = mem[addr];
        end
    end
endmodule
module VX_mufu_rom #(
    parameter REGISTERED = 1
) (
    input  wire clk,
    input  wire enable,
    input  wire [2:0] tbl,
    input  wire [6:0] idx,
    output wire [31:0] a0,
    output wire signed [26:0] a1,
    output wire signed [19:0] a2
);
    localparam DATAW = 72;
    localparam SIZE  = 512;
    localparam [SIZE*DATAW-1:0] ROM_DATA = {
        72'h01fffff0000017fffe,
        72'h01ffffc800003ffffc,
        72'h01ffff68000097fff4,
        72'h01fffe68000187ffe0,
        72'h01fffba800041fffa9,
        72'h01fff420000b2fff13,
        72'h01ffdfc0001e57fd7c,
        72'h01ffa86000525ff92a,
        72'h03fede58008e17f8e9,
        72'h03fe229800ea17f453,
        72'h03fced6001817fecc8,
        72'h03faf050027a5fe06a,
        72'h03f7ab280412afcc31,
        72'h03f24cc006ae6fab4b,
        72'h03e982780aecbf7643,
        72'h03db2e7011c4d72203,
        72'h07a1e40016e18f6344,
        72'h0787f1c01d014f3b68,
        72'h07671e2824a3770b06,
        72'h073dc1082e1336d146,
        72'h0709e5a8399e3e8de0,
        72'h06c94c50478cb64190,
        72'h0679767058143deeb1,
        72'h0617c2406b453d99fc,
        72'h0bbec2a075fefeaec1,
        72'h0b433350811b669c9c,
        72'h0abc48a08cb58e8cf6,
        72'h0a29927898b26e80b0,
        72'h098abf50a4ef9e78ba,
        72'h08dfa408b1430e7603,
        72'h08284348bd7b0e7982,
        72'h0764d478c95fce83fb,
        72'h0dfd7340cf15af4856,
        72'h0d2b94d0d4a7774ddb,
        72'h0c543ee0da04f75465,
        72'h0b77a9b8df25ff5bf3,
        72'h0a9615e8e402776485,
        72'h09afcc00e8925f6e17,
        72'h08c51c78eccdf778a0,
        72'h07d65f48f0add78416,
        72'h0ebb32e0f2723fc69f,
        72'h0dc7e820f423dfc9ce,
        72'h0cd2f8d8f5bb37cd17,
        72'h0bdc7fc0f7378fd077,
        72'h0ae49838f89827d3ee,
        72'h09eb5e38f9dc67d77a,
        72'h08f0ee78fb03afdb19,
        72'h07f56640fc0d67deca,
        72'h0eee84b0fc84e7f0cd,
        72'h0df1c6d8fcf6f7f1bf,
        72'h0cf49ac8fd615ff2b3,
        72'h0bf70828fdc41ff3a8,
        72'h0af916a8fe1f1ff4a0,
        72'h09face00fe725ff598,
        72'h08fc3600febdd7f692,
        72'h07fd5680ff016ff78d,
        72'h0efb9cb0ff1fb7fc25,
        72'h0dfc6e90ff3c97fc64,
        72'h0cfd2490ff577ffca3,
        72'h0bfdc0a0ff706ffce3,
        72'h0afe44c8ff875ffd22,
        72'h09feb300ff9c4ffd62,
        72'h08ff0d40ffaf47fda1,
        72'h07ff5588ffc03ffde1,
        72'h7ff6218013bced8867,
        72'h7fd887882776e588c9,
        72'h7fa736b03b2ac5898b,
        72'h7f6236884ed58d8aaf,
        72'h7f0991c06274258c34,
        72'h7e9d55f07603958e1a,
        72'h7e1d93e08980cd9060,
        72'h7d8a5f389ce8cd9307,
        72'h7ce3cea0b038a5960d,
        72'h7c29fbe0c36d4d9973,
        72'h7b5d0390d683cd9d37,
        72'h7a7d0548e9793da159,
        72'h798a23a0fc4aada5d9,
        72'h788484010ef535aab6,
        72'h776c4ec92175f5afef,
        72'h7641af2933ca0db584,
        72'h7504d33145eeb5bb72,
        72'h73b5ebb157e11dc1bb,
        72'h72552c69699e75c85b,
        72'h70e2cba97b240dcf54,
        72'h6f5f02918c6f2dd6a3,
        72'h6dca0cf19d7d2dde47,
        72'h6c242941ae4b6de63f,
        72'h6a6d9881bed74dee8a,
        72'h68a69e61cf1e45f727,
        72'h66cf8101df1dd60014,
        72'h64e88901eed3860950,
        72'h62f20189fe3ce612da,
        72'h60ec38020d579e1cb0,
        72'h5ed77c621c214626d0,
        72'h5cb420b22a97ae3139,
        72'h5a82797238b88e3bea,
        72'h5842dd224681be46e0,
        72'h55f5a4a253f116521a,
        72'h539b2ac26104865d97,
        72'h5133cc626dba0e6954,
        72'h4ebfe8727a0fbe7550,
        72'h4c3fdfc286039e8188,
        72'h49b415029193e68dfc,
        72'h471cecb29cbec69aa9,
        72'h447acd22a7827ea78c,
        72'h41ce1e32b1dd76b4a5,
        72'h3f174982bbce0ec1f1,
        72'h3c56ba3ac552b6cf6e,
        72'h398cdd02ce69fedd1a,
        72'h36ba1fdad71286eaf3,
        72'h33def252df4ae6f8f7,
        72'h30fbc512e711e70723,
        72'h2e110a2aee664f1576,
        72'h2b1f34b2f5470723ec,
        72'h2826b8f2fbb2ef3285,
        72'h25280c2301a917413d,
        72'h2223a48b07288f5013,
        72'h1f19f93b0c30875f04,
        72'h1c0b822b10c0276e0e,
        72'h18f8b7fb14d6c77d2e,
        72'h15e214031873bf8c62,
        72'h12c810331b96879ba8,
        72'h0fab26eb1e3e9faafe,
        72'h0c8bd323206b9fba61,
        72'h096a900b221d2fc9ce,
        72'h0647d94323530fd944,
        72'h03242a83240d0fe8c0,
        72'h00000003244857f8cf,
        72'h7e8d3859743bdfa2f1,
        72'h7d17824177301fa177,
        72'h7b9ed1d97a307f9ff4,
        72'h7a231ae17d3d3f9e67,
        72'h78a450c98056b79cd1,
        72'h772266c1837d2f9b30,
        72'h759d4f9186b0f79986,
        72'h7414fdc989f26f97d1,
        72'h728963898d41df9610,
        72'h70fa72a1909fb79445,
        72'h6f681c91940c3f926d,
        72'h6dd252519787ef908a,
        72'h6c3904b19b13178e99,
        72'h6a9c23f19eae2f8c9c,
        72'h68fb9fe9a2599f8a91,
        72'h67576811a615cf8878,
        72'h65af6b61a9e33f8651,
        72'h64039871adc25f841b,
        72'h6253dd49b1b3af81d5,
        72'h60a02771b5b7af7f7f,
        72'h5ee86401b9cee77d18,
        72'h5d2c7f79bdf9df7a9f,
        72'h5b6c65c9c239277815,
        72'h59a80259c68d5f7578,
        72'h57df3ff1caf71772c7,
        72'h561208c1cf76f77002,
        72'h54404641d40da76d29,
        72'h5269e151d8bbcf6a39,
        72'h508ec221dd822f6732,
        72'h4eaed011e261876414,
        72'h4cc9f1d1e75a8f60dd,
        72'h4ae00d41ec6e1f5d8c,
        72'h48f10779f19d075a21,
        72'h46fcc4a1f6e82f5699,
        72'h45032811fc507752f4,
        72'h4304143201d6d74f31,
        72'h40ff6a5a077c4f4b4f,
        72'h3ef50b020d41df474b,
        72'h3ce4d5721328a74324,
        72'h3acea7f21931c73ed9,
        72'h38b25f921f5e673a69,
        72'h368fd82225afcf35d0,
        72'h3466ec522c273f310e,
        72'h3237755232c6172c21,
        72'h30014b02398dc72706,
        72'h2dc443da407fcf21bb,
        72'h2b8034b2479dbf1c3f,
        72'h2934f0da4ee937168d,
        72'h26e249e25663ef10a4,
        72'h24880f9a5e0fc70a81,
        72'h2226100265ee970420,
        72'h1fbc17026e0276fd80,
        72'h1d49ee9a764d6ef69b,
        72'h1acf5e827ed1ceef6f,
        72'h184c2c228791e6e7f7,
        72'h15c01a92909036e030,
        72'h132aea4299cf5ed814,
        72'h108c58eaa35226cfa0,
        72'h0de42182ad1b7ec6cd,
        72'h0b31fbe2b72e86bd97,
        72'h08759cbac18e86b3f7,
        72'h05aeb552cc3efea9e8,
        72'h02dcf34ad743a69f61,
        72'h00000002e2a27693f4,
        72'hfd3e0c82be2110f4aa,
        72'hfa83b352b690d8f207,
        72'hf7d0dfeaaf1580ef6c,
        72'hf5257d8aa7aec8ecd8,
        72'hf28177b2a05c78ea4b,
        72'hefe4ba12991e58e7c4,
        72'hed4f309291f430e545,
        72'heac0c75a8addd0e2cd,
        72'he8396ac283daf8e05c,
        72'he5b907527ceb70ddf1,
        72'he33f89e2760f10db8d,
        72'he0ccdf5a6f4598d92f,
        72'hde60f4ea688ed8d6d9,
        72'hdbfbb80261ea98d488,
        72'hd99d162a5b58b0d23e,
        72'hd744fd3254d8e0cffa,
        72'hd4f35b124e6b00cdbd,
        72'hd2a81df2480ed8cb85,
        72'hd063344241c438c954,
        72'hce248c7a3b8af0c729,
        72'hcbec15623562d8c504,
        72'hc9b9bdea2f4bb8c2e4,
        72'hc78d752a294568c0cb,
        72'hc5672a72234fb0beb7,
        72'hc346cd3a1d6a68bca9,
        72'hc12c4d2a179560baa1,
        72'hbf179a1211d070b89f,
        72'hbd08a3fa0c1b68b6a1,
        72'hbaff5b0a067620b4aa,
        72'hb8fbafa200e060b2b8,
        72'hb6fd9239fb5a10b0cb,
        72'hb504f389f5e2f8aee3,
        72'hb311c469f07af8ad01,
        72'hb123f5d9eb21d8ab24,
        72'haf3b7901e5d780a94c,
        72'had583f41e09bb8a779,
        72'hab7a3a09db6e60a5ab,
        72'ha9a15b09d64f50a3e2,
        72'ha7cd9409d13e60a21e,
        72'ha5fed6f9cc3b68a05f,
        72'ha4351601c746409ea5,
        72'ha2704351c25ec89cf0,
        72'ha0b05161bd84d09b3f,
        72'h9ef532b1b8b8409993,
        72'h9d3ed9f1b3f8e897eb,
        72'h9b8d3a01af46a89648,
        72'h99e045d9aaa16094aa,
        72'h9837f099a608e09310,
        72'h96942d81a17d10917a,
        72'h94f4eff19cfdc88fe9,
        72'h935a2b79988ae88e5c,
        72'h91c3d3b99424488cd4,
        72'h9031dc898fc9d08b4f,
        72'h8ea439d18b7b5889cf,
        72'h8d1adfa18738c08853,
        72'h8b95c2298301e886db,
        72'h8a14d5b97ed6b08567,
        72'h88980ec17ab6f883f8,
        72'h871f61d976a2a0828c,
        72'h85aac3a97299808124,
        72'h843a29016e9b887fc0,
        72'h82cd86d96aa8907e5f,
        72'h8164d23166c0807d03,
        72'h8000000162e3687b9e,
        72'h404060a7bf3e78183c,
        72'h40818517be78b818b8,
        72'h40c3713fbdaf081937,
        72'h41062927bce14019b9,
        72'h4149b0e7bc0f481a3f,
        72'h418e0ccfbb39001ac9,
        72'h41d34127ba5e501b57,
        72'h4219528fb97f081be9,
        72'h4260458fb89b101c80,
        72'h42a81ef7b7b2381d1b,
        72'h42f0e3afb6c4701dba,
        72'h433a98c7b5d1801e5e,
        72'h43854377b4d9401f08,
        72'h43d0e917b3db901fb6,
        72'h441d8f3fb2d840206a,
        72'h446b3b97b1cf282124,
        72'h44b9f407b0c01021e4,
        72'h4509beafafaac822a9,
        72'h455aa1cfae8f202375,
        72'h45aca3d7ad6ce82448,
        72'h45ffcb7fac43e02521,
        72'h46541fb7ab13d82602,
        72'h46a9a797a9dc8826ea,
        72'h47006a7fa89dc027da,
        72'h47587017a7573028d2,
        72'h47b1c047a608a029d3,
        72'h480c632fa4b1b82add,
        72'h48686147a352402bf0,
        72'h48c5c347a1e9e02d0d,
        72'h49249247a078502e34,
        72'h4984d79f9efd282f65,
        72'h49e69d179d782030a2,
        72'h4a49ecaf9be8d831ea,
        72'h4aaed0ef9a4ee0333f,
        72'h4b15549f98a9e834a1,
        72'h4b7d830f96f9703610,
        72'h4be767ef953d10378d,
        72'h4c530f579374503919,
        72'h4cc085f7919eb03ab5,
        72'h4d2fd8e78fbbb03c61,
        72'h4da115cf8dcac83e1f,
        72'h4e144adf8bcb603fee,
        72'h4e8986d789bce841d1,
        72'h4f00d937879eb043c8,
        72'h4f7a51f785702045d4,
        72'h4ff601cf83307847f7,
        72'h5073fa4780def84a31,
        72'h50f44d777e7ae84c85,
        72'h51770e7f7c03684ef2,
        72'h51fc512f797798517c,
        72'h52842a4776d6905424,
        72'h530eaf8f741f5056ea,
        72'h539bf7b77150d059d3,
        72'h542c1a8f6e69f05cde,
        72'h54bf31076b6990600f,
        72'h55555537684e706368,
        72'h55eea2a765173066eb,
        72'h568b360f61c2786a9b,
        72'h572b2dbf5e4eb86e7c,
        72'h57cea9775aba60728f,
        72'h5875cab75703b876da,
        72'h5920b4b75328e87b5e,
        72'h59cf8c8f4f28088022,
        72'h5a82796f4afef08528,
        72'h5add84bfa46bd02246,
        72'h5b39a4c7a3543022f5,
        72'h5b96df47a236f023a8,
        72'h5bf539e7a113f02461,
        72'h5c54ba7f9feb00251e,
        72'h5cb567179ebbf825e1,
        72'h5d1745d79d86a826aa,
        72'h5d7a5d179c4ae82779,
        72'h5ddeb3779b0880284e,
        72'h5e444faf99bf382929,
        72'h5eab38a7986ef02a0a,
        72'h5f1375979717582af3,
        72'h5f7d0dd795b8502be2,
        72'h5fe808ff9451882cd9,
        72'h60546edf92e2d02dd8,
        72'h60c24797916be82ede,
        72'h61319b778fec802fed,
        72'h61a2731f8e64603105,
        72'h6214d75f8cd3403225,
        72'h6288d16f8b38d0334f,
        72'h62fe6abf8994c03482,
        72'h6375ad0f87e6c835c0,
        72'h63eea27f862e883709,
        72'h6469557f846bb0385c,
        72'h64e5d0d7829de039bb,
        72'h65641fa780c4b03b26,
        72'h65e44d877edfc83c9e,
        72'h6666665f7ceeb83e23,
        72'h66ea768f7af1183fb6,
        72'h67708aef78e6684157,
        72'h67f8b0b776ce404307,
        72'h6882f5b774a81044c7,
        72'h690f681f7273604697,
        72'h699e16c7702fa04879,
        72'h6a2f10f76ddc404a6d,
        72'h6ac266a76b78a84c75,
        72'h6b5828676904384e90,
        72'h6bf06757667e4050c0,
        72'h6c8b354763e6205306,
        72'h6d28a4df613b105564,
        72'h6dc8c95f5e7c5057da,
        72'h6e6bb6d75ba9185a69,
        72'h6f11823758c0885d14,
        72'h6fba414755c1c05fdb,
        72'h70660aaf52abd062c1,
        72'h7114f62f4f7db065c6,
        72'h71c71c574c366868ec,
        72'h727c96ff48d4c86c36,
        72'h733580ff4557b06fa6,
        72'h73f1f66f41bde8733d,
        72'h74b214af3e061876fe,
        72'h7575fa873a2ed87aeb,
        72'h763dc7ff3636c07f07,
        72'h77099ed7321c308356,
        72'h77d9a2472ddd9087d9,
        72'h78adf74f2979088c95,
        72'h7986c4b724ecd0918c,
        72'h7a6433372036e096c4,
        72'h7b466da71b55109c3f,
        72'h7c2da0ef164528a203,
        72'h7d19fc671104b8a814,
        72'h7e0bb1e70b9128ae78,
        72'h7f02f5df05e7c0b535,
        72'h80000007000438bc93,
        72'h40404047bf7f601018,
        72'h40810207befd201049,
        72'h40c246dfbe7948107a,
        72'h41041047bdf3e810ad,
        72'h41465fe7bd6ce810e0,
        72'h41893757bce4481114,
        72'h41cc982fbc5a081149,
        72'h42108427bbce10117e,
        72'h4254fce7bb407011b5,
        72'h429a042fbab11011ec,
        72'h42df9bb7ba1ff01224,
        72'h4325c547b98d00125e,
        72'h436c82a7b8f8401298,
        72'h43b3d5b7b861b012d3,
        72'h43fbc047b7c938130f,
        72'h44444447b72ed8134c,
        72'h448d63a7b69280138a,
        72'h44d72047b5f43813c9,
        72'h45217c3fb553e8140a,
        72'h456c7987b4b190144b,
        72'h45b81a27b40d28148e,
        72'h4604604fb366a014d1,
        72'h46514e07b2bdf01516,
        72'h469ee587b21318155c,
        72'h46ed2907b1660015a3,
        72'h473c1abfb0b6a015eb,
        72'h478bbcf7b004f81635,
        72'h47dc11f7af51001680,
        72'h482d1c37ae9a9816cc,
        72'h487ede0fade1c8171a,
        72'h48d159e7ad26881769,
        72'h4924924fac68b817b9,
        72'h497889c7aba860180b,
        72'h49cd42e7aae570185f,
        72'h4a22c04faa1fd018b4,
        72'h4a7904afa95780190a,
        72'h4ad012b7a88c701962,
        72'h4b27ed37a7be9819bc,
        72'h4b809707a6ede01a17,
        72'h4bda12ffa61a401a74,
        72'h4c346407a543b01ad3,
        72'h4c8f8d2fa46a181b33,
        72'h4ceb916fa38d701b95,
        72'h4d4873f7a2ada01bfa,
        72'h4da637d7a1caa81c60,
        72'h4e04e057a0e4681cc8,
        72'h4e6470b79ffae01d32,
        72'h4ec4ec4f9f0df81d9e,
        72'h4f2656979e1d981e0c,
        72'h4f88b2f79d29b81e7c,
        72'h4fec04ff9c32481eef,
        72'h505050579b37281f63,
        72'h50b5989f9a38581fda,
        72'h511be1979935c02054,
        72'h51832f27982f4020d0,
        72'h51eb851f9724d8214e,
        72'h5254e78f96166021cf,
        72'h52bf5a879503d02252,
        72'h532ae21f93ed1022d8,
        72'h5397829f92d2082361,
        72'h5405405791b2a023ed,
        72'h54741faf908ec8247c,
        72'h54e425278f6660250d,
        72'h555555578e395825a2,
        72'h55c7b4f78d07882639,
        72'h563b48c78bd0e826d4,
        72'h56b015af8a95582772,
        72'h572620b78954b82814,
        72'h579d6ee7880ef828b9,
        72'h5816058786c3e82962,
        72'h588fe9d78573802a0e,
        72'h590b2167841d902abe,
        72'h5987b1a782c2002b72,
        72'h5a05a0578160b82c2a,
        72'h5a84f3477ff9902ce6,
        72'h5b05b0577e8c682da6,
        72'h5b87ddaf7d19182e6a,
        72'h5c0b816f7b9f802f33,
        72'h5c90a1ff7a1f803000,
        72'h5d1745cf7898f830d2,
        72'h5d9f738f770bb031a9,
        72'h5e2932077577883285,
        72'h5eb4881f73dc603366,
        72'h5f417d07723a00344c,
        72'h5fd017ef7090483538,
        72'h6060605f6edf083629,
        72'h60f25de76d26103720,
        72'h6186185f6b6530381c,
        72'h621b97bf699c38391f,
        72'h62b2e43f67caf83a28,
        72'h634c063765f1403b38,
        72'h63e70637640ed83c4e,
        72'h6483ed276223803d6b,
        72'h6522c3ef602f103e8f,
        72'h65c393df5e31403fba,
        72'h666666675c29e040ed,
        72'h670b45375a18a84228,
        72'h67b23a4f57fd58436a,
        72'h685b4fdf55d7b844b5,
        72'h6906906753a7784608,
        72'h69b40697516c584765,
        72'h6a63bd774f261048ca,
        72'h6b15c0674cd4584a38,
        72'h6bca1ae74a76d84bb1,
        72'h6c80d8f7480d484d33,
        72'h6d3a06cf4597504ebf,
        72'h6df5b0e74314a85057,
        72'h6eb3e4474084e851f9,
        72'h6f74ae173de7b853a7,
        72'h70381c073b3cc05560,
        72'h70fe3bf73883985726,
        72'h71c71c6735bbd858f8,
        72'h7292cc0732e5285ad8,
        72'h73615a172fff085cc5,
        72'h7432d6372d09105ec0,
        72'h750750672a02d060ca,
        72'h75ded94726ebc862e2,
        72'h76b981c723c380650b,
        72'h77975b7f2089706743,
        72'h787878671d3d18698c,
        72'h795ceb0f19ddf06be7,
        72'h7a44c69f166b586e54,
        72'h7b301eb712e4d070d3,
        72'h7c1f07af0f49a87366,
        72'h7d1196670b9950760d,
        72'h7e07e06707d31078c9,
        72'h7f01fbef03f6487b9b,
        72'h800000070001b07e9f
    };
    reg [8:0] base;
    always @(*) begin
        case (tbl)
            3'd0: base = 9'd0;
            3'd1: base = 9'd128;
            3'd2: base = 9'd256;
            3'd3: base = 9'd320;
            3'd4: base = 9'd384;
            3'd5: base = 9'd448;
            default: base = '0;
        endcase
    end
    wire [8:0] addr = base + 9'(idx);
    wire [DATAW-1:0] rd_data, rd_data_r;
    VX_rom #(
        .DATAW     (DATAW),
        .SIZE      (SIZE),
        .OUT_REG   (REGISTERED),
        .INIT_DATA (ROM_DATA)
    ) rom (
        .clk   (clk),
        .read  (enable),
        .addr  (addr),
        .rdata (rd_data)
    );
    VX_pipe_register #(
        .DATAW (DATAW),
        .DEPTH (REGISTERED)
    ) rd_reg (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (rd_data),
        .data_out (rd_data_r)
    );
    assign a0 = 32'({rd_data_r[71:43], 2'b0});
    assign a1 = 27'($signed({rd_data_r[42:19], 2'b0}));
    assign a2 = 20'($signed({rd_data_r[18:0], 1'b0}));
endmodule
module VX_ucc_ex2_prepare #(
    parameter W = 80,
    parameter NARROW = 0,
    parameter COMPACT = 0
) (
    input  wire [31:0]           a,
    input  wire                 natural,
    input  wire [54:0]          range_product,
    output wire [W-1:0]         align_data,
    output wire signed [11:0]   align_distance,
    input  wire [W-1:0]         aligned,
    output wire [15:0][10:0]    mul_a,
    output wire [15:0][10:0]    mul_b,
    input  wire [15:0][21:0]    products,
    output wire [16:0][W-1:0]   operands,
    output wire signed [11:0]   base_exp,
    output wire                 special,
    output wire [31:0]          special_result
);
    wire [7:0] e = a[30:23];
    assign align_data = natural ? W'(range_product) : W'({(|e), a[22:0]});
    assign align_distance = (natural ? 12'sd150 : 12'sd120) - 12'(e);
    wire [38:0] fixed_x = a[31] ? -aligned[38:0] : aligned[38:0];
    wire signed [8:0] integer_part = $signed(fixed_x[38:30]);
    wire [5:0] index = fixed_x[29:24];
    wire [17:0] residual = fixed_x[23:6];
    wire [31:0] a0;
    wire signed [26:0] a1;
    wire signed [19:0] a2;
    VX_mufu_rom #(
        .REGISTERED (0)
    ) coefficients (
        .clk    (1'b0),
        .enable (1'b1),
        .tbl    (3'd2),
        .idx    ({1'b0, index}),
        .a0     (a0),
        .a1     (a1),
        .a2     (a2)
    );
    if (COMPACT) begin : g_compact
        wire [32:0] linear_coefficient = 33'(a1);
        wire [21:0] linear_input = {4'd0, residual};
        for (genvar i = 0; i < 6; ++i) begin : g_linear
            assign mul_a[i] = linear_coefficient[(i/2)*11 +: 11];
            assign mul_b[i] = linear_input[(i%2)*11 +: 11];
            wire [W-1:0] term = W'(products[i]) << (11*((i/2)+(i%2)));
            assign operands[i] = NARROW ? term >> 18 : term;
        end
        assign mul_a[6] = residual[17:7];
        assign mul_b[6] = residual[17:7];
        assign mul_a[7] = a2[16:6];
        assign mul_b[7] = products[6][21:11];
        assign mul_a[15:8] = '0;
        assign mul_b[15:8] = '0;
        assign operands[6] = NARROW ? W'(products[7]) >> 5 : W'(products[7]) << 13;
        assign operands[7] = NARROW ? W'(a0) : W'(a0) << 18;
        assign operands[16:8] = '0;
    end else begin : g_full
        assign mul_a[0] = residual[10:0];
        assign mul_b[0] = residual[10:0];
        assign mul_a[1] = residual[10:0];
        assign mul_b[1] = {4'd0, residual[17:11]};
        assign mul_a[2] = {4'd0, residual[17:11]};
        assign mul_b[2] = {4'd0, residual[17:11]};
        wire [2:0][35:0] square_terms;
        assign square_terms[0] = 36'(products[0]);
        assign square_terms[1] = 36'(products[1]) << 12;
        assign square_terms[2] = 36'(products[2]) << 22;
        wire [35:0] square_sum, square_carry;
        VX_csa_tree #(
            .N (3),
            .W (36),
            .S (36)
        ) square_reduction (
            .operands (square_terms),
            .sum      (square_sum),
            .carry    (square_carry)
        );
        wire [35:0] square = square_sum + square_carry;
        wire [17:0] squared_residual = square[35:18];
        wire [32:0] linear_coefficient = 33'(a1);
        wire [21:0] quadratic_coefficient = 22'(a2);
        wire [21:0] linear_input = {4'd0, residual};
        wire [21:0] quadratic_input = {4'd0, squared_residual};
        for (genvar i = 0; i < 6; ++i) begin : g_linear
            assign mul_a[3+i] = linear_coefficient[(i/2)*11 +: 11];
            assign mul_b[3+i] = linear_input[(i%2)*11 +: 11];
            wire [W-1:0] term = W'(products[3+i]) << (11*((i/2)+(i%2)));
            assign operands[i] = NARROW ? term >> 18 : term;
        end
        for (genvar i = 0; i < 4; ++i) begin : g_quadratic
            assign mul_a[9+i] = quadratic_coefficient[(i/2)*11 +: 11];
            assign mul_b[9+i] = quadratic_input[(i%2)*11 +: 11];
            wire [W-1:0] term = W'(products[9+i]) << (11*((i/2)+(i%2)));
            assign operands[6+i] = NARROW ? term >> 18 : term;
        end
        assign mul_a[15:13] = '0;
        assign mul_b[15:13] = '0;
        assign operands[10] = NARROW ? W'(a0) : W'(a0) << 18;
        assign operands[16:11] = '0;
    end
    assign base_exp = 12'(integer_part) - (NARROW ? 12'sd30 : 12'sd48);
    wire nan_input = (&e) && (|a[22:0]);
    assign special = e == 0 || e >= (natural ? 134 : 135);
    assign special_result = nan_input ? 32'h7fc00000
                          : e == 0 ? 32'h3f800000
                          : a[31] ? 32'd0 : 32'h7f800000;
endmodule
module VX_ucc_exp_range (
    input  wire [31:0]       a,
    output wire [2:0][10:0]  wide_a,
    output wire [2:0][10:0]  wide_b,
    input  wire [2:0][21:0]  wide_products,
    output wire [31:0][3:0]  small_a,
    output wire [31:0][3:0]  small_b,
    input  wire [31:0][7:0]  small_products,
    output wire [54:0]      product
);
    localparam [30:0] LOG2E_Q30 = 31'h5c551d95;
    wire [23:0] significand = {(|a[30:23]), a[22:0]};
    wire [32:0][54:0] terms;
    for (genvar i = 0; i < 3; ++i) begin : g_high
        assign wide_a[i] = {3'd0, significand[i*8 +: 8]};
        assign wide_b[i] = LOG2E_Q30[30:20];
        assign terms[i] = 55'(wide_products[i]) << (20 + i*8);
    end
    for (genvar i = 0; i < 30; ++i) begin : g_low
        localparam COLUMN = i % 5;
        localparam ROW = i / 5;
        localparam OFFSET = 4 * (ROW + COLUMN);
        if (COLUMN == 3) begin : g_one
            assign small_a[i] = '0;
            assign small_b[i] = '0;
            assign terms[3+i] = 55'(significand[ROW*4 +: 4]) << OFFSET;
        end else begin : g_product
            assign small_a[i] = significand[ROW*4 +: 4];
            assign small_b[i] = LOG2E_Q30[COLUMN*4 +: 4];
            assign terms[3+i] = 55'(small_products[i]) << OFFSET;
        end
    end
    assign small_a[31:30] = '0;
    assign small_b[31:30] = '0;
    wire [54:0] sum_vec, carry_vec;
    VX_csa_tree #(
        .N (33),
        .W (55),
        .S (55)
    ) reduction (
        .operands (terms),
        .sum      (sum_vec),
        .carry    (carry_vec)
    );
    VX_ks_adder #(
        .N (55),
        .BYPASS (0)
    ) adder (
        .cin   (1'b0),
        .dataa (sum_vec),
        .datab (carry_vec),
        .sum   (product),
        . cout ()
    );
endmodule
module VX_ucc_exp_range_compact (
    input  wire [31:0]       a,
    output wire [5:0][10:0]  mul_a,
    output wire [5:0][10:0]  mul_b,
    input  wire [5:0][21:0]  products,
    output wire [54:0]      product
);
    localparam [32:0] LOG2E_Q30 = 33'h05c551d95;
    wire [23:0] significand = {(|a[30:23]), a[22:0]};
    wire [8:0][54:0] terms;
    for (genvar i = 0; i < 6; ++i) begin : g_product
        assign mul_a[i] = significand[(i/3)*11 +: 11];
        assign mul_b[i] = LOG2E_Q30[(i%3)*11 +: 11];
        assign terms[i] = 55'(products[i]) << (11*((i/3)+(i%3)));
    end
    for (genvar i = 0; i < 3; ++i) begin : g_high_digit
        localparam [12:0] COEFFICIENT = 13'(LOG2E_Q30[i*11 +: 11]);
        wire [12:0] value = significand[23:22] == 0 ? 13'd0
                           : significand[23:22] == 1 ? COEFFICIENT
                           : significand[23:22] == 2 ? COEFFICIENT*13'd2 : COEFFICIENT*13'd3;
        assign terms[6+i] = 55'(value) << (22+11*i);
    end
    wire [54:0] sum_vec, carry_vec;
    VX_csa_tree #(.N (9), .W (55), .S (55)) reduction (
        .operands (terms), .sum (sum_vec), .carry (carry_vec)
    );
    VX_ks_adder #(.N (55), .BYPASS (0)) adder (
        .cin (1'b0), .dataa (sum_vec), .datab (carry_vec), .sum (product),
        . cout ()
    );
endmodule
module VX_ucc_float_to_int #(
    parameter W = 80
) (
    input  wire [31:0]           a,
    input  wire                 unsigned_result,
    input  wire [1:0]           rm,
    output wire [W-1:0]         align_data,
    output wire signed [11:0]   align_distance,
    input  wire [W-1:0]         aligned,
    input  wire                 sticky,
    output wire [1:0][W-1:0]    operands,
    output wire [1:0]           negatives,
    input  wire [W-1:0]         sum,
    output wire [31:0]          result,
    output wire [4:0]           flags
);
    wire [7:0] e = a[30:23];
    wire sign = a[31];
    wire signed [11:0] exponent = e == 0 ? -12'sd126 : 12'(e) - 12'sd127;
    assign align_data = W'({(|e), a[22:0]});
    assign align_distance = 12'sd20 - exponent;
    wire [31:0] kept = aligned[34:3];
    wire guard_bit = aligned[2];
    wire tail = (|aligned[1:0]) || sticky;
    wire inexact = guard_bit || tail;
    wire increment = (rm == 0 && guard_bit && (tail || kept[0]))
                   || (rm == 2 && sign && inexact)
                   || (rm == 3 && !sign && inexact);
    assign operands[0] = sign ? ~W'(kept) : W'(kept);
    assign operands[1] = sign ? ~W'(increment) : W'(increment);
    assign negatives = {2{sign}};
    wire nan_input = (&e) && (|a[22:0]);
    wire invalid_unsigned = exponent >= 32 || (sign && (|sum));
    wire invalid_signed = exponent > 31
                       || (exponent == 31 && (!sign || sum != W'($signed(32'h80000000))));
    wire invalid = (&e) || (unsigned_result ? invalid_unsigned : invalid_signed);
    wire [31:0] saturated = nan_input ? 32'd0
                         : unsigned_result ? (sign ? 32'd0 : 32'hffffffff)
                         : sign ? 32'h80000000 : 32'h7fffffff;
    assign result = invalid ? saturated : sum[31:0];
    assign flags = {invalid, 3'd0, (inexact && !invalid)};
endmodule
module VX_ucc_shift_jam #(
    parameter W = 80,
    parameter SW = 10
) (
    input  wire [W-1:0]  data_in,
    input  wire [SW-1:0] amount,
    input  wire          left,
    input  wire          fill,
    output wire [W-1:0] data_out,
    output wire          sticky
);
    localparam LEVELS = $clog2(W);
    wire [LEVELS:0][W-1:0] stage;
    wire [LEVELS:0] lost;
    wire [W-1:0] shifted;
    wire over = amount >= SW'(W);
    assign lost[0] = 1'b0;
    for (genvar i = 0; i < W; ++i) begin : g_reverse
        assign stage[0][i] = left ? data_in[W-1-i] : data_in[i];
        assign shifted[i] = left ? stage[LEVELS][W-1-i] : stage[LEVELS][i];
    end
    for (genvar s = 0; s < LEVELS; ++s) begin : g_stage
        localparam D = 1 << s;
        assign stage[s+1] = amount[s] ? {{D{fill && !left}}, stage[s][W-1:D]} : stage[s];
        assign lost[s+1] = lost[s] | (amount[s] && (|stage[s][D-1:0]));
    end
    assign data_out = over ? {W{fill && !left}} : shifted;
    assign sticky = !left && (over ? (|data_in) : lost[LEVELS]);
endmodule
module VX_ucc_fma_prepare #(
    parameter W = 80,
    parameter CHUNK = 11,
    parameter REDUCE_FIRST = 0,
    parameter ANCHORED = 0,
    parameter CROP_PRODUCTS = 0
) (
    input  wire [31:0]             a,
    input  wire [31:0]             b,
    input  wire [31:0]             c,
    input  wire [1:0]              op,
    input  wire [1:0]              rm,
    input  wire [31:0]             raw_sum,
    output wire [8:0][10:0]        mul_a,
    output wire [8:0][10:0]        mul_b,
    input  wire [8:0][21:0]        products,
    input  wire [1:0][W-1:0]       reduced_products,
    output wire [2:0][W-1:0]       post_operands,
    output wire [2:0]              post_negatives,
    input  wire                    external_align,
    input  wire [W-1:0]            align_data,
    input  wire signed [11:0]      align_distance,
    output wire [W-1:0]            align_result,
    output wire                    align_sticky,
    output wire [9:0][W-1:0]       operands,
    output wire [9:0]              negatives,
    output wire signed [11:0]     base_exp,
    output wire                    zero_sign,
    output wire                    special,
    output wire [31:0]             special_result,
    output wire [4:0]              special_flags
);
    wire [31:0] x = a;
    wire [31:0] y = op[1] ? 32'h3f800000 : b;
    wire psign = x[31] ^ y[31];
    wire [31:0] z = op[1] ? {b[31] ^ op[0], b[30:0]}
                         : op[0] ? {psign, 31'd0} : c;
    wire [7:0] ex = x[30:23], ey = y[30:23], ez = z[30:23];
    wire [23:0] mx = {(|ex), x[22:0]}, my = {(|ey), y[22:0]}, mz = {(|ez), z[22:0]};
    wire xzero = x[30:0] == 0, yzero = y[30:0] == 0, zzero = z[30:0] == 0;
    wire xnan = (&ex) && (|x[22:0]), ynan = (&ey) && (|y[22:0]), znan = (&ez) && (|z[22:0]);
    wire xinf = (&ex) && !(|x[22:0]), yinf = (&ey) && !(|y[22:0]), zinf = (&ez) && !(|z[22:0]);
    wire snan = (xnan && !x[22]) || (ynan && !y[22]) || (znan && !z[22]);
    wire bad_product = (xinf && yzero) || (yinf && xzero);
    wire pinf = (xinf || yinf) && !(xnan || ynan || bad_product);
    wire bad_sum = pinf && zinf && (psign != z[31]);
    wire invalid = snan || bad_product || bad_sum;
    wire nan_result = xnan || ynan || znan || invalid;
    wire pzero = xzero || yzero;
    assign zero_sign = pzero && zzero && (psign == z[31]) ? psign : rm == 2;
    wire signed [11:0] xe = (ex == 0) ? -12'sd149 : 12'({1'b0, ex}) - 12'sd150;
    wire signed [11:0] ye = (ey == 0) ? -12'sd149 : 12'({1'b0, ey}) - 12'sd150;
    wire signed [11:0] ze = (ez == 0) ? -12'sd149 : 12'({1'b0, ez}) - 12'sd150;
    wire signed [11:0] pe = xe + ye;
    wire signed [11:0] ptop = pzero ? -12'sd1024 : pe + 12'sd47;
    wire signed [11:0] ctop = zzero ? -12'sd1024 : ze + 12'sd23;
    wire dominant_c = ANCHORED && !zzero && (pzero || ctop >= ptop + 12'sd27);
    wire step_up = !pzero && psign == z[31] && ((rm == 3 && !z[31]) || (rm == 2 && z[31]));
    wire step_down = !pzero && psign != z[31] && (rm == 1 || (rm == 3 && z[31]) || (rm == 2 && !z[31]));
    wire dominant_overflow = !pzero && step_up && z[30:0] == 31'h7f7fffff;
    wire dominant_tiny = !pzero && (ez == 0 || (z[30:0] == 31'h00800000 && step_down));
    assign special = nan_result || pinf || zinf || dominant_c;
    assign special_result = nan_result ? 32'h7fc00000
                          : pinf || zinf ? {pinf ? psign : z[31], 8'hff, 23'd0} : raw_sum;
    assign special_flags = nan_result || pinf || zinf ? {invalid, 4'd0}
                         : {2'b00, dominant_overflow, dominant_tiny, !pzero};
    assign base_exp = ANCHORED ? pe - 12'sd3
                              : ((ptop > ctop) ? ptop : ctop) - 12'(W-3);
    wire [32:0] xa = {9'd0, mx}, ya = {9'd0, my};
    for (genvar i = 0; i < 9; ++i) begin : g_product
        localparam OFFSET = CHUNK * ((i / 3) + (i % 3));
        localparam A_BITS = (i/3 == 2) ? 24-2*CHUNK : CHUNK;
        localparam B_BITS = (i%3 == 2) ? 24-2*CHUNK : CHUNK;
        localparam PRODUCT_BITS = CROP_PRODUCTS ? A_BITS+B_BITS : 22;
        wire [PRODUCT_BITS-1:0] product = products[i][PRODUCT_BITS-1:0];
        assign mul_a[i] = 11'(xa[(i/3)*CHUNK +: CHUNK]);
        assign mul_b[i] = 11'(ya[(i%3)*CHUNK +: CHUNK]);
        if (ANCHORED) begin : g_fixed
            wire [W-1:0] magnitude = W'(product) << (OFFSET+3);
            wire [W-1:0] encoded_c = i == 0 ? W'(z)
                                   : i == 1 ? (W'(step_up) | {W{step_down}}) : '0;
            assign operands[i] = dominant_c ? encoded_c : psign ? ~magnitude : magnitude;
            assign negatives[i] = !dominant_c && psign;
        end else if (REDUCE_FIRST) begin : g_raw
            assign operands[i] = W'(product) << OFFSET;
            assign negatives[i] = 1'b0;
        end else begin : g_aligned
            wire signed [11:0] distance = base_exp - pe - 12'(OFFSET);
            wire left = distance < 0;
            wire [11:0] amount = left ? 12'(-distance) : 12'(distance);
            wire [W-1:0] shifted;
            wire sticky;
            VX_ucc_shift_jam #(.W (W), .SW (12)) align (
                .data_in (W'(product)), .amount (amount), .left (left), .fill (1'b0),
                .data_out (shifted), .sticky (sticky)
            );
            wire [W-1:0] jammed = shifted | W'(sticky);
            assign operands[i] = psign ? ~jammed : jammed;
            assign negatives[i] = psign;
        end
    end
    wire signed [11:0] c_distance = external_align ? align_distance : base_exp - ze;
    wire c_left = c_distance < 0;
    wire [11:0] c_amount = c_left ? 12'(-c_distance) : 12'(c_distance);
    wire [W-1:0] c_shifted;
    wire c_sticky;
    VX_ucc_shift_jam #(
        .W  (W),
        .SW (12)
    ) align_c (
        .data_in  (external_align ? align_data : W'(mz)),
        .amount   (c_amount),
        .left     (c_left),
        .fill     (1'b0),
        .data_out (c_shifted),
        .sticky   (c_sticky)
    );
    wire [W-1:0] c_jammed = c_shifted | W'(c_sticky);
    assign align_result = c_shifted;
    assign align_sticky = c_sticky;
    assign operands[9] = REDUCE_FIRST || dominant_c ? '0 : z[31] ? ~c_jammed : c_jammed;
    assign negatives[9] = !REDUCE_FIRST && !dominant_c && z[31];
    if (REDUCE_FIRST) begin : g_post_alignment
        wire signed [11:0] distance = base_exp - pe;
        wire left = distance < 0;
        wire [11:0] amount = left ? 12'(-distance) : 12'(distance);
        for (genvar i = 0; i < 2; ++i) begin : g_row
            wire [W-1:0] shifted;
            wire sticky;
            VX_ucc_shift_jam #(.W (W), .SW (12)) align (
                .data_in (W'(reduced_products[i][47:0])), .amount (amount),
                .left (left), .fill (1'b0), .data_out (shifted), .sticky (sticky)
            );
            wire [W-1:0] jammed = shifted | W'(sticky);
            assign post_operands[i] = psign ? ~jammed : jammed;
            assign post_negatives[i] = psign;
        end
        assign post_operands[2] = z[31] ? ~c_jammed : c_jammed;
        assign post_negatives[2] = z[31];
    end else begin : g_no_post_alignment
        assign post_operands = '0;
        assign post_negatives = '0;
    end
endmodule
module VX_ucc_fp_compare (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [7:0]  op,
    input  wire        unsigned_less,
    output wire [31:0] result,
    output wire        predicate,
    output wire [4:0]  flags
);
    wire an = (&a[30:23]) && (|a[22:0]);
    wire bn = (&b[30:23]) && (|b[22:0]);
    wire nan_input = an || bn;
    wire zeros = a[30:0] == 0 && b[30:0] == 0;
    wire equal = a == b || zeros;
    wire less = !zeros && ((a[31] != b[31]) ? a[31]
                       : a[31] ? (!unsigned_less && a != b) : unsigned_less);
    logic compare;
    always_comb begin
        case (op[2:0])
            3'd0: compare = !nan_input && equal;
            3'd1: compare = nan_input || !equal;
            3'd2: compare = !nan_input && less;
            3'd3: compare = !nan_input && (less || equal);
            3'd4: compare = !nan_input && !(less || equal);
            3'd5: compare = !nan_input && !less;
            default: compare = !nan_input && less;
        endcase
    end
    wire minmax = op[2:1] == 3;
    wire zero_sign = op[0] ? a[31] && b[31] : a[31] || b[31];
    wire [31:0] ordered = zeros ? {zero_sign, 31'd0} : (less ^ op[0]) ? a : b;
    wire [31:0] minimum_maximum = an && bn ? 32'h7fc00000 : an ? b : bn ? a : ordered;
    assign result = minmax ? minimum_maximum : {31'd0, compare};
    assign predicate = compare;
    assign flags = {((an && !a[22]) || (bn && !b[22])), 4'd0};
endmodule
module VX_ucc_int_prepare #(
    parameter W = 80
) (
    input  wire [31:0]            a,
    input  wire [31:0]            b,
    input  wire [7:0]             op,
    output wire [8:0][10:0]       mul_a,
    output wire [8:0][10:0]       mul_b,
    input  wire [8:0][21:0]       products,
    output wire [16:0][W-1:0]     operands,
    output wire [16:0]            negatives,
    input  wire [W-1:0]           sum,
    output wire [31:0]            result,
    output wire                   predicate
);
    wire multiply = op >= 8'h14 && op <= 8'h17;
    wire negate = op == 8'h12 || (op == 8'h13 && a[31]);
    wire absolute = op == 8'h13;
    wire passthrough = op >= 8'h30;
    wire subtract = op == 8'h11 || op >= 8'h18 || (op >= 8'h08 && op <= 8'h0f);
    wire sign_extend = op == 8'h32 || op == 8'h40;
    wire signed_a = op == 8'h16 || op == 8'h17;
    wire signed_b = op == 8'h16;
    wire correction_a = signed_a && a[31];
    wire correction_b = signed_b && b[31];
    wire [32:0] xa = {1'b0, a};
    wire [32:0] xb = {1'b0, b};
    for (genvar i = 0; i < 17; ++i) begin : g_operand
        if (i < 9) begin : g_product
            assign mul_a[i] = xa[(i/3)*11 +: 11];
            assign mul_b[i] = xb[(i%3)*11 +: 11];
            wire [W-1:0] partial = W'(products[i]) << (11*((i/3)+(i%3)));
            if (i == 0) begin : g_first
                assign operands[i] = multiply ? partial : negate ? ~W'(a)
                                   : sign_extend ? W'($signed(a)) : W'(a);
                assign negatives[i] = !multiply && negate;
            end else if (i == 1) begin : g_second
                assign operands[i] = multiply ? partial : (negate || absolute || passthrough) ? '0
                                   : subtract ? ~W'(b) : W'(b);
                assign negatives[i] = !multiply && subtract && !(negate || absolute || passthrough);
            end else begin : g_remaining
                assign operands[i] = multiply ? partial : '0;
                assign negatives[i] = 1'b0;
            end
        end else if (i == 9) begin : g_signed_a
            assign operands[i] = multiply && correction_a ? ~(W'(b) << 32) : '0;
            assign negatives[i] = multiply && correction_a;
        end else if (i == 10) begin : g_signed_b
            assign operands[i] = multiply && correction_b ? ~(W'(a) << 32) : '0;
            assign negatives[i] = multiply && correction_b;
        end else begin : g_zero
            assign operands[i] = '0;
            assign negatives[i] = 1'b0;
        end
    end
    wire equal = sum[31:0] == 0;
    wire unsigned_compare = op[5];
    wire less = !unsigned_compare && (a[31] != b[31]) ? a[31] : sum[32];
    logic comparison;
    always_comb begin
        case (op[2:0])
            3'd0: comparison = equal;
            3'd1: comparison = !equal;
            3'd2: comparison = less;
            3'd3: comparison = less || equal;
            3'd4: comparison = !(less || equal);
            3'd5: comparison = !less;
            default: comparison = less;
        endcase
    end
    wire compare_op = op[3] && (op[2:0] <= 5);
    wire minmax = op[3] && (op[2:1] == 3);
    wire high_product = multiply && op != 8'h14;
    assign predicate = compare_op ? comparison : minmax && less;
    assign result = compare_op ? {31'd0, comparison}
                  : minmax ? ((less ^ op[0]) ? a : b)
                  : high_product ? sum[63:32] : sum[31:0];
    if (W > 64) begin : g_unused_high
    end
endmodule
module VX_ucc_partitioned_acc #(
    parameter N = 17
) (
    input  wire [N-1:0][63:0] operands,
    input  wire [N-1:0]      negatives,
    input  wire [N-1:0]      sticky_in,
    input  wire              full_product,
    output wire [63:0]      sum,
    output wire [31:0]      magnitude,
    output wire              sign,
    output wire              sticky_out
);
    wire [$clog2(N+1)-1:0] corrections;
    VX_popcount #(
        .N (N)
    ) popcount (
        .data_in  (negatives),
        .data_out (corrections)
    );
    wire [N:0][63:0] terms;
    assign terms[N-1:0] = operands;
    assign terms[N] = 64'(corrections);
    wire [63:0] sum_vec, carry_vec;
    VX_csa_tree #(
        .N (N+1),
        .W (64),
        .S (64)
    ) reduction (
        .operands (terms),
        .sum      (sum_vec),
        .carry    (carry_vec)
    );
    wire [31:0] low, high_or_negative;
    wire carry_low;
    VX_ks_adder #(
        .N (32),
        .BYPASS (0)
    ) low_adder (
        .cin   (1'b0),
        .dataa (sum_vec[31:0]),
        .datab (carry_vec[31:0]),
        .sum   (low),
        .cout  (carry_low)
    );
    VX_ks_adder #(
        .N (32),
        .BYPASS (0)
    ) high_adder (
        .cin   (full_product ? carry_low : 1'b1),
        .dataa (full_product ? sum_vec[63:32] : ~sum_vec[31:0]),
        .datab (full_product ? carry_vec[63:32] : ~carry_vec[31:0]),
        .sum   (high_or_negative),
        . cout ()
    );
    wire [31:0] negative_magnitude = high_or_negative + 32'd1;
    assign sum = {full_product ? high_or_negative : {32{low[31]}}, low};
    assign sign = low[31];
    assign magnitude = sign ? negative_magnitude : low;
    assign sticky_out = |sticky_in;
endmodule
module VX_find_first #(
    parameter N       = 1,
    parameter DATAW   = 1,
    parameter REVERSE = 0  
) (
    input  wire [N-1:0][DATAW-1:0] data_in,
    input  wire [N-1:0]            valid_in,
    output wire [DATAW-1:0]        data_out,
    output wire                    valid_out
);
    localparam LOGN = $clog2(N);
    localparam TL   = (1 << LOGN) - 1;
    localparam TN   = (1 << (LOGN+1)) - 1;
    reg             valid_r;
    reg [DATAW-1:0] data_r;
    always @(*) begin : g_scan
        reg [TN-1:0]       s_n;
        reg [TN*DATAW-1:0] d_n;
        s_n = '0;
        d_n = '0;
        for (integer i = 0; i < N; ++i) begin
            s_n[TL+i] = REVERSE ? valid_in[N-1-i] : valid_in[i];
            d_n[(TL+i)*DATAW +: DATAW] = REVERSE ? data_in[N-1-i] : data_in[i];
        end
        for (integer k = TL-1; k >= 0; --k) begin
            s_n[k] = s_n[2*k+2] | s_n[2*k+1];
            d_n[k*DATAW +: DATAW] = s_n[2*k+1] ? d_n[(2*k+1)*DATAW +: DATAW] : d_n[(2*k+2)*DATAW +: DATAW];
        end
        valid_r = s_n[0];
        data_r  = d_n[0 +: DATAW];
    end
    assign valid_out = valid_r;
    assign data_out  = data_r;
endmodule
module VX_lzc #(
    parameter N       = 2,
    parameter REVERSE = 0,   
    parameter LOGN    = (((N) > 1) ? $clog2(N) : 1)
) (
    input  wire [N-1:0]    data_in,
    output wire [LOGN-1:0] data_out,
    output wire            valid_out
);
    if (N == 1) begin : g_passthru
        assign data_out  = '0;
        assign valid_out = data_in;
    end else begin : g_lzc
        wire [N-1:0][LOGN-1:0] indices;
        for (genvar i = 0; i < N; ++i) begin : g_indices
            assign indices[i] = REVERSE ? LOGN'(i) : LOGN'(N-1-i);
        end
        VX_find_first #(
            .N       (N),
            .DATAW   (LOGN),
            .REVERSE (!REVERSE)
        ) find_first (
            .valid_in  (data_in),
            .data_in   (indices),
            .data_out  (data_out),
            .valid_out (valid_out)
        );
    end
endmodule
module VX_ucc_round #(
    parameter W = 80,
    parameter DIRECT_DISTANCE = 0
) (
    input  wire [W-1:0]       magnitude,
    input  wire signed [11:0] base_exp,
    input  wire               sign,
    input  wire [1:0]         rm,
    input  wire               sticky_in,
    input  wire               dpa,
    input  wire               shift_mode,
    input  wire               shift_left,
    input  wire               shift_signed,
    input  wire [4:0]         shift_count,
    output wire [31:0]        shift_result,
    output wire [31:0]        clz_result,
    output wire [31:0]        result,
    output wire [4:0]         flags
);
    wire [$clog2(W)-1:0] lz;
    wire nonzero;
    VX_lzc #(
        .N (W)
    ) lzc (
        .data_in   (magnitude),
        .data_out  (lz),
        .valid_out (nonzero)
    );
    wire signed [11:0] exponent = base_exp + 12'(W-1) - 12'(lz);
    wire subnormal = !dpa && (exponent < -12'sd126);
    wire signed [11:0] quantum = subnormal ? -12'sd149 : exponent - 12'sd23;
    wire signed [11:0] distance = DIRECT_DISTANCE
                               ? (subnormal ? -12'sd152 - base_exp : 12'(W-27) - 12'(lz))
                               : quantum - base_exp - 12'sd3;
    wire left = shift_mode ? shift_left : distance < 0;
    wire [11:0] shift_amount = shift_mode ? 12'(shift_count)
                            : left ? 12'(-distance) : 12'(distance);
    wire [W-1:0] shifted;
    wire shift_sticky;
    VX_ucc_shift_jam #(
        .W  (W),
        .SW (12)
    ) shifter (
        .data_in  (magnitude),
        .amount   (shift_amount),
        .left     (left),
        .fill     (shift_mode && shift_signed),
        .data_out (shifted),
        .sticky   (shift_sticky)
    );
    assign shift_result = shifted[31:0];
    assign clz_result = nonzero ? 32'(lz) - 32'(W-32) : 32'd32;
    wire [23:0] kept = shifted[26:3];
    wire guard_bit = shifted[2];
    wire round_bit = shifted[1];
    wire tail = shifted[0] | shift_sticky | sticky_in;
    wire inexact = guard_bit | round_bit | tail;
    wire increment = ((rm == 0) && guard_bit && (round_bit || tail || kept[0]))
                   || ((rm == 2) && sign && inexact)
                   || ((rm == 3) && !sign && inexact);
    wire [24:0] rounded = {1'b0, kept} + 25'(increment);
    wire [23:0] significand = rounded[24] ? rounded[24:1] : rounded[23:0];
    wire signed [11:0] out_exp = quantum + 12'sd150 + 12'(rounded[24]);
    wire overflow = out_exp >= 255;
    wire to_inf = (rm == 0) || ((rm == 2) && sign) || ((rm == 3) && !sign);
    wire ub_inexact = round_bit | tail;
    wire ub_increment = ((rm == 0) && round_bit && (tail || guard_bit))
                      || ((rm == 2) && sign && ub_inexact)
                      || ((rm == 3) && !sign && ub_inexact);
    wire [24:0] ub_rounded = {1'b0, kept[22:0], guard_bit} + 25'(ub_increment);
    wire tiny = (exponent < -127) || ((exponent == -127) && !ub_rounded[24]);
    wire [7:0] packed_exp = significand[23] ? 8'(out_exp) : 8'd0;
    wire [31:0] finite_result = {sign, packed_exp, significand[22:0]};
    wire [31:0] overflow_result = {sign, (to_inf ? 31'h7f800000 : 31'h7f7fffff)};
    wire flush = dpa && out_exp <= 0;
    assign result = !nonzero || flush ? {sign, 31'd0}
                  : overflow ? overflow_result : finite_result;
    assign flags = dpa || !nonzero ? 5'd0 : {2'b00, overflow, (tiny && inexact), (inexact || overflow)};
endmodule
module VX_ucc_comb import VX_tcu_pkg::*; #(
    parameter W = 80,
    parameter CHUNK = 11,
    parameter ENABLE_INT = 0,
    parameter ENABLE_AUX = 0,
    parameter ENABLE_BOOL = 0,
    parameter ENABLE_EX2 = 0,
    parameter NATIVE_FP = 0,
    parameter SHARED_ALIGN = 0,
    parameter SMALL_NATIVE = 0,
    parameter ENABLE_EXP = 0,
    parameter FMA_CSA = 0,
    parameter DIRECT_NORM = 0,
    parameter ONEHOT_ROUTE = 0,
    parameter EXP_CONST = 0,
    parameter COMPACT_EXP = 0,
    parameter FMA_ANCHORED = 0,
    parameter FMA_CROP = 0
) (
    input  wire                dpa,
    input  wire [4:0]          fmt,
    input  wire [63:0]         mask,
    input  wire [7:0][31:0]    a_vec,
    input  wire [7:0][31:0]    b_vec,
    input  wire [3:0][7:0]     scale_a,
    input  wire [3:0][7:0]     scale_b,
    input  wire [31:0]         a,
    input  wire [31:0]         b,
    input  wire [31:0]         c,
    input  wire [7:0]          op,
    input  wire [1:0]          rm,
    input  wire [7:0]          immediate,
    output wire [31:0]         result,
    output wire [4:0]          flags,
    output wire                predicate
);
    wire [W-1:0] raw_sum;
    wire [1:0][W-1:0] reduced_products;
    wire [2:0][W-1:0] post_operands;
    wire [2:0] post_negatives;
    localparam NORM_W = SMALL_NATIVE ? 32 : W;
    wire [15:0][10:0] tensor_ma, tensor_mb;
    wire [15:0][21:0] products;
    wire [31:0][3:0] tensor_f8_ma, tensor_f8_mb, range_small_a, range_small_b;
    wire [31:0][7:0] f8_products;
    wire [2:0][10:0] range_wide_a, range_wide_b;
    wire [5:0][10:0] compact_range_a, compact_range_b;
    wire [54:0] range_product;
    wire [8:0][10:0] scalar_ma, scalar_mb;
    wire [9:0][W-1:0] scalar_operands;
    wire [9:0] scalar_negs;
    wire signed [11:0] scalar_base;
    wire zero_sign, scalar_special;
    wire [31:0] scalar_special_result;
    wire [4:0] scalar_special_flags;
    wire [16:0][TCU_EXP_BITS-1:0] exponents;
    wire [16:0] exp_sel;
    wire [16:0][24:0] raw_sigs, native_sigs;
    wire [16:0][9:0] native_exponents;
    wire native_mode = NATIVE_FP && !dpa && op <= 8'h03;
    wire tensor_format_mode = dpa || native_mode;
    fedp_excep_t exceptions;
    wire [15:0] lane_mask;
    wire [TCU_EXP_BITS-1:0] max_exp;
    wire [16:0][31:0] aligned;
    wire [16:0] tensor_sticky, tensor_negs;
    VX_tcu_tfr_shared_mul #(
        .N            (8),
        .W            (25),
        .WA           (32),
        .SF           (4),
        .USE_DSP      (0),
        .PROD_REG     (0),
        .EXTERNAL_MUL (1),
        .EXTERNAL_EXP (NATIVE_FP),
        .EXTERNAL_F8 (ENABLE_EXP && !EXP_CONST && !COMPACT_EXP)
    ) tensor_prepare (
        .clk               (1'b0),
        .enable            (1'b1),
        .valid_in          (1'b0),
        .req_id            (32'd0),
        .vld_mask          (mask),
        .fmt_s             (fmt),
        .a_row             (a_vec),
        .b_col             (b_vec),
        .c_val             (c),
        .sf_a              (scale_a),
        .sf_b              (scale_b),
        .mantissa_a        (tensor_ma),
        .mantissa_b        (tensor_mb),
        .external_products (products),
        .external_exp_enable (native_mode),
        .external_exponents (native_exponents),
        .f8_mantissa_a (tensor_f8_ma),
        .f8_mantissa_b (tensor_f8_mb),
        .external_f8_products (f8_products),
        .exponents         (exponents),
        .exp_sel           (exp_sel),
        .raw_sigs          (raw_sigs),
        .exceptions        (exceptions),
        .lane_mask         (lane_mask)
    );
    wire shift_mode = ENABLE_AUX && op[7:4] == 3 && !dpa;
    wire int_to_float = ENABLE_AUX && (op == 8'h40 || op == 8'h41) && !dpa;
    wire float_to_int = ENABLE_AUX && (op == 8'h42 || op == 8'h43) && !dpa;
    wire fp_compare = ENABLE_AUX && op >= 8'h08 && op <= 8'h0f && !dpa;
    wire fp_sign_op = ENABLE_AUX && (op == 8'h04 || op == 8'h05) && !dpa;
    wire integer_arithmetic = ENABLE_INT && (op[7:4] == 1 || op[7:4] == 2) && !dpa;
    wire exp_mode = ENABLE_EXP && op == 8'h61 && !dpa;
    wire ex2_mode = (ENABLE_EX2 && op == 8'h60 && !dpa) || exp_mode;
    wire [15:0][10:0] ex2_ma, ex2_mb;
    wire [16:0][W-1:0] ex2_operands;
    wire [W-1:0] ex2_align_data;
    wire signed [11:0] ex2_align_distance, ex2_base;
    wire ex2_special;
    wire [31:0] ex2_special_result;
    wire boolean_mode = ENABLE_BOOL && op[7:4] == 5 && !dpa;
    wire [31:0] boolean_result;
    if (ENABLE_BOOL) begin : g_boolean
        VX_ucc_boolean boolean_unit (
            .a         (a),
            .b         (b),
            .c         (c),
            .immediate (immediate),
            .op        (op[2:0]),
            .result    (boolean_result)
        );
    end else begin : g_no_boolean
        assign boolean_result = '0;
    end
    wire [W-1:0] conversion_data, conversion_aligned;
    wire signed [11:0] conversion_distance;
    wire conversion_sticky;
    wire [51:0] shared_alignment_result;
    wire shared_alignment_sticky;
    wire signed [11:0] shared_alignment_distance = (ex2_mode ? ex2_align_distance : conversion_distance) + (exp_mode ? -12'sd3 : 12'sd14);
    wire [7:0] shared_alignment_amount = shared_alignment_distance < 0 ? 8'd0 : 8'(shared_alignment_distance);
    wire [51:0] shared_alignment_data = exp_mode ? range_product[54:3] : {14'd0, (|a[30:23]), a[22:0], 14'd0};
    wire [1:0][W-1:0] conversion_operands;
    wire [1:0] conversion_negs;
    wire [31:0] conversion_result, comparison_result;
    wire [4:0] conversion_flags, comparison_flags;
    wire comparison_predicate;
    if (NATIVE_FP) begin : g_native_fp
        assign post_operands = '0;
        assign post_negatives = '0;
        VX_ucc_bf16x9_prepare prepare (
            .a              (a),
            .b              (b),
            .c              (c),
            .op             (op[1:0]),
            .mul_a          (scalar_ma),
            .mul_b          (scalar_mb),
            .products       (products[8:0]),
            .exponents      (native_exponents),
            .significands   (native_sigs),
            .zero_sign      (zero_sign),
            .special        (scalar_special),
            .special_result (scalar_special_result),
            .flags          (scalar_special_flags)
        );
        assign scalar_operands = '0;
        assign scalar_negs = '0;
        assign scalar_base = 12'(max_exp) - 12'sd318;
        if (SHARED_ALIGN) begin : g_paired_alignment
            assign conversion_aligned = W'(shared_alignment_result);
            assign conversion_sticky = shared_alignment_sticky;
        end else if (ENABLE_AUX || ENABLE_EX2) begin : g_external_alignment
            wire signed [11:0] distance = ex2_mode ? ex2_align_distance : conversion_distance;
            wire left = distance < 0;
            wire [11:0] amount = left ? 12'(-distance) : 12'(distance);
            VX_ucc_shift_jam #(
                .W  (W),
                .SW (12)
            ) shifter (
                .data_in  (ex2_mode ? ex2_align_data : conversion_data),
                .amount   (amount),
                .left     (left),
                .fill     (1'b0),
                .data_out (conversion_aligned),
                .sticky   (conversion_sticky)
            );
        end else begin : g_no_external_alignment
            assign conversion_aligned = '0;
            assign conversion_sticky = 1'b0;
        end
    end else begin : g_exact_fp
        assign native_exponents = '0;
        assign native_sigs = '0;
        VX_ucc_fma_prepare #(
            .REDUCE_FIRST (FMA_CSA),
            .ANCHORED (FMA_ANCHORED),
            .CROP_PRODUCTS (FMA_CROP),
            .W     (W),
            .CHUNK (CHUNK)
        ) scalar_prepare (
            .raw_sum (raw_sum[31:0]),
            .reduced_products (reduced_products),
            .post_operands (post_operands),
            .post_negatives (post_negatives),
            .a              (a),
            .b              (b),
            .c              (c),
            .op             (op[1:0]),
            .rm             (rm),
            .mul_a          (scalar_ma),
            .mul_b          (scalar_mb),
            .products       (products[8:0]),
            .external_align (float_to_int || ex2_mode),
            .align_data     (ex2_mode ? ex2_align_data : conversion_data),
            .align_distance (ex2_mode ? ex2_align_distance : conversion_distance),
            .align_result   (conversion_aligned),
            .align_sticky   (conversion_sticky),
            .operands       (scalar_operands),
            .negatives      (scalar_negs),
            .base_exp       (scalar_base),
            .zero_sign      (zero_sign),
            .special        (scalar_special),
            .special_result (scalar_special_result),
            .special_flags  (scalar_special_flags)
        );
    end
    wire integer_mode = integer_arithmetic || shift_mode || int_to_float || fp_compare;
    wire [8:0][10:0] integer_ma, integer_mb;
    wire [16:0][W-1:0] integer_operands;
    wire [16:0] integer_negs;
    wire [31:0] integer_result;
    wire integer_predicate;
    if (ENABLE_INT || ENABLE_AUX) begin : g_integer
        VX_ucc_int_prepare #(
            .W (W)
        ) prepare (
            .a          (a),
            .b          (b),
            .op         (op),
            .mul_a      (integer_ma),
            .mul_b      (integer_mb),
            .products   (products[8:0]),
            .operands   (integer_operands),
            .negatives  (integer_negs),
            .sum        (raw_sum),
            .result     (integer_result),
            .predicate  (integer_predicate)
        );
    end else begin : g_no_integer
        assign integer_ma = '0;
        assign integer_mb = '0;
        assign integer_operands = '0;
        assign integer_negs = '0;
        assign integer_result = '0;
        assign integer_predicate = 1'b0;
    end
    if (ENABLE_AUX) begin : g_auxiliary
        VX_ucc_float_to_int #(
            .W (W)
        ) convert (
            .a               (a),
            .unsigned_result (op[0]),
            .rm              (rm),
            .align_data      (conversion_data),
            .align_distance  (conversion_distance),
            .aligned         (conversion_aligned),
            .sticky          (conversion_sticky),
            .operands        (conversion_operands),
            .negatives       (conversion_negs),
            .sum             (raw_sum),
            .result          (conversion_result),
            .flags           (conversion_flags)
        );
        VX_ucc_fp_compare compare (
            .a             (a),
            .b             (b),
            .op            (op),
            .unsigned_less (raw_sum[32]),
            .result        (comparison_result),
            .predicate     (comparison_predicate),
            .flags         (comparison_flags)
        );
    end else begin : g_no_auxiliary
        assign conversion_data = '0;
        assign conversion_distance = '0;
        assign conversion_operands = '0;
        assign conversion_negs = '0;
        assign conversion_result = '0;
        assign conversion_flags = '0;
        assign comparison_result = '0;
        assign comparison_predicate = 1'b0;
        assign comparison_flags = '0;
    end
    if (ENABLE_EXP && EXP_CONST) begin : g_constant_range
        assign compact_range_a = '0;
        assign compact_range_b = '0;
        assign range_product = {(|a[30:23]), a[22:0]} * 31'h5c551d95;
        assign range_wide_a = '0;
        assign range_wide_b = '0;
        assign range_small_a = '0;
        assign range_small_b = '0;
        assign f8_products = '0;
    end else if (ENABLE_EXP && COMPACT_EXP) begin : g_compact_range
        VX_ucc_exp_range_compact prepare (
            .a (a), .mul_a (compact_range_a), .mul_b (compact_range_b),
            .products (products[13:8]), .product (range_product)
        );
        assign range_wide_a = '0;
        assign range_wide_b = '0;
        assign range_small_a = '0;
        assign range_small_b = '0;
        assign f8_products = '0;
    end else if (ENABLE_EXP) begin : g_exp_range
        assign compact_range_a = '0;
        assign compact_range_b = '0;
        VX_ucc_exp_range prepare (
            .a              (a),
            .wide_a         (range_wide_a),
            .wide_b         (range_wide_b),
            .wide_products  (products[15:13]),
            .small_a        (range_small_a),
            .small_b        (range_small_b),
            .small_products (f8_products),
            .product        (range_product)
        );
        for (genvar i = 0; i < 32; ++i) begin : g_slice
            wire [3:0] ma, mb;
            if (i < 30 && i % 5 != 3) begin : g_shared
                assign ma = exp_mode ? range_small_a[i] : tensor_f8_ma[i];
                assign mb = exp_mode ? range_small_b[i] : tensor_f8_mb[i];
            end else begin : g_tensor
                assign ma = tensor_f8_ma[i];
                assign mb = tensor_f8_mb[i];
            end
            VX_tcu_tfr_wmul #(
                .N (4)
            ) multiplier (
                .clk    (1'b0),
                .enable (1'b1),
                .a      (ma),
                .b      (mb),
                .p      (f8_products[i])
            );
        end
    end else begin : g_no_exp_range
        assign compact_range_a = '0;
        assign compact_range_b = '0;
        assign range_wide_a = '0;
        assign range_wide_b = '0;
        assign range_small_a = '0;
        assign range_small_b = '0;
        assign range_product = '0;
        assign f8_products = '0;
    end
    if (ENABLE_EX2) begin : g_ex2
        wire [15:0][10:0] polynomial_a, polynomial_b;
        for (genvar i = 0; i < 16; ++i) begin : g_routing
            if (COMPACT_EXP && i >= 8 && i < 14) begin : g_range
                assign ex2_ma[i] = exp_mode ? compact_range_a[i-8] : 11'd0;
                assign ex2_mb[i] = exp_mode ? compact_range_b[i-8] : 11'd0;
            end else begin : g_polynomial
                assign ex2_ma[i] = polynomial_a[i];
                assign ex2_mb[i] = polynomial_b[i];
            end
        end
        VX_ucc_ex2_prepare #(
            .W (W),
            .NARROW (SMALL_NATIVE),
            .COMPACT (COMPACT_EXP)
        ) prepare (
            .a              (a),
            .natural        (exp_mode),
            .range_product  (range_product),
            .align_data     (ex2_align_data),
            .align_distance (ex2_align_distance),
            .aligned        (conversion_aligned),
            .mul_a          (polynomial_a),
            .mul_b          (polynomial_b),
            .products       (products),
            .operands       (ex2_operands),
            .base_exp       (ex2_base),
            .special        (ex2_special),
            .special_result (ex2_special_result)
        );
    end else begin : g_no_ex2
        assign ex2_ma = '0;
        assign ex2_mb = '0;
        assign ex2_operands = '0;
        assign ex2_align_data = '0;
        assign ex2_align_distance = '0;
        assign ex2_base = '0;
        assign ex2_special = 1'b0;
        assign ex2_special_result = '0;
    end
    for (genvar i = 0; i < 16; ++i) begin : g_mul
        wire [10:0] ma, mb;
        if (i < 9) begin : g_scalar
            if (ONEHOT_ROUTE) begin : g_parallel
                wire scalar_select = !ex2_mode && !dpa && !integer_mode;
                assign ma = ({11{ex2_mode}} & ex2_ma[i]) | ({11{dpa}} & tensor_ma[i])
                          | ({11{integer_mode}} & integer_ma[i]) | ({11{scalar_select}} & scalar_ma[i]);
                assign mb = ({11{ex2_mode}} & ex2_mb[i]) | ({11{dpa}} & tensor_mb[i])
                          | ({11{integer_mode}} & integer_mb[i]) | ({11{scalar_select}} & scalar_mb[i]);
            end else begin : g_priority
                assign ma = ex2_mode ? ex2_ma[i] : dpa ? tensor_ma[i] : integer_mode ? integer_ma[i] : scalar_ma[i];
                assign mb = ex2_mode ? ex2_mb[i] : dpa ? tensor_mb[i] : integer_mode ? integer_mb[i] : scalar_mb[i];
            end
        end else if (i >= 13 && !COMPACT_EXP) begin : g_range
            assign ma = exp_mode ? range_wide_a[i-13] : ex2_mode ? ex2_ma[i] : tensor_ma[i];
            assign mb = exp_mode ? range_wide_b[i-13] : ex2_mode ? ex2_mb[i] : tensor_mb[i];
        end else begin : g_tensor
            assign ma = ex2_mode ? ex2_ma[i] : tensor_ma[i];
            assign mb = ex2_mode ? ex2_mb[i] : tensor_mb[i];
        end
        VX_tcu_tfr_wmul #(
            .N (11)
        ) multiplier (
            .clk    (1'b0),
            .enable (1'b1),
            .a      (ma),
            .b      (mb),
            .p      (products[i])
        );
    end
    VX_tcu_tfr_align #(
        .N  (17),
        .WI (25),
        .WO (32),
        .SHARED_SHIFT (SHARED_ALIGN)
    ) tensor_align (
        .clk         (1'b0),
        .valid_in    (1'b0),
        .req_id      (32'd0),
        .exponents   (exponents),
        .sel_exp     (exp_sel),
        .lane_mask   (native_mode ? 16'h01ff : lane_mask),
        .sigs_in     (native_mode ? native_sigs : raw_sigs),
        .is_int      (1'b0),
        .external_shift (float_to_int || ex2_mode),
        .external_data (shared_alignment_data),
        .external_amount (shared_alignment_amount),
        .external_result (shared_alignment_result),
        .external_sticky (shared_alignment_sticky),
        .max_exp     (max_exp),
        .sigs_out    (aligned),
        .sticky_bits (tensor_sticky),
        .fp_negs     (tensor_negs)
    );
    wire [16:0][W-1:0] operands;
    wire [16:0] negatives;
    for (genvar i = 0; i < 17; ++i) begin : g_acc_mux
        wire [W-1:0] converted;
        wire converted_negative;
        if (i < 2) begin : g_conversion
            assign converted = conversion_operands[i];
            assign converted_negative = conversion_negs[i];
        end else begin : g_no_conversion
            assign converted = '0;
            assign converted_negative = 1'b0;
        end
        if (i < 10) begin : g_scalar
            if (ONEHOT_ROUTE) begin : g_parallel
                wire scalar_select = !ex2_mode && !float_to_int && !integer_mode && !tensor_format_mode;
                wire [W-1:0] tensor_operand = SMALL_NATIVE ? W'(aligned[i]) : W'($signed(aligned[i]));
                assign operands[i] = ({W{ex2_mode}} & ex2_operands[i]) | ({W{float_to_int}} & converted)
                                   | ({W{integer_mode}} & integer_operands[i]) | ({W{tensor_format_mode}} & tensor_operand)
                                   | ({W{scalar_select}} & scalar_operands[i]);
                assign negatives[i] = (float_to_int && converted_negative) || (integer_mode && integer_negs[i])
                                    || (tensor_format_mode && tensor_negs[i]) || (scalar_select && scalar_negs[i]);
            end else begin : g_priority
                assign operands[i] = ex2_mode ? ex2_operands[i] : float_to_int ? converted : integer_mode ? integer_operands[i] : tensor_format_mode ? (SMALL_NATIVE ? W'(aligned[i]) : W'($signed(aligned[i]))) : scalar_operands[i];
                assign negatives[i] = ex2_mode ? 1'b0 : float_to_int ? converted_negative : integer_mode ? integer_negs[i] : tensor_format_mode ? tensor_negs[i] : scalar_negs[i];
            end
        end else begin : g_tensor
            if (ONEHOT_ROUTE) begin : g_parallel
                wire [W-1:0] tensor_operand = SMALL_NATIVE ? W'(aligned[i]) : W'($signed(aligned[i]));
                assign operands[i] = ({W{ex2_mode}} & ex2_operands[i]) | ({W{float_to_int}} & converted)
                                   | ({W{integer_mode}} & integer_operands[i]) | ({W{tensor_format_mode}} & tensor_operand);
                assign negatives[i] = (float_to_int && converted_negative) || (integer_mode && integer_negs[i])
                                    || (tensor_format_mode && tensor_negs[i]);
            end else begin : g_priority
                assign operands[i] = ex2_mode ? ex2_operands[i] : float_to_int ? converted : integer_mode ? integer_operands[i] : tensor_format_mode ? (SMALL_NATIVE ? W'(aligned[i]) : W'($signed(aligned[i]))) : '0;
                assign negatives[i] = ex2_mode ? 1'b0 : float_to_int ? converted_negative : integer_mode ? integer_negs[i] : tensor_format_mode && tensor_negs[i];
            end
        end
    end
    wire [W-1:0] magnitude;
    wire sign, sticky;
    if (SMALL_NATIVE) begin : g_partitioned_accumulator
        assign reduced_products = '0;
        wire [31:0] small_magnitude;
        VX_ucc_partitioned_acc #(
            .N (17)
        ) accumulator (
            .operands     (operands),
            .negatives    (negatives),
            .sticky_in    (tensor_format_mode ? tensor_sticky : 17'd0),
            .full_product (integer_arithmetic || fp_compare || float_to_int),
            .sum          (raw_sum),
            .magnitude    (small_magnitude),
            .sign         (sign),
            .sticky_out   (sticky)
        );
        assign magnitude = W'(small_magnitude);
    end else begin : g_wide_accumulator
        VX_tcu_tfr_acc #(
            .POST_REDUCE (FMA_CSA),
            .N  (17),
            .WO (W)
        ) accumulator (
            .post_enable (FMA_CSA && !dpa && op <= 8'h03),
            .post_operands (post_operands),
            .post_negatives (post_negatives),
            .reduced_sigs (reduced_products),
            .clk        (1'b0),
            .valid_in   (1'b0),
            .req_id     (32'd0),
            .sigs_in    (operands),
            .sticky_in  (tensor_format_mode ? tensor_sticky : 17'd0),
            .fp_negs    (negatives),
            .sum_out    (raw_sum),
            .sig_out    (magnitude),
            .sign_out   (sign),
            .sticky_out (sticky)
        );
    end
    wire signed [11:0] base_exp = ex2_mode ? ex2_base : dpa ? 12'(max_exp) - 12'sd286 : int_to_float ? 12'sd0 : scalar_base;
    wire [31:0] rounded_result, shifted_result, clz_result;
    wire [4:0] rounded_flags;
    VX_ucc_round #(
        .W (NORM_W),
        .DIRECT_DISTANCE (DIRECT_NORM)
    ) rounder (
        .magnitude (NORM_W'(shift_mode || (SMALL_NATIVE && int_to_float && op[0]) ? raw_sum : magnitude)),
        .base_exp  (base_exp),
        .sign      (SMALL_NATIVE && int_to_float && op[0] ? 1'b0 : dpa || int_to_float || (|magnitude) ? sign : zero_sign),
        .rm        (tensor_format_mode || ex2_mode ? 2'd0 : rm),
        .sticky_in (sticky),
        .dpa       (tensor_format_mode),
        .shift_mode (shift_mode),
        .shift_left (op == 8'h30),
        .shift_signed (op == 8'h32 && a[31]),
        .shift_count (b[4:0]),
        .shift_result (shifted_result),
        .clz_result (clz_result),
        .result    (rounded_result),
        .flags     (rounded_flags)
    );
    assign predicate = fp_compare ? comparison_predicate : integer_arithmetic && integer_predicate;
    assign result = ex2_mode ? (ex2_special ? ex2_special_result : rounded_result)
                  : boolean_mode ? boolean_result
                  : fp_sign_op ? {op[0] ? 1'b0 : !a[31], a[30:0]}
                  : fp_compare ? comparison_result
                  : shift_mode ? (op == 8'h33 ? clz_result : shifted_result)
                  : int_to_float ? rounded_result
                  : float_to_int ? conversion_result
                  : integer_arithmetic ? integer_result : dpa ? (exceptions.is_nan ? 32'h7fc00000
                         : exceptions.is_inf ? {exceptions.sign, 8'hff, 23'd0}
                         : rounded_result)
                       : scalar_special ? scalar_special_result : rounded_result;
    assign flags = ex2_mode || boolean_mode || fp_sign_op || shift_mode || integer_arithmetic || dpa ? 5'd0
                 : fp_compare ? comparison_flags
                 : float_to_int ? conversion_flags
                 : int_to_float ? rounded_flags
                 : native_mode ? scalar_special_flags
                 : scalar_special ? scalar_special_flags : rounded_flags;
endmodule
module VX_ucc_v4_compact_unpaired_comb import VX_tcu_pkg::*; #(
    parameter W = 64,
    parameter CHUNK = 11,
    parameter SHARED_ALIGN = 0,
    parameter DIRECT_NORM = 0,
    parameter ONEHOT_ROUTE = 0,
    parameter EXP_CONST = 0,
    parameter COMPACT_EXP = 1
) (
    input  wire                dpa,
    input  wire [4:0]          fmt,
    input  wire [63:0]         mask,
    input  wire [7:0][31:0]    a_vec,
    input  wire [7:0][31:0]    b_vec,
    input  wire [3:0][7:0]     scale_a,
    input  wire [3:0][7:0]     scale_b,
    input  wire [31:0]         a,
    input  wire [31:0]         b,
    input  wire [31:0]         c,
    input  wire [7:0]          op,
    input  wire [1:0]          rm,
    input  wire [7:0]          immediate,
    output wire [31:0]         result,
    output wire [4:0]          flags,
    output wire                predicate
);
    VX_ucc_comb #(
        .W          (W),
        .CHUNK      (CHUNK),
        .ENABLE_INT (1),
        .ENABLE_AUX (1),
        .ENABLE_BOOL (1),
        .ENABLE_EX2 (1),
        .NATIVE_FP (1),
        .SHARED_ALIGN (SHARED_ALIGN),
        .DIRECT_NORM (DIRECT_NORM),
        .ONEHOT_ROUTE (ONEHOT_ROUTE),
        .EXP_CONST (EXP_CONST),
        .COMPACT_EXP (COMPACT_EXP),
        .SMALL_NATIVE (1),
        .ENABLE_EXP (1)
    ) core (
        .dpa       (dpa),
        .fmt       (fmt),
        .mask      (mask),
        .a_vec     (a_vec),
        .b_vec     (b_vec),
        .scale_a   (scale_a),
        .scale_b   (scale_b),
        .a         (a),
        .b         (b),
        .c         (c),
        .op        (op),
        .rm        (rm),
        .immediate (immediate),
        .result    (result),
        .flags     (flags),
        .predicate (predicate)
    );
endmodule
