# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.10-p002_1 on Fri Nov 06 13:45:45 PST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design VX_ucc_coeff_replica_p1

create_clock -name "virtual_clock" -period 5.0 -waveform {0.0 2.5} 
set_load -pin_load 0.005 [get_ports {coefficients[78]}]
set_load -pin_load 0.005 [get_ports {coefficients[77]}]
set_load -pin_load 0.005 [get_ports {coefficients[76]}]
set_load -pin_load 0.005 [get_ports {coefficients[75]}]
set_load -pin_load 0.005 [get_ports {coefficients[74]}]
set_load -pin_load 0.005 [get_ports {coefficients[73]}]
set_load -pin_load 0.005 [get_ports {coefficients[72]}]
set_load -pin_load 0.005 [get_ports {coefficients[71]}]
set_load -pin_load 0.005 [get_ports {coefficients[70]}]
set_load -pin_load 0.005 [get_ports {coefficients[69]}]
set_load -pin_load 0.005 [get_ports {coefficients[68]}]
set_load -pin_load 0.005 [get_ports {coefficients[67]}]
set_load -pin_load 0.005 [get_ports {coefficients[66]}]
set_load -pin_load 0.005 [get_ports {coefficients[65]}]
set_load -pin_load 0.005 [get_ports {coefficients[64]}]
set_load -pin_load 0.005 [get_ports {coefficients[63]}]
set_load -pin_load 0.005 [get_ports {coefficients[62]}]
set_load -pin_load 0.005 [get_ports {coefficients[61]}]
set_load -pin_load 0.005 [get_ports {coefficients[60]}]
set_load -pin_load 0.005 [get_ports {coefficients[59]}]
set_load -pin_load 0.005 [get_ports {coefficients[58]}]
set_load -pin_load 0.005 [get_ports {coefficients[57]}]
set_load -pin_load 0.005 [get_ports {coefficients[56]}]
set_load -pin_load 0.005 [get_ports {coefficients[55]}]
set_load -pin_load 0.005 [get_ports {coefficients[54]}]
set_load -pin_load 0.005 [get_ports {coefficients[53]}]
set_load -pin_load 0.005 [get_ports {coefficients[52]}]
set_load -pin_load 0.005 [get_ports {coefficients[51]}]
set_load -pin_load 0.005 [get_ports {coefficients[50]}]
set_load -pin_load 0.005 [get_ports {coefficients[49]}]
set_load -pin_load 0.005 [get_ports {coefficients[48]}]
set_load -pin_load 0.005 [get_ports {coefficients[47]}]
set_load -pin_load 0.005 [get_ports {coefficients[46]}]
set_load -pin_load 0.005 [get_ports {coefficients[45]}]
set_load -pin_load 0.005 [get_ports {coefficients[44]}]
set_load -pin_load 0.005 [get_ports {coefficients[43]}]
set_load -pin_load 0.005 [get_ports {coefficients[42]}]
set_load -pin_load 0.005 [get_ports {coefficients[41]}]
set_load -pin_load 0.005 [get_ports {coefficients[40]}]
set_load -pin_load 0.005 [get_ports {coefficients[39]}]
set_load -pin_load 0.005 [get_ports {coefficients[38]}]
set_load -pin_load 0.005 [get_ports {coefficients[37]}]
set_load -pin_load 0.005 [get_ports {coefficients[36]}]
set_load -pin_load 0.005 [get_ports {coefficients[35]}]
set_load -pin_load 0.005 [get_ports {coefficients[34]}]
set_load -pin_load 0.005 [get_ports {coefficients[33]}]
set_load -pin_load 0.005 [get_ports {coefficients[32]}]
set_load -pin_load 0.005 [get_ports {coefficients[31]}]
set_load -pin_load 0.005 [get_ports {coefficients[30]}]
set_load -pin_load 0.005 [get_ports {coefficients[29]}]
set_load -pin_load 0.005 [get_ports {coefficients[28]}]
set_load -pin_load 0.005 [get_ports {coefficients[27]}]
set_load -pin_load 0.005 [get_ports {coefficients[26]}]
set_load -pin_load 0.005 [get_ports {coefficients[25]}]
set_load -pin_load 0.005 [get_ports {coefficients[24]}]
set_load -pin_load 0.005 [get_ports {coefficients[23]}]
set_load -pin_load 0.005 [get_ports {coefficients[22]}]
set_load -pin_load 0.005 [get_ports {coefficients[21]}]
set_load -pin_load 0.005 [get_ports {coefficients[20]}]
set_load -pin_load 0.005 [get_ports {coefficients[19]}]
set_load -pin_load 0.005 [get_ports {coefficients[18]}]
set_load -pin_load 0.005 [get_ports {coefficients[17]}]
set_load -pin_load 0.005 [get_ports {coefficients[16]}]
set_load -pin_load 0.005 [get_ports {coefficients[15]}]
set_load -pin_load 0.005 [get_ports {coefficients[14]}]
set_load -pin_load 0.005 [get_ports {coefficients[13]}]
set_load -pin_load 0.005 [get_ports {coefficients[12]}]
set_load -pin_load 0.005 [get_ports {coefficients[11]}]
set_load -pin_load 0.005 [get_ports {coefficients[10]}]
set_load -pin_load 0.005 [get_ports {coefficients[9]}]
set_load -pin_load 0.005 [get_ports {coefficients[8]}]
set_load -pin_load 0.005 [get_ports {coefficients[7]}]
set_load -pin_load 0.005 [get_ports {coefficients[6]}]
set_load -pin_load 0.005 [get_ports {coefficients[5]}]
set_load -pin_load 0.005 [get_ports {coefficients[4]}]
set_load -pin_load 0.005 [get_ports {coefficients[3]}]
set_load -pin_load 0.005 [get_ports {coefficients[2]}]
set_load -pin_load 0.005 [get_ports {coefficients[1]}]
set_load -pin_load 0.005 [get_ports {coefficients[0]}]
set_max_delay 5 -from [list \
  [get_ports {indices[5]}]  \
  [get_ports {indices[4]}]  \
  [get_ports {indices[3]}]  \
  [get_ports {indices[2]}]  \
  [get_ports {indices[1]}]  \
  [get_ports {indices[0]}] ] -to [list \
  [get_ports {coefficients[78]}]  \
  [get_ports {coefficients[77]}]  \
  [get_ports {coefficients[76]}]  \
  [get_ports {coefficients[75]}]  \
  [get_ports {coefficients[74]}]  \
  [get_ports {coefficients[73]}]  \
  [get_ports {coefficients[72]}]  \
  [get_ports {coefficients[71]}]  \
  [get_ports {coefficients[70]}]  \
  [get_ports {coefficients[69]}]  \
  [get_ports {coefficients[68]}]  \
  [get_ports {coefficients[67]}]  \
  [get_ports {coefficients[66]}]  \
  [get_ports {coefficients[65]}]  \
  [get_ports {coefficients[64]}]  \
  [get_ports {coefficients[63]}]  \
  [get_ports {coefficients[62]}]  \
  [get_ports {coefficients[61]}]  \
  [get_ports {coefficients[60]}]  \
  [get_ports {coefficients[59]}]  \
  [get_ports {coefficients[58]}]  \
  [get_ports {coefficients[57]}]  \
  [get_ports {coefficients[56]}]  \
  [get_ports {coefficients[55]}]  \
  [get_ports {coefficients[54]}]  \
  [get_ports {coefficients[53]}]  \
  [get_ports {coefficients[52]}]  \
  [get_ports {coefficients[51]}]  \
  [get_ports {coefficients[50]}]  \
  [get_ports {coefficients[49]}]  \
  [get_ports {coefficients[48]}]  \
  [get_ports {coefficients[47]}]  \
  [get_ports {coefficients[46]}]  \
  [get_ports {coefficients[45]}]  \
  [get_ports {coefficients[44]}]  \
  [get_ports {coefficients[43]}]  \
  [get_ports {coefficients[42]}]  \
  [get_ports {coefficients[41]}]  \
  [get_ports {coefficients[40]}]  \
  [get_ports {coefficients[39]}]  \
  [get_ports {coefficients[38]}]  \
  [get_ports {coefficients[37]}]  \
  [get_ports {coefficients[36]}]  \
  [get_ports {coefficients[35]}]  \
  [get_ports {coefficients[34]}]  \
  [get_ports {coefficients[33]}]  \
  [get_ports {coefficients[32]}]  \
  [get_ports {coefficients[31]}]  \
  [get_ports {coefficients[30]}]  \
  [get_ports {coefficients[29]}]  \
  [get_ports {coefficients[28]}]  \
  [get_ports {coefficients[27]}]  \
  [get_ports {coefficients[26]}]  \
  [get_ports {coefficients[25]}]  \
  [get_ports {coefficients[24]}]  \
  [get_ports {coefficients[23]}]  \
  [get_ports {coefficients[22]}]  \
  [get_ports {coefficients[21]}]  \
  [get_ports {coefficients[20]}]  \
  [get_ports {coefficients[19]}]  \
  [get_ports {coefficients[18]}]  \
  [get_ports {coefficients[17]}]  \
  [get_ports {coefficients[16]}]  \
  [get_ports {coefficients[15]}]  \
  [get_ports {coefficients[14]}]  \
  [get_ports {coefficients[13]}]  \
  [get_ports {coefficients[12]}]  \
  [get_ports {coefficients[11]}]  \
  [get_ports {coefficients[10]}]  \
  [get_ports {coefficients[9]}]  \
  [get_ports {coefficients[8]}]  \
  [get_ports {coefficients[7]}]  \
  [get_ports {coefficients[6]}]  \
  [get_ports {coefficients[5]}]  \
  [get_ports {coefficients[4]}]  \
  [get_ports {coefficients[3]}]  \
  [get_ports {coefficients[2]}]  \
  [get_ports {coefficients[1]}]  \
  [get_ports {coefficients[0]}] ]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[5]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[4]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[3]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[2]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[1]}]
set_input_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {indices[0]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[78]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[77]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[76]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[75]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[74]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[73]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[72]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[71]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[70]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[69]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[68]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[67]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[66]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[65]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[64]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[63]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[62]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[61]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[60]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[59]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[58]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[57]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[56]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[55]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[54]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[53]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[52]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[51]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[50]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[49]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[48]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[47]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[46]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[45]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[44]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[43]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[42]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[41]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[40]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[39]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[38]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[37]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[36]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[35]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[34]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[33]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[32]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[31]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[30]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[29]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[28]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[27]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[26]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[25]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[24]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[23]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[22]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[21]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[20]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[19]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[18]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[17]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[16]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[15]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[14]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[13]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[12]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[11]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[10]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[9]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[8]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[7]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[6]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[5]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[4]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[3]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[2]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[1]}]
set_output_delay -clock [get_clocks virtual_clock] -add_delay 0.0 [get_ports {coefficients[0]}]
set_input_transition 0.05 [get_ports {indices[5]}]
set_input_transition 0.05 [get_ports {indices[4]}]
set_input_transition 0.05 [get_ports {indices[3]}]
set_input_transition 0.05 [get_ports {indices[2]}]
set_input_transition 0.05 [get_ports {indices[1]}]
set_input_transition 0.05 [get_ports {indices[0]}]
set_wire_load_mode "segmented"
