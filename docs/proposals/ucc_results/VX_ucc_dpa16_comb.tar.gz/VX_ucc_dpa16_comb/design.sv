package VX_gpu_pkg;
    localparam NC_BITS = $clog2(1);
    localparam NW_BITS = $clog2(4);
    localparam NT_BITS = $clog2(64);
    localparam NB_BITS = $clog2(8);
    localparam NC_WIDTH = (((NC_BITS) > 0) ? (NC_BITS) : 1);
    localparam NW_WIDTH = (((NW_BITS) > 0) ? (NW_BITS) : 1);
    localparam NT_WIDTH = (((NT_BITS) > 0) ? (NT_BITS) : 1);
    localparam NB_WIDTH = (((NB_BITS) > 0) ? (NB_BITS) : 1);
    localparam NUM_CTA_MAX = 4;
    localparam NCTA_BITS  = $clog2(NUM_CTA_MAX);
    localparam NCTA_WIDTH = (((NCTA_BITS) > 0) ? (NCTA_BITS) : 1);
    localparam XLENB    = 32 / 8;
    localparam XLENB_W  = $clog2(XLENB);
    localparam BYTESEL_BITS = (XLENB_W + XLENB_W);
    localparam [BYTESEL_BITS-1:0] BYTESEL_DEFAULT = {XLENB_W'(XLENB-1), XLENB_W'(0)};
    localparam RV_REGS = 32;
    localparam RV_REGS_BITS = 5;
    localparam RV_RD  = 0;
    localparam RV_RS1 = 1;
    localparam RV_RS2 = 2;
    localparam RV_RS3 = 3;
    localparam REG_TYPE_I = 0;
    localparam REG_TYPE_F = 1;
    localparam REG_TYPES = 1 + 1;
    localparam NUM_REGS = (REG_TYPES * RV_REGS);
    localparam REG_TYPE_BITS = (((REG_TYPES) > 1) ? $clog2(REG_TYPES) : 1);
    localparam NUM_REGS_BITS = $clog2(NUM_REGS);
    localparam XREG_0      = 0;
    localparam XREG_1      = 1;
    localparam NUM_XREGS   = 2;
    localparam DV_STACK_SIZE = (((64-1) > 0) ? (64-1) : 1);
    localparam DV_STACK_SIZEW = (((DV_STACK_SIZE) > 1) ? $clog2(DV_STACK_SIZE) : 1);
    localparam PERF_CTR_BITS = 44;
    localparam SIMD_COUNT = 64 / 64;
    localparam SIMD_IDX_BITS = $clog2(SIMD_COUNT);
    localparam SIMD_IDX_W = (((SIMD_IDX_BITS) > 0) ? (SIMD_IDX_BITS) : 1);
    localparam NUM_OPCS_BITS = $clog2(1);
    localparam NUM_OPCS_W = (((NUM_OPCS_BITS) > 0) ? (NUM_OPCS_BITS) : 1);
    localparam BAR_ADDR_BITS = NW_BITS + NB_BITS;
    localparam BAR_ADDR_W = (((BAR_ADDR_BITS) > 0) ? (BAR_ADDR_BITS) : 1);
    localparam BAR_ID_SHIFT = 8;
    localparam BAR_SIZE_W = ((((((NW_WIDTH) > (NC_WIDTH)) ? (NW_WIDTH) : (NC_WIDTH))) > ($clog2(32))) ? ((((NW_WIDTH) > (NC_WIDTH)) ? (NW_WIDTH) : (NC_WIDTH))) : ($clog2(32)));
    localparam UOP_PACKLD = 0;
    localparam UOP_TCU = UOP_PACKLD + 1;
    localparam UOP_GFX = UOP_TCU + 1;
    localparam UOP_MAX = UOP_GFX + 0;
    localparam UOP_CTR_W = 8;
    localparam CTA_TID_WIDTH = (((NW_BITS + NT_BITS) > 0) ? (NW_BITS + NT_BITS) : 1);
    localparam UUID_WIDTH = 44;
    localparam PC_BITS = 32;
    function automatic logic [32-1:0] to_fullPC(input logic[PC_BITS-1:0] pc);
        to_fullPC = 32'(pc);
    endfunction
    function automatic logic [PC_BITS-1:0] from_fullPC(input logic[32-1:0] pc);
        from_fullPC = pc;
    endfunction
    localparam NUM_SRC_OPDS = 3;
    localparam SRC_OPD_BITS = $clog2(NUM_SRC_OPDS);
    localparam SRC_OPD_WIDTH = (((SRC_OPD_BITS) > 0) ? (SRC_OPD_BITS) : 1);
    localparam NUM_SOCKETS = (((1 / 1) > 0) ? (1 / 1) : 1);
    localparam NUM_STACKS = 1 * NUM_SOCKETS * 1 * 4 * 64;
    localparam [32-1:0] STACK_WINDOW_TOP    = 32'(32'hFFFF0000);
    localparam [32-1:0] STACK_WINDOW_SPAN   = 32'(NUM_STACKS) << 13;
    localparam [32-1:0] STACK_WINDOW_BOTTOM = STACK_WINDOW_TOP - STACK_WINDOW_SPAN;
    localparam HART_ID_BITS = NC_BITS + NW_BITS + NT_BITS;
    localparam HART_ID_WIDTH = (((HART_ID_BITS) > 0) ? (HART_ID_BITS) : 1);
    typedef enum logic [3:0] {
        AMO_OP_LR    = 4'h0,
        AMO_OP_SC    = 4'h1,
        AMO_OP_ADD   = 4'h2,
        AMO_OP_SWAP  = 4'h3,
        AMO_OP_XOR   = 4'h4,
        AMO_OP_OR    = 4'h5,
        AMO_OP_AND   = 4'h6,
        AMO_OP_MIN   = 4'h7,
        AMO_OP_MAX   = 4'h8,
        AMO_OP_CAS   = 4'h9
    } amo_op_e;
    typedef struct packed {
        logic [HART_ID_WIDTH-1:0]   hart_id;
        logic                        amo_unsigned;
        amo_op_e                     amo_op;
        logic                        amo_valid;
    } amo_req_t;
    localparam AMO_REQ_BITS = $bits(amo_req_t);
    typedef struct packed {
        amo_req_t                    amo;            
        logic                        is_addr_om;     
        logic                        is_addr_local;  
        logic                        is_addr_io;     
        logic                        is_flush;       
    } mem_bus_attr_t;
    localparam MEM_ATTR_FLUSH_OFFS  = 0;
    localparam MEM_ATTR_IO_OFFS     = 1;
    localparam MEM_ATTR_LOCAL_OFFS  = 2;
    localparam MEM_ATTR_OM_OFFS     = 3;
    localparam MEM_ATTR_AMO_OFFS    = 4;
    localparam MEM_ATTR_WIDTH = $bits(mem_bus_attr_t);
    localparam VX_DCR_ADDR_WIDTH = 12;
    localparam VX_DCR_DATA_WIDTH = 32;
    localparam STALL_TIMEOUT = 100000;
    localparam EX_ALU = 0;
    localparam EX_LSU = 1;
    localparam EX_SFU = 2;
    localparam EX_FPU = (EX_SFU + 1);
    localparam EX_TCU = (EX_FPU + 1);
    localparam NUM_EX_UNITS = EX_TCU + 1;
    localparam EX_BITS = $clog2(NUM_EX_UNITS);
    localparam EX_WIDTH = (((EX_BITS) > 0) ? (EX_BITS) : 1);
    localparam SFU_BITS = $clog2(2);
    localparam SFU_WIDTH = (((SFU_BITS) > 0) ? (SFU_BITS) : 1);
    localparam SFU_CSRS = 0;
    localparam SFU_WCTL = 1;
    localparam NUM_SFU_UNITS = (2);
    localparam INST_LUI =        7'b0110111;
    localparam INST_AUIPC =      7'b0010111;
    localparam INST_JAL =        7'b1101111;
    localparam INST_JALR =       7'b1100111;
    localparam INST_B =          7'b1100011;  
    localparam INST_L =          7'b0000011;  
    localparam INST_S =          7'b0100011;  
    localparam INST_I =          7'b0010011;  
    localparam INST_R =          7'b0110011;  
    localparam INST_V =          7'b1010111;  
    localparam INST_FENCE =      7'b0001111;  
    localparam INST_AMO =        7'b0101111;  
    localparam INST_SYS =        7'b1110011;  
    localparam INST_I_W =        7'b0011011;  
    localparam INST_R_W =        7'b0111011;  
    localparam INST_FL =         7'b0000111;  
    localparam INST_FS =         7'b0100111;  
    localparam INST_FMADD =      7'b1000011;
    localparam INST_FMSUB =      7'b1000111;
    localparam INST_FNMSUB =     7'b1001011;
    localparam INST_FNMADD =     7'b1001111;
    localparam INST_FCI =        7'b1010011;  
    localparam INST_EXT1 =       7'b0001011;  
    localparam INST_EXT2 =       7'b0101011;  
    localparam INST_EXT3 =       7'b1011011;  
    localparam INST_EXT4 =       7'b1111011;  
    localparam INST_R_F7_MUL =   7'b0000001;
    localparam INST_R_F7_ZICOND= 7'b0000111;
    localparam INST_FRM_RNE =    3'b000;   
    localparam INST_FRM_RTZ =    3'b001;   
    localparam INST_FRM_RDN =    3'b010;   
    localparam INST_FRM_RUP =    3'b011;   
    localparam INST_FRM_RMM =    3'b100;   
    localparam INST_FRM_DYN =    3'b111;   
    localparam INST_FRM_BITS =   3;
    localparam INST_OP_BITS =    4;
    localparam INST_FMT_BITS =   2;
    localparam INST_ALU_ADD =    4'b0000;
    localparam INST_ALU_LUI =    4'b0010;
    localparam INST_ALU_AUIPC =  4'b0011;
    localparam INST_ALU_SLTU =   4'b0100;
    localparam INST_ALU_SLT =    4'b0101;
    localparam INST_ALU_SUB =    4'b0111;
    localparam INST_ALU_SRL =    4'b1000;
    localparam INST_ALU_SRA =    4'b1001;
    localparam INST_ALU_CZEQ =   4'b1010;
    localparam INST_ALU_CZNE =   4'b1011;
    localparam INST_ALU_AND =    4'b1100;
    localparam INST_ALU_OR =     4'b1101;
    localparam INST_ALU_XOR =    4'b1110;
    localparam INST_ALU_SLL =    4'b1111;
    localparam INST_ALU_BITS =   4;
    localparam ALU_TYPE_BITS =   2;
    localparam ALU_TYPE_ARITH =  0;
    localparam ALU_TYPE_BRANCH = 1;
    localparam ALU_TYPE_MULDIV = 2;
    localparam ALU_TYPE_OTHER =  3;
    function automatic logic [1:0] inst_alu_class(input logic [INST_ALU_BITS-1:0] op);
        return op[3:2];
    endfunction
    function automatic logic inst_alu_signed(input logic [INST_ALU_BITS-1:0] op);
        return op[0];
    endfunction
    function automatic logic inst_alu_is_sub(input logic [INST_ALU_BITS-1:0] op);
        return op[1];
    endfunction
    function automatic logic inst_alu_is_czero(input logic [INST_ALU_BITS-1:0] op);
        return (op[3:1] == 3'b101);
    endfunction
    localparam INST_BR_BEQ =     4'b0000;
    localparam INST_BR_BNE =     4'b0010;
    localparam INST_BR_BLTU =    4'b0100;
    localparam INST_BR_BGEU =    4'b0110;
    localparam INST_BR_BLT =     4'b0101;
    localparam INST_BR_BGE =     4'b0111;
    localparam INST_BR_JAL =     4'b1000;
    localparam INST_BR_JALR =    4'b1001;
    localparam INST_BR_ECALL =   4'b1010;
    localparam INST_BR_EBREAK =  4'b1011;
    localparam INST_BR_URET =    4'b1100;
    localparam INST_BR_SRET =    4'b1101;
    localparam INST_BR_MRET =    4'b1110;
    localparam INST_BR_OTHER =   4'b1111;
    localparam INST_BR_BITS =    4;
    function automatic logic [1:0] inst_br_class(input logic [INST_BR_BITS-1:0] op);
        return {1'b0, ~op[3]};
    endfunction
    function automatic logic inst_br_is_neg(input logic [INST_BR_BITS-1:0] op);
        return op[1];
    endfunction
    function automatic logic inst_br_is_less(input logic [INST_BR_BITS-1:0] op);
        return op[2];
    endfunction
    function automatic logic inst_br_is_static(input logic [INST_BR_BITS-1:0] op);
        return op[3];
    endfunction
    localparam INST_VOTE_ALL =   2'b00;
    localparam INST_VOTE_ANY =   2'b01;
    localparam INST_VOTE_UNI =   2'b10;
    localparam INST_VOTE_BAL =   2'b11;
    localparam INST_SHFL_UP =    2'b00;
    localparam INST_SHFL_DOWN =  2'b01;
    localparam INST_SHFL_BFLY =  2'b10;
    localparam INST_SHFL_IDX =   2'b11;
    localparam INST_VOTE_BITS =  2;
    localparam INST_SHFL_BITS =  2;
    localparam INST_WGATHER =    4'h8;  
    localparam INST_M_MUL =      3'b000;
    localparam INST_M_MULHU =    3'b001;
    localparam INST_M_MULH =     3'b010;
    localparam INST_M_MULHSU =   3'b011;
    localparam INST_M_DIV =      3'b100;
    localparam INST_M_DIVU =     3'b101;
    localparam INST_M_REM =      3'b110;
    localparam INST_M_REMU =     3'b111;
    localparam INST_M_BITS =     3;
    function automatic logic inst_m_signed(input logic [INST_M_BITS-1:0] op);
        return (~op[0]);
    endfunction
    function automatic logic inst_m_is_mulx(input logic [INST_M_BITS-1:0] op);
        return (~op[2]);
    endfunction
    function automatic logic inst_m_is_mulh(input logic [INST_M_BITS-1:0] op);
        return (op[1:0] != 0);
    endfunction
    function automatic logic inst_m_signed_a(input logic [INST_M_BITS-1:0] op);
        return (op[1:0] != 1);
    endfunction
    function automatic logic inst_m_is_rem(input logic [INST_M_BITS-1:0] op);
        return op[1];
    endfunction
    localparam LSU_FMT_B =       3'b000;
    localparam LSU_FMT_H =       3'b001;
    localparam LSU_FMT_W =       3'b010;
    localparam LSU_FMT_D =       3'b011;
    localparam LSU_FMT_BU =      3'b100;
    localparam LSU_FMT_HU =      3'b101;
    localparam LSU_FMT_WU =      3'b110;
    localparam INST_LSU_LB =     4'b0000;
    localparam INST_LSU_LH =     4'b0001;
    localparam INST_LSU_LW =     4'b0010;
    localparam INST_LSU_LD =     4'b0011;  
    localparam INST_LSU_LBU =    4'b0100;
    localparam INST_LSU_LHU =    4'b0101;
    localparam INST_LSU_LWU =    4'b0110;  
    localparam INST_LSU_SB =     4'b1000;
    localparam INST_LSU_SH =     4'b1001;
    localparam INST_LSU_SW =     4'b1010;
    localparam INST_LSU_SD =     4'b1011;  
    localparam INST_LSU_FENCE =  4'b1111;
    localparam INST_LSU_BITS =   4;
    localparam INST_FENCE_BITS = 1;
    localparam INST_FENCE_D =    1'h0;
    localparam INST_FENCE_I =    1'h1;
    function automatic logic [2:0] inst_lsu_fmt(input logic [INST_LSU_BITS-1:0] op);
        return op[2:0];
    endfunction
    function automatic logic [1:0] inst_lsu_wsize(input logic [INST_LSU_BITS-1:0] op);
        return op[1:0];
    endfunction
    function automatic logic inst_lsu_is_fence(input logic [INST_LSU_BITS-1:0] op);
        return (op == INST_LSU_FENCE);
    endfunction
    localparam INST_FPU_ADD =    4'b0000;  
    localparam INST_FPU_MUL =    4'b0001;
    localparam INST_FPU_MADD =   4'b0010;  
    localparam INST_FPU_NMADD =  4'b0011;  
    localparam INST_FPU_DIV =    4'b0100;
    localparam INST_FPU_SQRT =   4'b0101;
    localparam INST_FPU_F2I =    4'b1000;  
    localparam INST_FPU_F2U =    4'b1001;  
    localparam INST_FPU_I2F =    4'b1010;  
    localparam INST_FPU_U2F =    4'b1011;  
    localparam INST_FPU_CMP =    4'b1100;  
    localparam INST_FPU_F2F =    4'b1101;  
    localparam INST_FPU_MISC =   4'b1110;  
    localparam INST_FPU_F2H =    4'b1111;
    localparam INST_FPU_BITS =   4;
    function automatic logic inst_fpu_is_class(input logic [INST_FPU_BITS-1:0] op, input logic [INST_FRM_BITS-1:0] frm);
        return (op == INST_FPU_MISC && frm == 3);
    endfunction
    function automatic logic inst_fpu_is_mvxw(input logic [INST_FPU_BITS-1:0] op, input logic [INST_FRM_BITS-1:0] frm);
        return (op == INST_FPU_MISC && frm == 4);
    endfunction
    localparam INST_SFU_TMC =    4'h0;
    localparam INST_SFU_WSPAWN = 4'h1;
    localparam INST_SFU_SPLIT =  4'h2;
    localparam INST_SFU_JOIN =   4'h3;
    localparam INST_SFU_BAR =    4'h4;
    localparam INST_SFU_PRED =   4'h5;
    localparam INST_SFU_CSRRW =  4'h6;
    localparam INST_SFU_CSRRS =  4'h7;
    localparam INST_SFU_CSRRC =  4'h8;
    localparam INST_SFU_WSYNC =  4'hA;
    localparam INST_SFU_BITS =   4;
    function automatic logic [3:0] inst_sfu_csr(input logic [2:0] funct3);
        return (4'h6 + 4'(funct3[1:0]) - 4'h1);
    endfunction
    function automatic logic inst_sfu_is_wctl(input logic [INST_SFU_BITS-1:0] op);
        return (op == INST_SFU_TMC)
            || (op == INST_SFU_WSPAWN)
            || (op == INST_SFU_SPLIT)
            || (op == INST_SFU_JOIN)
            || (op == INST_SFU_BAR)
            || (op == INST_SFU_PRED)
            || (op == INST_SFU_WSYNC);
    endfunction
    function automatic logic inst_sfu_is_csr(input logic [INST_SFU_BITS-1:0] op);
        return (op >= 6 && op <= 8);
    endfunction
    localparam ISSUE_ISW_BITS = $clog2(1);
    localparam ISSUE_ISW_SIZEW = $clog2(1 + 1);
    localparam ISSUE_ISW_W = (((ISSUE_ISW_BITS) > 0) ? (ISSUE_ISW_BITS) : 1);
    localparam PER_ISSUE_WARPS = 4 / 1;
    localparam ISSUE_WIS_BITS = $clog2(PER_ISSUE_WARPS);
    localparam ISSUE_WIS_W = (((ISSUE_WIS_BITS) > 0) ? (ISSUE_WIS_BITS) : 1);
    localparam NUM_TRAP_CSRS = 5;
    localparam DISPATCH_QSIZE = 4;
    localparam PER_OPC_WARPS = PER_ISSUE_WARPS / 1;
    localparam PER_OPC_NW_BITS = $clog2(PER_OPC_WARPS);
    localparam PER_OPC_NW_W = (((PER_OPC_NW_BITS) > 0) ? (PER_OPC_NW_BITS) : 1);
    function automatic logic [NW_WIDTH-1:0] wis_to_wid(
        input logic [ISSUE_WIS_W-1:0] wis,
        input logic [ISSUE_ISW_W-1:0] isw
    );
        if (ISSUE_WIS_BITS == 0) begin
            wis_to_wid = NW_WIDTH'(isw);
        end else if (ISSUE_ISW_BITS == 0) begin
            wis_to_wid = NW_WIDTH'(wis);
        end else begin
            wis_to_wid = NW_WIDTH'({wis, isw});
        end
    endfunction
    function automatic logic [ISSUE_ISW_W-1:0] wid_to_isw(
        input logic [NW_WIDTH-1:0] wid
    );
        if (ISSUE_ISW_BITS != 0) begin
            wid_to_isw = wid[ISSUE_ISW_W-1:0];
        end else begin
            wid_to_isw = 0;
        end
    endfunction
    function automatic logic [ISSUE_WIS_W-1:0] wid_to_wis(
        input logic [NW_WIDTH-1:0] wid
    );
        if (ISSUE_WIS_BITS != 0) begin
            wid_to_wis = ISSUE_WIS_W'(wid >> ISSUE_ISW_BITS);
        end else begin
            wid_to_wis = 0;
        end
    endfunction
    localparam INST_TCU_WMMA       = 4'h0;
    localparam INST_TCU_LD         = 4'h5;
    localparam INST_TCU_BITS = 4;
    typedef struct packed {
        logic [64-1:0] tmask;
    } tmc_t;
    typedef struct packed {
        logic [4-1:0]  wmask;
        logic [PC_BITS-1:0]     pc;
    } wspawn_t;
    typedef struct packed {
        logic                   is_dvg;
        logic [64-1:0] then_tmask;
        logic [64-1:0] else_tmask;
        logic [PC_BITS-1:0]     next_pc;
    } split_t;
    typedef struct packed {
        logic [64-1:0] tmask;
        logic [DV_STACK_SIZEW-1:0] stack_ptr;
    } join_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0]    id;
        logic                   is_event;
        logic                   is_global;
        logic                   is_arrive;
        logic                   is_sync;
        logic                   phase;
        logic [BAR_SIZE_W-1:0]  size_m1;
    } barrier_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0] id;
        logic [NC_WIDTH-1:0] size_m1;
        logic [NC_WIDTH-1:0] core_id;
    } gbar_req_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0] id;
    } gbar_rsp_t;
    typedef struct packed {
        logic [BAR_ADDR_W-1:0] addr;
        logic                  is_done;
    } txbar_t;
    typedef struct packed {
        logic                         rw;
        logic [VX_DCR_ADDR_WIDTH-1:0] addr;
        logic [VX_DCR_DATA_WIDTH-1:0] data;
    } dcr_req_t;
    typedef struct packed {
        logic [VX_DCR_DATA_WIDTH-1:0] data;
    } dcr_rsp_t;
    localparam FRAG_STAMP_BITS = 2 * (15 - 1) + 4 + 16;
    localparam FRAG_QUAD_LANES = 4;
    localparam FRAG_LANE_BITS  = FRAG_STAMP_BITS / FRAG_QUAD_LANES;
    localparam KMU_FRAG_BITS = 0;
    localparam KMU_FRAG_PAYLOAD_BITS = 0;
    localparam KMU_COMPUTE_BITS = 3*32                     
                                + 3*32                     
                                + 3*(CTA_TID_WIDTH+1)      
                                + (CTA_TID_WIDTH+1)        
                                + 3*CTA_TID_WIDTH          
                                + (NW_WIDTH+1)             
                                + 1;                       
    localparam KMU_ARGS_BITS = (((KMU_COMPUTE_BITS) > (KMU_FRAG_PAYLOAD_BITS)) ? (KMU_COMPUTE_BITS) : (KMU_FRAG_PAYLOAD_BITS)) + 1;
    typedef struct packed {
        logic [KMU_ARGS_BITS-KMU_COMPUTE_BITS-1:0] __padding;
        logic [2:0][31:0]              grid_dim;
        logic [2:0][31:0]              block_idx;
        logic [2:0][CTA_TID_WIDTH:0]   block_dim;
        logic [CTA_TID_WIDTH:0]        block_size;
        logic [2:0][CTA_TID_WIDTH-1:0] warp_step;
        logic [NW_WIDTH:0]             cluster_size;
        logic                          is_first_of_cluster;
    } kmu_compute_args_t;
    typedef union packed {
        kmu_compute_args_t  compute;
    } kmu_args_t;
    typedef struct packed {
        logic                              kind;    
        logic [PC_BITS-1:0]                PC;
        logic [PC_BITS-1:0]                entry;
        logic [32-1:0] param;
        logic [7:0]                        ctx_id;
        logic [17:0]    aligned_lmem_size;
        kmu_args_t                         args;    
    } kmu_req_t;
    localparam KMU_DATAW = $bits(kmu_req_t);
    localparam KMU_KIND_COMPUTE  = 1'b0;    
    localparam KMU_KIND_FRAGMENT = 1'b1;    
    localparam KMU_KIND_BITS     = 1;
    localparam KMU_DEST_W = ((($clog2(1 * 1)) > 0) ? ($clog2(1 * 1)) : 1);
    localparam KMU_DEST_LSB_SOCKET  = 0;
    localparam KMU_DEST_LSB_CLUSTER = $clog2(1);
    localparam KMU_DEST_LSB_DEVICE  = KMU_DEST_LSB_CLUSTER + $clog2(NUM_SOCKETS);
    typedef struct packed {
        logic [NCTA_WIDTH-1:0] cta_id;
        logic [NW_WIDTH-1:0] cta_rank;
        logic [NW_WIDTH:0] cta_size;
        logic [2:0][31:0] block_idx;
        logic [2:0][CTA_TID_WIDTH:0] block_dim;
        logic [2:0][31:0] grid_dim;
        logic [PC_BITS-1:0] entry;
        logic [32-1:0] param;
        logic [32-1:0] lmem_addr;
        logic [31:0] cluster_size;
    } cta_csrs_t;
    typedef struct packed {
        logic [NW_WIDTH:0]              cta_size;
        logic [2:0][31:0]               block_idx;
        logic [2:0][CTA_TID_WIDTH:0]    block_dim;
        logic [2:0][31:0]               grid_dim;
        logic [PC_BITS-1:0]             entry;
        logic [32-1:0] param;
        logic [32-1:0] lmem_addr;
        logic [31:0]                    cluster_size;
    } cta_ctx_t;
    localparam CTA_TID_LANE_BITS = 3 * CTA_TID_WIDTH;
    localparam LANE_LAUNCH_BITS = CTA_TID_LANE_BITS;
    typedef logic [LANE_LAUNCH_BITS-1:0] cta_lane_t;
    typedef struct packed {
        logic [NW_WIDTH-1:0]                     cta_rank;
        cta_lane_t [64-1:0]     lane_launch;
    } cta_warp_t;
    localparam INST_ARGS_BITS = 3 + ALU_TYPE_BITS + 20 + 2;
    typedef struct packed {
        logic [1:0] __padding;
        logic use_PC;
        logic use_imm;
        logic is_w;
        logic [ALU_TYPE_BITS-1:0] xtype;
        logic [19:0] imm20;
    } alu_args_t;
    typedef struct packed {
        logic [1:0] __padding;
        logic use_PC;
        logic use_imm;
        logic is_rvc;
        logic [ALU_TYPE_BITS-1:0] xtype;
        logic [19:0] imm20;
    } br_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-INST_FRM_BITS-INST_FMT_BITS)-1:0] __padding;
        logic [INST_FRM_BITS-1:0] frm;
        logic [INST_FMT_BITS-1:0] fmt;
    } fpu_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-1-1-12-2-1-1-$bits(amo_op_e)-2-2)-1:0] __padding;
        logic [1:0]                 export_mask;
        logic                       amo_valid;
        logic                       amo_unsigned;
        amo_op_e                    amo_op;
        logic                       amo_aq;
        logic                       amo_rl;
        logic [1:0]                 pack;
        logic                       is_store;
        logic                       is_float;
        logic [11:0]                offset;
    } lsu_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-1-12-5)-1:0] __padding;
        logic use_imm;
        logic [12-1:0] addr;
        logic [4:0] imm5;
    } csr_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-3)-1:0] __padding;
        logic is_cond_neg;
        logic is_sync_bar;
        logic is_bar_arrive;
    } wctl_args_t;
    typedef struct packed {
        logic is_last_uop;     
        logic is_first_uop;    
        logic a_from_smem;     
        logic [1:0] cd_nregs;  
        logic [4:0] fmt_d;
        logic [4:0] fmt_s;
        logic [3:0] step_k;
        logic [3:0] step_n;
        logic [3:0] step_m;
    } tcu_args_t;
    typedef union packed {
        alu_args_t  alu;
        br_args_t   br;
        fpu_args_t  fpu;
        lsu_args_t  lsu;
        csr_args_t  csr;
        wctl_args_t wctl;
        tcu_args_t  tcu;
    } op_args_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]  uuid;
        logic [NW_WIDTH-1:0]    wid;
        logic [NCTA_WIDTH-1:0]  cta_id;
        logic [64-1:0] tmask;
        logic [PC_BITS-1:0]     PC;
        logic [31:0]            instr;
    } fetch_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       rd_xregs;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
    } decode_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       rd_xregs;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
        logic                       fu_lock;
        logic                       fu_unlock;
    } ibuffer_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [ISSUE_WIS_W-1:0]     wis;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
    } scoreboard_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic [EX_BITS-1:0]                 ex_type;
        logic [INST_OP_BITS-1:0]            op_type;
        op_args_t                           op_args;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [64-1:0][32-1:0]  rs1_data;
        logic [64-1:0][32-1:0]  rs2_data;
        logic [64-1:0][32-1:0]  rs3_data;
        logic                               sop;
        logic                               eop;
    } operands_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [INST_OP_BITS-1:0]            op_type;
        op_args_t                           op_args;
        logic [64-1:0][32-1:0]  rs1_data;
        logic [64-1:0][32-1:0]  rs2_data;
        logic [64-1:0][32-1:0]  rs3_data;
        logic                               sop;
        logic                               eop;
    } dispatch_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [NW_WIDTH-1:0]                wid;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [64-1:0][32-1:0]  data;
        logic                               sop;
        logic                               eop;
    } commit_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [PER_ISSUE_WARPS-1:0]         eop_wis;  
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [64-1:0][XLENB-1:0]  byteen;
        logic [64-1:0][32-1:0]  data;
        logic                               sop;
        logic                               eop;
    } writeback_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [NW_WIDTH-1:0]                wid;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [64-1:0]            tmask;
        logic [PC_BITS-1:0]                 PC;
    } schedule_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } alu_header_t; 
    typedef struct packed { 
        alu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } alu_execute_t; 
    typedef struct packed { 
        alu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } alu_result_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } lsu_header_t; 
    typedef struct packed { 
        lsu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } lsu_execute_t; 
    typedef struct packed { 
        lsu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } lsu_result_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } sfu_header_t; 
    typedef struct packed { 
        sfu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } sfu_execute_t; 
    typedef struct packed { 
        sfu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } sfu_result_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] read_misses;
        logic [PERF_CTR_BITS-1:0] write_misses;
        logic [PERF_CTR_BITS-1:0] evictions;
        logic [PERF_CTR_BITS-1:0] bank_stalls;
        logic [PERF_CTR_BITS-1:0] mshr_stalls;
        logic [PERF_CTR_BITS-1:0] mem_stalls;
        logic [PERF_CTR_BITS-1:0] crsp_stalls;
    } cache_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] bank_stalls;
        logic [PERF_CTR_BITS-1:0] crsp_stalls;
    } lmem_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] misses;
    } coalescer_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] tlb_reads;
        logic [PERF_CTR_BITS-1:0] tlb_hits;
        logic [PERF_CTR_BITS-1:0] tlb_misses;
        logic [PERF_CTR_BITS-1:0] tlb_evictions;
        logic [PERF_CTR_BITS-1:0] ptw_walks;
        logic [PERF_CTR_BITS-1:0] ptw_latency;
    } mmu_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] lmem_reads;         
        logic [PERF_CTR_BITS-1:0] tbuf_cache_hits;    
        logic [PERF_CTR_BITS-1:0] wgmma_stalls;       
        logic [PERF_CTR_BITS-1:0] wgmma_instrs;       
        logic [PERF_CTR_BITS-1:0] tbuf_stalls;          
    } tcu_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] latency;
    } mem_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] idles;
        logic [PERF_CTR_BITS-1:0] active_warps;
        logic [PERF_CTR_BITS-1:0] stalled_warps;
        logic [PERF_CTR_BITS-1:0] issued_warps;
        logic [PERF_CTR_BITS-1:0] issued_threads;
        logic [PERF_CTR_BITS-1:0] branches;
        logic [PERF_CTR_BITS-1:0] divergence;
    } sched_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] stalls;
    } fetch_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] ibf_stalls;
        logic [PERF_CTR_BITS-1:0] scb_stalls;
        logic [PERF_CTR_BITS-1:0] opd_stalls;
        logic [NUM_EX_UNITS-1:0][PERF_CTR_BITS-1:0] dispatch_stalls;
        logic [NUM_EX_UNITS-1:0][PERF_CTR_BITS-1:0] dispatch_instrs;
    } issue_perf_t;
    typedef struct packed {
        cache_perf_t icache;
        cache_perf_t dcache;
        cache_perf_t l2cache;
        cache_perf_t l3cache;
        lmem_perf_t  lmem;
        coalescer_perf_t coalescer;
        mem_perf_t   mem;
    } sysmem_perf_t;
    typedef struct packed {
        sched_perf_t              sched;
        fetch_perf_t              fetch;
        issue_perf_t              issue;
        tcu_perf_t                tcu;
        logic [PERF_CTR_BITS-1:0] ifetches;
        logic [PERF_CTR_BITS-1:0] loads;
        logic [PERF_CTR_BITS-1:0] stores;
        logic [PERF_CTR_BITS-1:0] ifetch_latency;
        logic [PERF_CTR_BITS-1:0] load_latency;
   } pipeline_perf_t;
    localparam LSU_WORD_SIZE        = XLENB;
    localparam LSU_ADDR_WIDTH	    = (32 - $clog2(LSU_WORD_SIZE));
    localparam LSU_MEM_BATCHES      = 1;
    localparam LSU_TAG_ID_BITS      = ($clog2(8) + $clog2(LSU_MEM_BATCHES));
    localparam LSU_TAG_WIDTH        = (UUID_WIDTH + LSU_TAG_ID_BITS);
    localparam LSU_NUM_REQS	        = 1 * 64;
    localparam LSU_QUEUE_OUT_SIZE   = (((8) > (64 / LSU_WORD_SIZE)) ? (8) : (64 / LSU_WORD_SIZE));
    localparam LMEM_TAG_WIDTH_BASE  = LSU_TAG_WIDTH + $clog2(1);
    localparam LMEM_TAG_WIDTH       = LMEM_TAG_WIDTH_BASE;
    localparam LSU_CLIENT_TAG_WIDTH = $bits(lsu_header_t) + INST_LSU_BITS
                                    + (64 * $clog2(LSU_WORD_SIZE))
                                    + (((8) > 1) ? $clog2(8) : 1) + 1;
    typedef struct packed {
        logic                                                       rw;
        logic [64-1:0]                           mask;
        logic [64-1:0][LSU_WORD_SIZE-1:0]        byteen;
        logic [64-1:0][LSU_ADDR_WIDTH-1:0]       addr;
        logic [64-1:0][MEM_ATTR_WIDTH-1:0]       attr;
        logic [64-1:0][(LSU_WORD_SIZE*8)-1:0]    data;
        logic [LSU_CLIENT_TAG_WIDTH-1:0]                            tag;
    } lsu_req_data_t;
    typedef struct packed {
        logic [64-1:0]                           mask;
        logic [64-1:0][(LSU_WORD_SIZE*8)-1:0]    data;
        logic [LSU_CLIENT_TAG_WIDTH-1:0]                            tag;
        logic                                                       sop;
        logic                                                       eop;
    } lsu_rsp_data_t;
    localparam DXA_LMEM_ATTR_W = (BAR_ADDR_W + 1);
    localparam DXA_LMEM_ENGINE_TAG_W = UUID_WIDTH + 1;
    localparam DXA_LMEM_TAG_W = DXA_LMEM_ENGINE_TAG_W + NC_BITS;
    localparam DXA_LMEM_OUT_TAG_W = DXA_LMEM_TAG_W + ((1 > 1) ? $clog2(((1 + 1 - 1) / (1))) : 0);
    localparam TCU_LMEM_ATTR_W = 1;
    localparam TCU_LMEM_BLK_TAG_W = UUID_WIDTH + 1;
    localparam TCU_LMEM_NUM_MASTERS = 1 + 1;
    localparam TCU_LMEM_TAG_W = TCU_LMEM_BLK_TAG_W + ((TCU_LMEM_NUM_MASTERS > 1) ? $clog2(((TCU_LMEM_NUM_MASTERS + 1 - 1) / (1))) : 0);
    localparam LMEM_DMA_EN         = (0 + 0) != 0;
    localparam LMEM_DMA_DATA_SIZE  = 64 * LSU_WORD_SIZE;
    localparam LMEM_DMA_ADDR_WIDTH = 17 - $clog2(64 * LSU_WORD_SIZE);
    localparam LMEM_DMA_ATTR_W     = (((DXA_LMEM_ATTR_W) > (TCU_LMEM_ATTR_W)) ? (DXA_LMEM_ATTR_W) : (TCU_LMEM_ATTR_W));
    localparam LMEM_DMA_DXA_IDX    = 0;
    localparam LMEM_DMA_TCU_IDX    = LMEM_DMA_DXA_IDX + 0;
    localparam LMEM_DMA_INPUTS     = 0 + 0;
    localparam LMEM_DMA_IN_TAG_MAX = (((DXA_LMEM_OUT_TAG_W) > (TCU_LMEM_TAG_W)) ? (DXA_LMEM_OUT_TAG_W) : (TCU_LMEM_TAG_W));
    localparam LMEM_DMA_TAG_WIDTH  = LMEM_DMA_IN_TAG_MAX + ((LMEM_DMA_INPUTS > 1) ? $clog2(((LMEM_DMA_INPUTS + 1 - 1) / (1))) : 0);
    localparam ICACHE_WORD_SIZE	    = 4;
    localparam ICACHE_ADDR_WIDTH	= (32 - $clog2(ICACHE_WORD_SIZE));
    localparam ICACHE_LINE_SIZE	    = 64;
    localparam ICACHE_TAG_ID_BITS	= NW_WIDTH;
    localparam ICACHE_FETCH_TAG_WIDTH = (UUID_WIDTH + ICACHE_TAG_ID_BITS);
    localparam ICACHE_TAG_WIDTH_BASE = (ICACHE_FETCH_TAG_WIDTH + 1);
    localparam ICACHE_TAG_WIDTH       = ICACHE_TAG_WIDTH_BASE;
    localparam ICACHE_MEM_DATA_WIDTH = (ICACHE_LINE_SIZE * 8);
    localparam ICACHE_MEM_TAG_WIDTH = 
        (
        (UUID_WIDTH + $clog2(16) + $clog2(((1 + 1 - 1) / (1)))) + (((((1) > 0) ? (1) : 1) > 1) ? $clog2((((((1) > 0) ? (1) : 1) + 1 - 1) / (1))) : 0));
    localparam DCACHE_WORD_SIZE	    = 32;
    localparam DCACHE_ADDR_WIDTH	= (32 - $clog2(DCACHE_WORD_SIZE));
    localparam DCACHE_LINE_SIZE 	= 64;
    localparam DCACHE_SECTOR_SIZE   = 64;
    localparam DCACHE_CHANNELS	    = ((((64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE) > 0) ? ((64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE) : 1);
    localparam DCACHE_NUM_REQS	    = 1 * DCACHE_CHANNELS;
    localparam DCACHE_NUM_BANKS     = 1;
    localparam L1_MEM_PORTS         = 1;
    localparam DCACHE_MERGED_REQS   = (64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE;
    localparam DCACHE_MEM_BATCHES   = ((DCACHE_MERGED_REQS + DCACHE_CHANNELS - 1) / (DCACHE_CHANNELS));
    localparam DCACHE_TAG_ID_BITS   = ($clog2(LSU_QUEUE_OUT_SIZE) + $clog2(DCACHE_MEM_BATCHES));
    localparam DCACHE_CORE_TAG_WIDTH = (UUID_WIDTH + DCACHE_TAG_ID_BITS);
    localparam DCACHE_TAG_WIDTH_BASE = (DCACHE_CORE_TAG_WIDTH + 1);
    localparam DCACHE_TAG_WIDTH       = DCACHE_TAG_WIDTH_BASE;
    localparam DCACHE_MEM_DATA_WIDTH = (DCACHE_SECTOR_SIZE * 8);
    localparam DCACHE_MEM_TAG_WIDTH = 
        (
        ((((
        (UUID_WIDTH + $clog2(16) + $clog2(((DCACHE_NUM_BANKS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))))) > (
        ($clog2(((DCACHE_NUM_REQS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))) + $clog2(DCACHE_SECTOR_SIZE / DCACHE_WORD_SIZE) + 
        (DCACHE_TAG_WIDTH + ((1 > (((1) > 0) ? (1) : 1)) ? $clog2(((1 + (((1) > 0) ? (1) : 1) - 1) / ((((1) > 0) ? (1) : 1)))) : 0))))) ? (
        (UUID_WIDTH + $clog2(16) + $clog2(((DCACHE_NUM_BANKS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))))) : (
        ($clog2(((DCACHE_NUM_REQS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))) + $clog2(DCACHE_SECTOR_SIZE / DCACHE_WORD_SIZE) + 
        (DCACHE_TAG_WIDTH + ((1 > (((1) > 0) ? (1) : 1)) ? $clog2(((1 + (((1) > 0) ? (1) : 1) - 1) / ((((1) > 0) ? (1) : 1)))) : 0))))) + 1) + (((((1) > 0) ? (1) : 1) > 1) ? $clog2((((((1) > 0) ? (1) : 1) + 1 - 1) / (1))) : 0));
    localparam DCACHE_IS_LLC        = !0 && !0;
    localparam L1_MEM_TAG_WIDTH     = (((ICACHE_MEM_TAG_WIDTH) > (DCACHE_MEM_TAG_WIDTH)) ? (ICACHE_MEM_TAG_WIDTH) : (DCACHE_MEM_TAG_WIDTH));
    localparam ICACHE_MEM_ARB_IDX   = 0;
    localparam DCACHE_MEM_ARB_IDX   = ICACHE_MEM_ARB_IDX + 1;
    localparam TCACHE_MEM_ARB_IDX   = DCACHE_MEM_ARB_IDX + 1;
    localparam RTCACHE_MEM_ARB_IDX  = TCACHE_MEM_ARB_IDX + 0;
    localparam DXA_MEM_ARB_IDX      = RTCACHE_MEM_ARB_IDX + 0;
    localparam SOCKET_MEM_ARB_REQS  = 2 + 0 + 0 + 0;
    localparam SOCKET_MEM_TAG_W1    = L1_MEM_TAG_WIDTH;
    localparam SOCKET_MEM_TAG_WIDTH = SOCKET_MEM_TAG_W1;
    localparam SOCKET_MEM_ARB_TAG_WIDTH = (SOCKET_MEM_TAG_WIDTH + $clog2(SOCKET_MEM_ARB_REQS));
    localparam L2_WORD_SIZE	        = 64;
    localparam L2_SECTOR_SIZE       = 64;
    localparam L2_SOCKET_REQS       = NUM_SOCKETS * L1_MEM_PORTS;
    localparam L2_GFX_REQS          = 0 + 0;
    localparam L2_GFX_RASTER_IDX    = L2_SOCKET_REQS;
    localparam L2_GFX_OM_IDX        = L2_GFX_RASTER_IDX + 0;
    localparam PTW_ON_L2            = ((0 != 0)
                                    && (1 == 1)
                                    && (0 != 0)
                                    && (0 == 0)) ? 1 : 0;
    localparam L2_PTW_REQS          = PTW_ON_L2;
    localparam L2_PTW_IDX           = L2_SOCKET_REQS + L2_GFX_REQS;
    localparam L2_NUM_REQS          = L2_SOCKET_REQS + L2_GFX_REQS + L2_PTW_REQS;
    localparam L2_NUM_BANKS         = 1;
    localparam L2_MEM_PORTS         = 0;
    localparam L2_TAG_WIDTH         = SOCKET_MEM_ARB_TAG_WIDTH;
    localparam L1_TLB_ID_WIDTH       = $clog2(4);
    localparam TLB_SOCKET_ID_WIDTH   = L1_TLB_ID_WIDTH + ((2 > 1) ? $clog2(((2 + 1 - 1) / (1))) : 0);
    localparam TLB_CLUSTER_ID_WIDTH  = TLB_SOCKET_ID_WIDTH + ((NUM_SOCKETS > 1) ? $clog2(((NUM_SOCKETS + 1 - 1) / (1))) : 0);
    localparam L2_TLB_SLOT_WIDTH     = $clog2(8);
    localparam TLB_DEV_ID_WIDTH      = L2_TLB_SLOT_WIDTH + ((1 > 1) ? $clog2(((1 + 1 - 1) / (1))) : 0);
    localparam L2_MEM_DATA_WIDTH	= (L2_SECTOR_SIZE * 8);
    localparam L2_MEM_TAG_WIDTH     = 
        ($clog2(((L2_NUM_REQS + L2_MEM_PORTS - 1) / (L2_MEM_PORTS))) + $clog2(L2_SECTOR_SIZE / L2_WORD_SIZE) + L2_TAG_WIDTH);
    localparam L2_IS_LLC            = 0 && !0;
    localparam L3_WORD_SIZE	        = L2_SECTOR_SIZE;
    localparam L3_SECTOR_SIZE       = 64;
    localparam L3_PTW_IDX           = 1 * L2_MEM_PORTS;
    localparam L3_NUM_REQS	        = 1 * L2_MEM_PORTS
                                    + ((0 != 0) && (PTW_ON_L2 == 0) ? 1 : 0);
    localparam L3_NUM_BANKS         = 1;
    localparam L3_MEM_PORTS         = 0;
    localparam L3_TAG_WIDTH	        = L2_MEM_TAG_WIDTH;
    localparam L3_MEM_DATA_WIDTH	= (L3_SECTOR_SIZE * 8);
    localparam L3_MEM_TAG_WIDTH     = 
        ($clog2(((L3_NUM_REQS + L3_MEM_PORTS - 1) / (L3_MEM_PORTS))) + $clog2(L3_SECTOR_SIZE / L3_WORD_SIZE) + L3_TAG_WIDTH);
    localparam L3_IS_LLC            = 0;
    localparam VX_MEM_PORTS =           L3_MEM_PORTS;
    localparam VX_MEM_BYTEEN_WIDTH =    L3_SECTOR_SIZE;
    localparam VX_MEM_ADDR_WIDTH =      (32 - $clog2(L3_SECTOR_SIZE));
    localparam VX_MEM_DATA_WIDTH =      (L3_SECTOR_SIZE * 8);
    localparam VX_MEM_TAG_WIDTH =       L3_MEM_TAG_WIDTH;
    function automatic logic [SFU_WIDTH-1:0] op_to_sfu_type(
        input logic [INST_OP_BITS-1:0] op_type
    );
        case (op_type)
            INST_SFU_CSRRW,
            INST_SFU_CSRRS,
            INST_SFU_CSRRC: op_to_sfu_type = SFU_CSRS;
            default: op_to_sfu_type = SFU_WCTL;
        endcase
    endfunction
    function automatic logic [NUM_REGS_BITS-1:0] make_reg_num(input logic [REG_TYPE_BITS-1:0] rtype, logic [RV_REGS_BITS-1:0] idx);
        return (NUM_REGS_BITS'(rtype) << RV_REGS_BITS) | NUM_REGS_BITS'(idx);
    endfunction
    function automatic logic [REG_TYPE_BITS-1:0] get_reg_type(input logic [NUM_REGS_BITS-1:0] reg_num);
        return REG_TYPE_BITS'(reg_num >> RV_REGS_BITS);
    endfunction
    function automatic logic [RV_REGS_BITS-1:0] get_reg_idx(input logic [NUM_REGS_BITS-1:0] reg_num);
        return reg_num[RV_REGS_BITS-1:0];
    endfunction
    function automatic logic [UUID_WIDTH-1:0] get_uop_uuid(input logic [UUID_WIDTH-1:0] uuid, input logic [UOP_CTR_W-1:0] uop_idx);
        logic [31:0] uuid_lo = {uop_idx[0 +: UOP_CTR_W], uuid[0 +: (32 - UOP_CTR_W)]};
        return {uuid[UUID_WIDTH-1:32], uuid_lo};
    endfunction
endpackage
package VX_tcu_pkg;
    import VX_gpu_pkg::*;
    localparam TCU_FP32_ID  = 0;
    localparam TCU_TF32_ID  = 1;
    localparam TCU_FP16_ID  = 2;
    localparam TCU_BF16_ID  = 3;
    localparam TCU_FP8_ID   = 4;
    localparam TCU_BF8_ID   = 5;
    localparam TCU_MXFP8_ID = 8;
    localparam TCU_MXBF8_ID = 9;
    localparam TCU_MXFP4_ID = 10;
    localparam TCU_NVFP4_ID = 11;
    localparam TCU_I32_ID   = 16;
    localparam TCU_I8_ID    = 17;
    localparam TCU_U8_ID    = 18;
    localparam TCU_I4_ID    = 19;
    localparam TCU_U4_ID    = 20;
    localparam TCU_FMT_WIDTH= 5;
    localparam TCU_NT = 64;
    localparam TCU_WG_NRA = 4;   
    localparam TCU_WG_NR = 32;   
    localparam TCU_NR = 8;
    localparam TCU_DK = 0;
    localparam TCU_DP = 0;
    localparam TCU_TILE_CAP = TCU_NT * TCU_NR;
    localparam TCU_LG_TILE_CAP = $clog2(TCU_TILE_CAP);
    localparam TCU_TILE_EN = TCU_LG_TILE_CAP / 2;
    localparam TCU_TILE_EM = TCU_LG_TILE_CAP - TCU_TILE_EN;
    localparam TCU_TILE_M = 1 << TCU_TILE_EM;
    localparam TCU_TILE_N = 1 << TCU_TILE_EN;
    localparam TCU_TILE_K = (TCU_DK != 0) ? TCU_DK : (TCU_DP != 0) ? TCU_DP : (TCU_TILE_CAP / ((TCU_TILE_M > TCU_TILE_N) ? TCU_TILE_M : TCU_TILE_N));
    localparam TCU_BLOCK_CAP = TCU_NT;
    localparam TCU_LG_BLOCK_CAP = $clog2(TCU_BLOCK_CAP);
    localparam TCU_BLOCK_EN = TCU_LG_BLOCK_CAP / 2;
    localparam TCU_BLOCK_EM = TCU_LG_BLOCK_CAP - TCU_BLOCK_EN;
    localparam TCU_TC_M = 1 << TCU_BLOCK_EM;
    localparam TCU_TC_N = 1 << TCU_BLOCK_EN;
    localparam TCU_TC_K = (TCU_DP != 0) ? TCU_DP : (TCU_BLOCK_CAP / ((TCU_TC_M > TCU_TC_N) ? TCU_TC_M : TCU_TC_N));
    localparam TCU_M_STEPS = TCU_TILE_M / TCU_TC_M;
    localparam TCU_N_STEPS = TCU_TILE_N / TCU_TC_N;
    localparam TCU_K_STEPS = TCU_TILE_K / TCU_TC_K;
    localparam TCU_A_BLOCK_SIZE = TCU_TC_M * TCU_TC_K;
    localparam TCU_A_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_A_BLOCK_SIZE;
    localparam TCU_B_BLOCK_SIZE = TCU_TC_K * TCU_TC_N;
    localparam TCU_B_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_B_BLOCK_SIZE;
    localparam TCU_WG_TILE_M = 2 * TCU_TC_M;
    localparam TCU_WG_TILE_K = 2 * TCU_TC_K;
    localparam TCU_WG_FEDP_K = TCU_TC_K;
    localparam TCU_WG_TILE_N = (TCU_WG_NR * TCU_NT) / TCU_WG_TILE_M;
    localparam TCU_WG_M_STEPS = TCU_WG_TILE_M / TCU_TC_M;
    localparam TCU_WG_N_STEPS = TCU_WG_TILE_N / TCU_TC_N;
    localparam TCU_WG_K_STEPS = TCU_WG_TILE_K / TCU_WG_FEDP_K;
    localparam TCU_WG_UOPS = TCU_WG_M_STEPS * TCU_WG_N_STEPS * TCU_WG_K_STEPS;
    localparam TCU_WG_A_BLOCK_SIZE = TCU_TC_M * TCU_TC_K;
    localparam TCU_WG_A_DATA_SIZE  = TCU_TC_M * TCU_WG_FEDP_K;
    localparam TCU_WG_A_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_WG_A_BLOCK_SIZE;
    localparam TCU_WG_B_BLOCK_SIZE = TCU_WG_FEDP_K * TCU_TC_N;
    localparam TCU_WG_B_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_WG_B_BLOCK_SIZE;
    localparam SYM_SPARSE = 0 ? 0 : (TCU_BLOCK_EM == TCU_BLOCK_EN);
    localparam TCU_B_BLOCK_SIZE_SP    = SYM_SPARSE ? TCU_BLOCK_CAP : (TCU_TC_K * TCU_TC_N) * 2;
    localparam TCU_B_SUB_BLOCKS_SP    = TCU_BLOCK_CAP / TCU_B_BLOCK_SIZE_SP;
    localparam TCU_WG_B_BLOCK_SIZE_SP = TCU_TC_K * TCU_TC_N * 2;
    localparam TCU_WG_RS2_WIDTH_DENSE =
        (TCU_WG_B_BLOCK_SIZE > TCU_BLOCK_CAP) ? TCU_WG_B_BLOCK_SIZE : TCU_BLOCK_CAP;
    localparam TCU_WG_RS2_WIDTH = 0
        ? ((TCU_WG_B_BLOCK_SIZE_SP > TCU_WG_RS2_WIDTH_DENSE) ? TCU_WG_B_BLOCK_SIZE_SP : TCU_WG_RS2_WIDTH_DENSE)
        : TCU_WG_RS2_WIDTH_DENSE;
    localparam TCU_MIN_FMT_WIDTH = 4;  
    localparam TCU_MAX_ELT_RATIO = 32 / TCU_MIN_FMT_WIDTH;
    localparam TCU_MAX_META_ROW_WIDTH   = TCU_TC_K * 2 * TCU_MAX_ELT_RATIO;
    localparam TCU_MAX_META_BLOCK_WIDTH = TCU_NT   * 2 * TCU_MAX_ELT_RATIO;
    localparam TCU_META_PER_WARP_DEPTH = TCU_M_STEPS * (TCU_K_STEPS / 2);
    localparam TCU_META_COLS_PER_LOAD  = (TCU_BLOCK_CAP >= TCU_META_PER_WARP_DEPTH)
        ? (TCU_BLOCK_CAP / TCU_META_PER_WARP_DEPTH) : 1;
    localparam TCU_BANKS_PER_STORE = (TCU_NT < TCU_META_PER_WARP_DEPTH)
        ? TCU_NT : TCU_META_PER_WARP_DEPTH;
    localparam TCU_STORES_PER_COL = (TCU_META_PER_WARP_DEPTH + TCU_NT - 1) / TCU_NT;
    localparam TCU_NRA = (TCU_TILE_M * TCU_TILE_K) / TCU_NT;
    localparam TCU_NRB = (TCU_TILE_N * TCU_TILE_K) / TCU_NT;
    localparam TCU_NRC = (TCU_TILE_M * TCU_TILE_N) / TCU_NT;
    localparam TCU_RC    = 0;
    localparam TCU_WG_RC = TCU_RC;   
    localparam TCU_WG_RA = 24;      
    localparam TCU_RA = 10;
    localparam TCU_RB = (TCU_NRB == 4) ? 28 : 24;
    localparam TCU_UOPS = TCU_M_STEPS * TCU_N_STEPS * TCU_K_STEPS;
    localparam TCU_MAX_INPUTS = TCU_TC_K * TCU_MAX_ELT_RATIO;
    function automatic int unsigned mx_fedp_sf_count(
        input int unsigned data_bits,
        input int unsigned block_elems
    );
        automatic int unsigned sparse_ratio = 0 ? 2 : 1;
        automatic int unsigned fedp_elems = TCU_WG_FEDP_K * (32 / data_bits) * sparse_ratio;
        return (fedp_elems + block_elems - 1) / block_elems;
    endfunction
    localparam TCU_MX_SF_FP8 = mx_fedp_sf_count(8, 32);
    localparam TCU_MX_SF_MXFP4 = mx_fedp_sf_count(4, 32);
    localparam TCU_MX_SF_NVFP4 = mx_fedp_sf_count(4, 16);
    localparam TCU_MX_MAX_SF = 
((((((TCU_MX_SF_FP8) > (TCU_MX_SF_MXFP4)) ? (TCU_MX_SF_FP8) : (TCU_MX_SF_MXFP4))) > (TCU_MX_SF_NVFP4)) ? ((((TCU_MX_SF_FP8) > (TCU_MX_SF_MXFP4)) ? (TCU_MX_SF_FP8) : (TCU_MX_SF_MXFP4))) : (TCU_MX_SF_NVFP4));
        localparam TCU_EXP_BITS = 10;
    typedef struct packed {
        logic is_zero;
        logic is_sub;
        logic is_inf;
        logic is_nan;
    } fedp_class_t;
    typedef struct packed {
        logic is_inf;
        logic is_nan;
        logic sign;
    } fedp_excep_t;
    function automatic int exp_bits(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 8;
            TCU_FP16_ID: return 5;
            TCU_BF16_ID: return 8;
            TCU_FP8_ID:  return 4;
            TCU_BF8_ID:  return 5;
            TCU_TF32_ID: return 8;
            default:     return 0;
        endcase
    endfunction
    function automatic int sig_bits(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 23;
            TCU_FP16_ID: return 10;
            TCU_BF16_ID: return 7;
            TCU_FP8_ID:  return 3;
            TCU_BF8_ID:  return 2;
            TCU_TF32_ID: return 10;
            default:     return 0;
        endcase
    endfunction
    function automatic int sign_pos(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 31;
            TCU_FP16_ID: return 15;
            TCU_BF16_ID: return 15;
            TCU_FP8_ID:  return 7;
            TCU_BF8_ID:  return 7;
            TCU_TF32_ID: return 18;
            default:     return 0;
        endcase
    endfunction
    function automatic int unsigned tcu_fmt_width(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_FP16_ID, TCU_BF16_ID:
                return 16;
            TCU_MXFP4_ID, TCU_NVFP4_ID, TCU_I4_ID, TCU_U4_ID:
                return 4;
            TCU_FP8_ID,
            TCU_BF8_ID,
            TCU_I8_ID,
            TCU_U8_ID,
            TCU_MXFP8_ID,
            TCU_MXBF8_ID:
                return 8;
            TCU_FP32_ID,
            TCU_I32_ID,
            TCU_TF32_ID:
                return 32;
            default:
                return 0;
        endcase
    endfunction
    function automatic logic tcu_fmt_is_int(input logic [TCU_FMT_WIDTH-1:0] fmt);
        return fmt[TCU_FMT_WIDTH-1];
    endfunction
    function automatic logic tcu_fmt_is_signed_int(input logic [TCU_FMT_WIDTH-2:0] int_fmt);
        return int_fmt[0];
    endfunction
    function automatic logic tcu_fmt_is_bfloat(input logic [TCU_FMT_WIDTH-2:0] float_fmt);
        return float_fmt[0];
    endfunction
    function automatic logic tcu_fmt_is_mx(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_MXFP8_ID, TCU_MXBF8_ID, TCU_MXFP4_ID, TCU_NVFP4_ID:
                return 1'b1;
            default:
                return 1'b0;
        endcase
    endfunction
    function automatic int unsigned mx_scale_block_size(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_MXFP8_ID, TCU_MXBF8_ID, TCU_MXFP4_ID: return 32;
            TCU_NVFP4_ID:                                          return 16;
            default:                                               return 1;
        endcase
    endfunction
    function automatic int unsigned mx_scale_blocks_k_words(
        input logic [TCU_FMT_WIDTH-1:0] fmt,
        input int unsigned tile_k_words
    );
        automatic int unsigned data_bits = tcu_fmt_width(fmt);
        automatic int unsigned block_elems = mx_scale_block_size(fmt);
        automatic int unsigned tile_elems = (data_bits != 0) ? tile_k_words * (32 / data_bits) : 0;
        return (tile_elems + block_elems - 1) / block_elems;
    endfunction
    function automatic int unsigned mx_scale_blocks_k(input logic [TCU_FMT_WIDTH-1:0] fmt);
        return mx_scale_blocks_k_words(fmt, TCU_TILE_K);
    endfunction
    function automatic logic [4:0] meta_num_cols(input logic [TCU_FMT_WIDTH-1:0] fmt);
        automatic int hw = tcu_fmt_width(fmt) / 2;
        return 5'((TCU_BLOCK_CAP + hw - 1) / hw);
    endfunction
    function automatic int unsigned tcu_meta_stride_words(input logic [TCU_FMT_WIDTH-1:0] fmt);
        automatic int unsigned fb   = tcu_fmt_width(fmt);
        automatic int unsigned elr  = (fb != 0) ? (32 / fb) : 1;  
        automatic int unsigned rowb = TCU_TC_K * 2 * elr;
        return (TCU_TC_M * rowb + 31) / 32;
    endfunction
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } tcu_header_t; 
    typedef struct packed { 
        tcu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } tcu_execute_t; 
    typedef struct packed { 
        tcu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } tcu_result_t;
    typedef struct packed {
        logic                       valid;
        logic [UUID_WIDTH-1:0]      uuid;    
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [3:0]                 step_m;
        logic [3:0]                 step_n;
        logic [3:0]                 step_k;
        logic [1:0]                 cd_nregs;
        logic [32-1:0]    desc_a;
        logic [32-1:0]    desc_b;
        logic                       a_is_smem;
        logic                       is_first_uop;
        logic                       is_last_uop;
        logic                       setup_fire;
    } tcu_tbuf_req_t;
endpackage
module FullAdder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    assign sum = a ^ b ^ cin;
    assign cout = (a & b) | ((a ^ b) & cin);
endmodule
module VX_csa_32 #(
    parameter N = 3,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N-1:0] carry_int;
    for (genvar i = 0; i < N; i++) begin : g_compress_3_2
        FullAdder FA (
            .a    (a[i]),
            .b    (b[i]),
            .cin  (c[i]),
            .sum  (sum_int[i]),
            .cout (carry_int[i])
        );
    end
    assign sum = WIDTH_O'(sum_int);
    assign carry = WIDTH_O'({1'b0, carry_int, 1'b0});
endmodule
module counter_5to3(
    input wire x1, x2, x3, x4, cin,
    output wire sum, carry, cout
);
    wire s1 = x1 ^ x2 ^ x3;
    assign cout = (x1 & x2) | (x2 & x3) | (x1 & x3);
    assign sum = s1 ^ x4 ^ cin;
    assign carry = (s1 & x4) | (x4 & cin) | (s1 & cin);
endmodule
module VX_csa_42 #(
    parameter N = 4,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    input  wire [N-1:0] d,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N:0]   cin;
    wire [N-1:0] cout;
    wire [N-1:0] carry_int;
    assign cin[0] = 1'b0;
    for (genvar i = 0; i < N; i++) begin : g_compress_4_2
        counter_5to3 u_counter_5to3(
            .x1(a[i]),
            .x2(b[i]),
            .x3(c[i]),
            .x4(d[i]),
            .cin(cin[i]),
            .sum(sum_int[i]),
            .carry(carry_int[i]),
            .cout(cout[i])
        );
        assign cin[i+1] = cout[i];
    end
    wire [1:0] carry_temp;
    assign sum = WIDTH_O'(sum_int);
    assign carry_temp = {carry_int[N-1] & cin[N], carry_int[N-1] ^ cin[N]};
    assign carry = WIDTH_O'({carry_temp, carry_int[N-2:0], 1'b0});
endmodule
module VX_csa_block #(
    parameter N = 4,
    parameter W = 8,
    parameter S = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    ;
    function automatic integer calc_4to2_levels(integer n);
        integer remaining = n;
        integer levels_4to2 = 0;
        while (remaining >= 4) begin
            levels_4to2 = levels_4to2 + 1;
            remaining = remaining - 2;
        end
        return levels_4to2;
    endfunction
    localparam LEVELS_4TO2 = calc_4to2_levels(N);
    localparam TOTAL_LEVELS = LEVELS_4TO2 + ((N - LEVELS_4TO2 * 2) == 3 ? 1 : 0);
    localparam WN_CALC = W + TOTAL_LEVELS + 2;
    localparam WN = (WN_CALC > S) ? WN_CALC : S;
    wire [WN-1:0] St [0:TOTAL_LEVELS];
    wire [WN-1:0] Ct [0:TOTAL_LEVELS];
    assign St[0] = WN'(operands[0]);
    assign Ct[0] = WN'(operands[1]);
    for (genvar i = 0; i < LEVELS_4TO2; i++) begin : g_4to2_levels
        localparam WI = W + i;
        localparam WO = WI + 2;
        localparam OP_A_IDX = 2 + (i * 2);
        localparam OP_B_IDX = 3 + (i * 2);
        wire [WO-1:0] st, ct;
        VX_csa_42 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_42 (
            .a(WI'(St[i])),
            .b(WI'(Ct[i])),
            .c(WI'(operands[OP_A_IDX])),
            .d(WI'(operands[OP_B_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[i+1] = WN'(st);
        assign Ct[i+1] = WN'(ct);
    end
    if ((N - LEVELS_4TO2 * 2) == 3) begin : g_final_3to2
        localparam FINAL_OP_IDX = 2 + (LEVELS_4TO2 * 2);
        localparam WI = W + LEVELS_4TO2;
        localparam WO = WI + 2;
        wire [WO-1:0] st, ct;
        VX_csa_32 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_32 (
            .a(WI'(St[LEVELS_4TO2])),
            .b(WI'(Ct[LEVELS_4TO2])),
            .c(WI'(operands[FINAL_OP_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[LEVELS_4TO2+1] = WN'(st);
        assign Ct[LEVELS_4TO2+1] = WN'(ct);
    end
    else begin : g_no_final_3to2
        if (LEVELS_4TO2 < TOTAL_LEVELS) begin : g_pass_through
            assign St[LEVELS_4TO2+1] = St[LEVELS_4TO2];
            assign Ct[LEVELS_4TO2+1] = Ct[LEVELS_4TO2];
        end
    end
    assign sum  = St[TOTAL_LEVELS][S-1:0];
    assign carry = Ct[TOTAL_LEVELS][S-1:0];
endmodule
module VX_csa_tree #(
    parameter N   = 16,  
    parameter W   = 8,   
    parameter K   = 6,   
    parameter BAL = 1,   
    parameter S   = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    localparam CLUSTER_W    = (K == 1) ? W : (W + K + 2);
    localparam NUM_CLUSTERS = (K == 1) ? N : ((N + K - 1) / K);
    localparam TOP_N        = (K == 1) ? N : (NUM_CLUSTERS * 2);
    function automatic integer next_lev_ragged(integer n_in);
        integer n_rem = n_in % 4;
        return (n_rem == 3) ? ((n_in/4)*2 + 2) : ((n_in/4)*2 + n_rem);
    endfunction
    function automatic integer next_lev_balanced(integer n_in);
        integer n_rem = n_in % 4;
        if (n_in <= 3) return (n_rem == 3) ? 2 : n_rem;
        if (n_rem == 0) return (n_in/4) * 2;
        if (n_rem == 1 || n_rem == 2) return ((n_in/4)-1)*2 + 4;
        return ((n_in/4)*2) + 2;
    endfunction
    function automatic integer get_next_sz(integer n, integer use_bal);
        return (use_bal != 0) ? next_lev_balanced(n) : next_lev_ragged(n);
    endfunction
    function automatic integer calc_depth(integer n_in);
        integer d = 0;
        integer count = n_in;
        while (count > 2) begin
            count = get_next_sz(count, BAL);
            d = d + 1;
        end
        return d;
    endfunction
    function automatic integer get_cnt_at_lev(integer l, integer start_n);
        integer c = start_n;
        for(integer k=0; k<l; k++) c = get_next_sz(c, BAL);
        return c;
    endfunction
    wire [TOP_N-1:0][CLUSTER_W-1:0] tree_inputs;
    if (K == 1) begin : g_no_cluster
        for (genvar i = 0; i < N; ++i) begin : g_map
            assign tree_inputs[i] = CLUSTER_W'(operands[i]);
        end
    end else begin : g_do_cluster
        for (genvar i = 0; i < NUM_CLUSTERS; ++i) begin : g_clusters
            localparam C_SIZE = (i == NUM_CLUSTERS - 1) ? (N - i*K) : K;
            if (C_SIZE == 1) begin : g_c1
                assign tree_inputs[2*i]     = CLUSTER_W'(operands[i*K]);
                assign tree_inputs[2*i + 1] = '0;
            end else begin : g_lin
                wire [CLUSTER_W-1:0] s_loc, c_loc;
                wire [C_SIZE-1:0][W-1:0] sub_ops;
                for(genvar j=0; j<C_SIZE; ++j) begin : g_slice
                    assign sub_ops[j] = operands[i*K + j];
                end
                VX_csa_block #(
                    .N(C_SIZE),
                    .W(W),
                    .S(CLUSTER_W)
                ) cluster_linear (
                    .operands(sub_ops),
                    .sum(s_loc),
                    .carry(c_loc)
                );
                assign tree_inputs[2*i]     = s_loc;
                assign tree_inputs[2*i + 1] = c_loc;
            end
        end
    end
    localparam DEPTH = calc_depth(TOP_N);
    localparam MAX_WN = CLUSTER_W + (DEPTH * 2) + 4;
    localparam WN = (S < MAX_WN) ? S : MAX_WN;
    wire [DEPTH:0][TOP_N-1:0][WN-1:0] tree_sig;
    for (genvar i = 0; i < TOP_N; i++) begin : g_init_l0
        assign tree_sig[0][i] = WN'(tree_inputs[i]);
    end
    for (genvar lev = 0; lev < DEPTH; lev++) begin : g_levels
        localparam integer NUM_IN = get_cnt_at_lev(lev, TOP_N);
        localparam integer WI = CLUSTER_W + (lev * 2);
        localparam integer WO = WI + 2;
        if (BAL == 1) begin : g_balanced
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            localparam integer CORE = (REM == 1 || REM == 2) ? (N_42 - 1) : N_42;
            for (genvar i = 0; i < CORE; i++) begin : g_core
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 1) begin : g_r1
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
                assign tree_sig[lev+1][OB+2] = tree_sig[lev][B+3]; assign tree_sig[lev+1][OB+3] = tree_sig[lev][B+4];
            end
            else if (REM == 2) begin : g_r2
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s1, c1, s2, c2;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cA (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s1),
                    .carry(c1)
                );
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cB (
                    .a(WI'(tree_sig[lev][B+3])),
                    .b(WI'(tree_sig[lev][B+4])),
                    .c(WI'(tree_sig[lev][B+5])),
                    .sum(s2),
                    .carry(c2)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s1); assign tree_sig[lev+1][OB+1] = WN'(c1);
                assign tree_sig[lev+1][OB+2] = WN'(s2); assign tree_sig[lev+1][OB+3] = WN'(c2);
            end
            else if (REM == 3) begin : g_r3
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
            end
        end
        else begin : g_ragged
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            for (genvar i = 0; i < N_42; i++) begin : g_csa42
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 3) begin : g_rem3
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][N_42*4])),
                    .b(WI'(tree_sig[lev][N_42*4+1])),
                    .c(WI'(tree_sig[lev][N_42*4+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][N_42*2] = WN'(s);
                assign tree_sig[lev+1][N_42*2+1] = WN'(c);
            end
            else begin : g_pass
                for(genvar p=0; p<REM; p++) begin : g_rem
                    assign tree_sig[lev+1][N_42*2+p] = tree_sig[lev][N_42*4+p];
                end
            end
        end
    end
    assign sum   = S'(tree_sig[DEPTH][0]);
    assign carry = (get_cnt_at_lev(DEPTH, TOP_N) > 1) ? S'(tree_sig[DEPTH][1]) : '0;
endmodule
module VX_ks_adder #(
    parameter N = 16,
    parameter BYPASS = 0
) (
    input  wire [N-1:0] dataa,
    input  wire [N-1:0] datab,
    input  wire         cin,
    output wire [N-1:0] sum,
    output wire         cout
);
    if (BYPASS) begin : g_bypass
        assign {cout, sum} = dataa + datab + N'(cin);
    end else begin : g_KS
        localparam LEVELS = $clog2(N);
        wire [LEVELS:0][N-1:0] G;
        wire [LEVELS:0][N-1:0] P;
        for (genvar i = 0; i < N; i++) begin : g_initial_gp
            assign G[0][i] = dataa[i] & datab[i];
            assign P[0][i] = dataa[i] ^ datab[i];
        end
        for (genvar k = 1; k <= LEVELS; k++) begin : g_ks_levels
            localparam STEP = 1 << (k - 1);
            for (genvar i = 0; i < N; i++) begin : g_ks_nodes
                if (i >= STEP) begin : g_compute_gp
                    assign G[k][i] = G[k-1][i] | (P[k-1][i] & G[k-1][i-STEP]);
                    assign P[k][i] = P[k-1][i] & P[k-1][i-STEP];
                end else begin : g_passthrough_gp
                    assign G[k][i] = G[k-1][i];
                    assign P[k][i] = P[k-1][i];
                end
            end
        end
        assign sum[0] = P[0][0] ^ cin;
        for (genvar i = 1; i < N; i++) begin : g_sum
            wire carry_in_i = G[LEVELS][i-1] | (P[LEVELS][i-1] & cin);
            assign sum[i] = P[0][i] ^ carry_in_i;
        end
        assign cout = G[LEVELS][N-1] | (P[LEVELS][N-1] & cin);
    end
endmodule
module VX_popcount63(
    input  wire [5:0] data_in,
    output wire [2:0] data_out
);
    reg [2:0] sum;
    always @(*) begin
        case (data_in)
         6'd0: sum=3'd0;   6'd1: sum=3'd1;   6'd2: sum=3'd1;   6'd3: sum=3'd2;
         6'd4: sum=3'd1;   6'd5: sum=3'd2;   6'd6: sum=3'd2;   6'd7: sum=3'd3;
         6'd8: sum=3'd1;   6'd9: sum=3'd2;  6'd10: sum=3'd2;  6'd11: sum=3'd3;
        6'd12: sum=3'd2;  6'd13: sum=3'd3;  6'd14: sum=3'd3;  6'd15: sum=3'd4;
        6'd16: sum=3'd1;  6'd17: sum=3'd2;  6'd18: sum=3'd2;  6'd19: sum=3'd3;
        6'd20: sum=3'd2;  6'd21: sum=3'd3;  6'd22: sum=3'd3;  6'd23: sum=3'd4;
        6'd24: sum=3'd2;  6'd25: sum=3'd3;  6'd26: sum=3'd3;  6'd27: sum=3'd4;
        6'd28: sum=3'd3;  6'd29: sum=3'd4;  6'd30: sum=3'd4;  6'd31: sum=3'd5;
        6'd32: sum=3'd1;  6'd33: sum=3'd2;  6'd34: sum=3'd2;  6'd35: sum=3'd3;
        6'd36: sum=3'd2;  6'd37: sum=3'd3;  6'd38: sum=3'd3;  6'd39: sum=3'd4;
        6'd40: sum=3'd2;  6'd41: sum=3'd3;  6'd42: sum=3'd3;  6'd43: sum=3'd4;
        6'd44: sum=3'd3;  6'd45: sum=3'd4;  6'd46: sum=3'd4;  6'd47: sum=3'd5;
        6'd48: sum=3'd2;  6'd49: sum=3'd3;  6'd50: sum=3'd3;  6'd51: sum=3'd4;
        6'd52: sum=3'd3;  6'd53: sum=3'd4;  6'd54: sum=3'd4;  6'd55: sum=3'd5;
        6'd56: sum=3'd3;  6'd57: sum=3'd4;  6'd58: sum=3'd4;  6'd59: sum=3'd5;
        6'd60: sum=3'd4;  6'd61: sum=3'd5;  6'd62: sum=3'd5;  6'd63: sum=3'd6;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_popcount32(
    input  wire [2:0] data_in,
    output wire [1:0] data_out
);
    reg [1:0] sum;
    always @(*) begin
        case (data_in)
        3'd0: sum=2'd0;   3'd1: sum=2'd1;   3'd2: sum=2'd1;   3'd3: sum=2'd2;
        3'd4: sum=2'd1;   3'd5: sum=2'd2;   3'd6: sum=2'd2;   3'd7: sum=2'd3;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_sum33(
    input  wire [2:0] data_in1,
    input  wire [2:0] data_in2,
    output wire [3:0] data_out
);
    reg [3:0] sum;
    always @(*) begin
        case ({data_in1, data_in2})
        6'd0:  sum=4'd0;   6'd1: sum=4'd1;   6'd2: sum=4'd2;   6'd3: sum=4'd3;
        6'd4:  sum=4'd4;   6'd5: sum=4'd5;   6'd6: sum=4'd6;   6'd7: sum=4'd7;
        6'd8:  sum=4'd1;   6'd9: sum=4'd2;  6'd10: sum=4'd3;  6'd11: sum=4'd4;
        6'd12: sum=4'd5;  6'd13: sum=4'd6;  6'd14: sum=4'd7;  6'd15: sum=4'd8;
        6'd16: sum=4'd2;  6'd17: sum=4'd3;  6'd18: sum=4'd4;  6'd19: sum=4'd5;
        6'd20: sum=4'd6;  6'd21: sum=4'd7;  6'd22: sum=4'd8;  6'd23: sum=4'd9;
        6'd24: sum=4'd3;  6'd25: sum=4'd4;  6'd26: sum=4'd5;  6'd27: sum=4'd6;
        6'd28: sum=4'd7;  6'd29: sum=4'd8;  6'd30: sum=4'd9;  6'd31: sum=4'd10;
        6'd32: sum=4'd4;  6'd33: sum=4'd5;  6'd34: sum=4'd6;  6'd35: sum=4'd7;
        6'd36: sum=4'd8;  6'd37: sum=4'd9;  6'd38: sum=4'd10; 6'd39: sum=4'd11;
        6'd40: sum=4'd5;  6'd41: sum=4'd6;  6'd42: sum=4'd7;  6'd43: sum=4'd8;
        6'd44: sum=4'd9;  6'd45: sum=4'd10; 6'd46: sum=4'd11; 6'd47: sum=4'd12;
        6'd48: sum=4'd6;  6'd49: sum=4'd7;  6'd50: sum=4'd8;  6'd51: sum=4'd9;
        6'd52: sum=4'd10; 6'd53: sum=4'd11; 6'd54: sum=4'd12; 6'd55: sum=4'd13;
        6'd56: sum=4'd7;  6'd57: sum=4'd8;  6'd58: sum=4'd9;  6'd59: sum=4'd10;
        6'd60: sum=4'd11; 6'd61: sum=4'd12; 6'd62: sum=4'd13; 6'd63: sum=4'd14;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_popcount #(
    parameter MODEL = 1,
    parameter N     = 1,
    parameter M     = $clog2(N+1)
) (
    input  wire [N-1:0] data_in,
    output wire [M-1:0] data_out
);
    if (N == 1) begin : g_passthru
        assign data_out = data_in;
    end else if (N <= 3) begin : g_popcount3
        reg [2:0] t_in;
        wire [1:0] t_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount32 pc32(t_in, t_out);
        assign data_out = t_out[M-1:0];
    end else if (N <= 6) begin : g_popcount6
        reg [5:0] t_in;
        wire [2:0] t_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63(t_in, t_out);
        assign data_out = t_out[M-1:0];
    end else if (N <= 9) begin : g_popcount9
        reg [8:0] t_in;
        wire [4:0] t1_out;
        wire [3:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63(t_in[5:0], t1_out[2:0]);
        VX_popcount32 pc32(t_in[8:6], t1_out[4:3]);
        VX_sum33 sum33(t1_out[2:0], {1'b0, t1_out[4:3]}, t2_out);
        assign data_out = t2_out[M-1:0];
    end else if (N <= 12) begin : g_popcount12
        reg [11:0] t_in;
        wire [5:0] t1_out;
        wire [3:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63a(t_in[5:0],  t1_out[2:0]);
        VX_popcount63 pc63b(t_in[11:6], t1_out[5:3]);
        VX_sum33 sum33(t1_out[2:0], t1_out[5:3], t2_out);
        assign data_out = t2_out[M-1:0];
    end else if (N <= 18) begin : g_popcount18
        reg [17:0] t_in;
        wire [8:0] t1_out;
        wire [5:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63a(t_in[5:0],   t1_out[2:0]);
        VX_popcount63 pc63b(t_in[11:6],  t1_out[5:3]);
        VX_popcount63 pc63c(t_in[17:12], t1_out[8:6]);
        VX_popcount32 pc32a({t1_out[0], t1_out[3], t1_out[6]}, t2_out[1:0]);
        VX_popcount32 pc32b({t1_out[1], t1_out[4], t1_out[7]}, t2_out[3:2]);
        VX_popcount32 pc32c({t1_out[2], t1_out[5], t1_out[8]}, t2_out[5:4]);
        assign data_out = {2'b0,t2_out[1:0]} + {1'b0,t2_out[3:2],1'b0} + {t2_out[5:4],2'b0};
    end else if (MODEL == 1) begin : g_model1
        localparam PN = 1 << $clog2(N);
        localparam LOGPN = $clog2(PN);
        wire [M-1:0] tmp [LOGPN-1:0][PN-1:0];
        for (genvar j = 0; j < LOGPN; ++j) begin
            localparam D = j + 1;
            localparam Q = (D < LOGPN) ? (D + 1) : M;
            for (genvar i = 0; i < (1 << (LOGPN-j-1)); ++i) begin
                localparam l = i * 2;
                localparam r = i * 2 + 1;
                wire [Q-1:0] res;
                if (j == 0) begin
                    if (r < N) begin
                        assign res = data_in[l] + data_in[r];
                    end else if (l < N) begin
                        assign res = 2'(data_in[l]);
                    end else begin
                        assign res = 2'b0;
                    end
                end else begin
                    assign res = D'(tmp[j-1][l]) + D'(tmp[j-1][r]);
                end
                assign tmp[j][i] = M'(res);
            end
        end
        assign data_out = tmp[LOGPN-1][0];
    end else begin : g_model2
        reg [M-1:0] cnt_w;
        always @(*) begin
            cnt_w = '0;
            for (integer i = 0; i < N; ++i) begin
                cnt_w = cnt_w + M'(data_in[i]);
            end
        end
        assign data_out = cnt_w;
    end
endmodule
module VX_tcu_tfr_acc import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N  = 5,
    parameter WO = 30
) (
    input  wire                 clk,
    input  wire                 valid_in,
    input  wire [31:0]          req_id,
    input  wire [N-1:0][WO-1:0] sigs_in,
    input  wire [N-1:0]         sticky_in,
    input  wire [N-1:0]         fp_negs,
    output wire [WO-1:0]        sum_out,
    output wire [WO-1:0]        sig_out,    
    output wire                 sign_out,   
    output wire                 sticky_out
);
    wire [$clog2(N+1)-1:0] fp_neg_count;
    VX_popcount #(
        .N (N)
    ) fp_neg_popcount (
        .data_in  (fp_negs),
        .data_out (fp_neg_count)
    );
    wire [N:0][WO-1:0] sig_operands;
    for (genvar i = 0; i < N; ++i) begin : g_ops
        assign sig_operands[i] = sigs_in[i];
    end
    assign sig_operands[N] = WO'(fp_neg_count);
    wire [WO-1:0] sum_vec;
    wire [WO-1:0] carry_vec;
    VX_csa_tree #(
        .N (N+1),
        .W (WO),
        .S (WO)
    ) sig_csa (
        .operands (sig_operands),
        .sum      (sum_vec),
        .carry    (carry_vec)
    );
    wire [WO-1:0] sig_pos;
    VX_ks_adder #(
        .N (WO),
        .BYPASS (0)
    ) final_adder (
        .cin   (1'b0),
        .dataa (sum_vec),
        .datab (carry_vec),
        .sum   (sig_pos),
        . cout ()
    );
    wire [WO-1:0] sig_neg_raw;
    VX_ks_adder #(
        .N (WO),
        .BYPASS (0)
    ) neg_adder (
        .cin   (1'b1),
        .dataa (~sum_vec),
        .datab (~carry_vec),
        .sum   (sig_neg_raw),
        . cout ()
    );
    wire [WO-1:0] sig_neg = sig_neg_raw + WO'(1);
    assign sign_out = sig_pos[WO-1];
    assign sum_out  = sig_pos;
    assign sig_out  = sign_out ? sig_neg : sig_pos;
    assign sticky_out = |sticky_in;
endmodule
module VX_paired_shift_jam #(
    parameter LW = 26,
    parameter AW = 8
) (
    input  wire [2*LW-1:0]   data_in,
    input  wire [1:0][AW-1:0] amount,
    input  wire              joined,
    output wire [2*LW-1:0]   data_out,
    output wire [1:0]        sticky
);
    localparam W = 2 * LW;
    localparam LEVELS = $clog2(W);
    wire [LEVELS:0][W-1:0] stage;
    wire [LEVELS:0][1:0] lost;
    assign stage[0] = data_in;
    assign lost[0] = '0;
    for (genvar s = 0; s < LEVELS; ++s) begin : g_stage
        localparam D = 1 << s;
        for (genvar i = 0; i < W; ++i) begin : g_bit
            localparam LANE = i / LW;
            wire control = joined ? amount[0][s] : amount[LANE][s];
            wire incoming;
            if (i+D >= W) begin : g_outside
                assign incoming = 1'b0;
            end else if (i/LW != (i+D)/LW) begin : g_boundary
                assign incoming = joined && stage[s][i+D];
            end else begin : g_inside
                assign incoming = stage[s][i+D];
            end
            assign stage[s+1][i] = control ? incoming : stage[s][i];
        end
        for (genvar q = 0; q < 2; ++q) begin : g_sticky
            localparam LOST_W = D < LW ? D : LW;
            wire lane_lost = |stage[s][q*LW +: LOST_W];
            wire full_lost = |stage[s][D-1:0];
            assign lost[s+1][q] = joined
                               ? ((q == 0) && (lost[s][0] || (amount[0][s] && full_lost)))
                               : (lost[s][q] || (amount[q][s] && lane_lost));
        end
    end
    for (genvar q = 0; q < 2; ++q) begin : g_output
        wire over = joined ? amount[0] >= AW'(W) : amount[q] >= AW'(LW);
        assign data_out[q*LW +: LW] = over ? '0 : stage[LEVELS][q*LW +: LW];
        assign sticky[q] = joined ? ((q == 0) && (over ? (|data_in) : lost[LEVELS][0]))
                                 : (over ? (|data_in[q*LW +: LW]) : lost[LEVELS][q]);
    end
endmodule
module VX_tcu_tfr_align import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N     = 5,
    parameter WI    = 25,
    parameter WO    = WI + 5,
    parameter SHARED_SHIFT = 0
) (
    input  wire                 clk,
    input  wire                 valid_in,
    input  wire [31:0]          req_id,
    input  wire [N-1:0][TCU_EXP_BITS-1:0] exponents,
    input  wire [N-1:0]         sel_exp,
    input  wire [N-2:0]         lane_mask,
    input  wire [N-1:0][WI-1:0] sigs_in,
    input  wire                 is_int,
    input  wire                 external_shift,
    input  wire [51:0]          external_data,
    input  wire [7:0]           external_amount,
    output wire [51:0]          external_result,
    output wire                 external_sticky,
    output logic [TCU_EXP_BITS-1:0] max_exp,
    output wire [N-1:0][WO-1:0] sigs_out,
    output wire [N-1:0]         sticky_bits,
    output wire [N-1:0]         fp_negs
);
    localparam MAX_PRE_SHIFT = WI - 23;
    localparam SHIFT_MAG_W   = (WI - 1) + MAX_PRE_SHIFT;
    wire [N:0][TCU_EXP_BITS-1:0] or_red;
    wire [N-1:0][7:0] shift_amts;
    wire [N-1:0][SHIFT_MAG_W-1:0] preshift_magnitudes;
    wire [51:0] paired_result;
    wire [1:0] paired_sticky;
    if (SHARED_SHIFT) begin : g_shared_shift
        VX_paired_shift_jam shifter (
            .data_in  (external_shift ? external_data : {preshift_magnitudes[N-2], preshift_magnitudes[N-3]}),
            .amount   (external_shift ? {external_amount, external_amount} : {shift_amts[N-2], shift_amts[N-3]}),
            .joined   (external_shift),
            .data_out (paired_result),
            .sticky   (paired_sticky)
        );
    end else begin : g_no_shared_shift
        assign paired_result = '0;
        assign paired_sticky = '0;
    end
    assign external_result = paired_result;
    assign external_sticky = paired_sticky[0];
    assign or_red[0] = {TCU_EXP_BITS{1'b0}};
    for (genvar i = 0; i < N; i++) begin : g_or_red
        assign or_red[i+1] = or_red[i] | (sel_exp[i] ? exponents[i] : {TCU_EXP_BITS{1'b0}});
    end
    assign max_exp = or_red[N];
    for (genvar i = 0; i < N; i++) begin : g_shift_amts
        wire [TCU_EXP_BITS-1:0] shift_full = max_exp - exponents[i];
        if (TCU_EXP_BITS > 8) begin : g_sat
            assign shift_amts[i] = (|shift_full[TCU_EXP_BITS-1:8]) ? 8'hFF : shift_full[7:0];
        end else begin : g_no_sat
            assign shift_amts[i] = 8'(shift_full);
        end
    end
    for (genvar i = 0; i < N; ++i) begin : g_align_lanes
        wire [7:0] shift_amt = shift_amts[i];
        wire lane_en;
        if (i == N-1) begin : g_c_en
            assign lane_en = 1'b1;  
        end else begin : g_lane_en
            assign lane_en = lane_mask[i];
        end
        wire in_sign = sigs_in[i][WI-1];
        wire [WI-2:0] in_mag = sigs_in[i][WI-2:0];
        wire [SHIFT_MAG_W-1:0] mag_shifted;
        assign preshift_magnitudes[i] = mag_shifted;
        if (i == N-1) begin : g_c_term
            assign mag_shifted = { {(MAX_PRE_SHIFT - (WI - 24)){1'b0}}, in_mag, {(WI - 24){1'b0}} };
        end else begin : g_prod_term
            assign mag_shifted = { in_mag, {(WI - 23){1'b0}} };
        end
        wire is_overshift = (shift_amt >= 8'(SHIFT_MAG_W));
        wire [SHIFT_MAG_W-1:0] shift_res_full;
        if (SHARED_SHIFT && (i == N-3 || i == N-2)) begin : g_paired
            assign shift_res_full = paired_result[(i-(N-3))*SHIFT_MAG_W +: SHIFT_MAG_W];
            assign sticky_bits[i] = lane_en && paired_sticky[i-(N-3)];
        end else begin : g_ordinary
            assign shift_res_full = mag_shifted >> shift_amt;
            wire [SHIFT_MAG_W-1:0] sticky_check_shift = mag_shifted << (8'(SHIFT_MAG_W) - shift_amt);
            assign sticky_bits[i] = lane_en & (is_overshift ? (|mag_shifted) : (|sticky_check_shift));
        end
        wire [WI:0] adj_mag = is_overshift ? '0 : shift_res_full[WI:0];
        wire fp_neg = in_sign & lane_en & ~is_int;
        wire [WO-1:0] fp_mag  = WO'(adj_mag) & {WO{lane_en}};
        wire [WO-1:0] fp_form = fp_neg ? ~fp_mag : fp_mag;
        wire [WO-1:0] int_form = WO'($signed(sigs_in[i])) & {WO{lane_en}};
        assign sigs_out[i] = is_int ? int_form : fp_form;
        assign fp_negs[i]  = fp_neg;
    end
endmodule
module VX_find_first #(
    parameter N       = 1,
    parameter DATAW   = 1,
    parameter REVERSE = 0  
) (
    input  wire [N-1:0][DATAW-1:0] data_in,
    input  wire [N-1:0]            valid_in,
    output wire [DATAW-1:0]        data_out,
    output wire                    valid_out
);
    localparam LOGN = $clog2(N);
    localparam TL   = (1 << LOGN) - 1;
    localparam TN   = (1 << (LOGN+1)) - 1;
    reg             valid_r;
    reg [DATAW-1:0] data_r;
    always @(*) begin : g_scan
        reg [TN-1:0]       s_n;
        reg [TN*DATAW-1:0] d_n;
        s_n = '0;
        d_n = '0;
        for (integer i = 0; i < N; ++i) begin
            s_n[TL+i] = REVERSE ? valid_in[N-1-i] : valid_in[i];
            d_n[(TL+i)*DATAW +: DATAW] = REVERSE ? data_in[N-1-i] : data_in[i];
        end
        for (integer k = TL-1; k >= 0; --k) begin
            s_n[k] = s_n[2*k+2] | s_n[2*k+1];
            d_n[k*DATAW +: DATAW] = s_n[2*k+1] ? d_n[(2*k+1)*DATAW +: DATAW] : d_n[(2*k+2)*DATAW +: DATAW];
        end
        valid_r = s_n[0];
        data_r  = d_n[0 +: DATAW];
    end
    assign valid_out = valid_r;
    assign data_out  = data_r;
endmodule
module VX_lzc #(
    parameter N       = 2,
    parameter REVERSE = 0,   
    parameter LOGN    = (((N) > 1) ? $clog2(N) : 1)
) (
    input  wire [N-1:0]    data_in,
    output wire [LOGN-1:0] data_out,
    output wire            valid_out
);
    if (N == 1) begin : g_passthru
        assign data_out  = '0;
        assign valid_out = data_in;
    end else begin : g_lzc
        wire [N-1:0][LOGN-1:0] indices;
        for (genvar i = 0; i < N; ++i) begin : g_indices
            assign indices[i] = REVERSE ? LOGN'(i) : LOGN'(N-1-i);
        end
        VX_find_first #(
            .N       (N),
            .DATAW   (LOGN),
            .REVERSE (!REVERSE)
        ) find_first (
            .valid_in  (data_in),
            .data_in   (indices),
            .data_out  (data_out),
            .valid_out (valid_out)
        );
    end
endmodule
module VX_tcu_tfr_norm_round import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter WA = 30,
    parameter EXP_W = 10,
    parameter C_HI_W = 8
) (
    input wire          clk,
    input wire          valid_in,
    input wire [31:0]   req_id,
    input wire [EXP_W-1:0] max_exp,
    input wire [WA-1:0] acc_sig,    
    input wire          acc_sign,   
    input wire [C_HI_W-1:0] cval_hi,
    input wire          is_int,
    input wire          sticky_in,
    input fedp_excep_t  exceptions,
    output wire [31:0]  result
);
    wire sum_sign = acc_sign;
    wire [WA-1:0] abs_sum = acc_sig;
    wire zero_sum = ~|acc_sig;
    wire [$clog2(WA)-1:0] lz_count;
    VX_lzc #(
        .N(WA)
    ) lzc_inst (
        .data_in   (abs_sum),
        .data_out  (lz_count),
        . valid_out ()
    );
    wire signed [EXP_W-1:0] norm_exp_base;
    wire signed [EXP_W-1:0] norm_exp_plus1;
    wire [EXP_W-1:0] sub_term = EXP_W'({1'b1, 2'b00, lz_count});
    VX_ks_adder #(
        .N(EXP_W),
        .BYPASS (0)
    ) exp_sub (
        .cin   (1'b1),
        .dataa (max_exp),
        .datab (~sub_term),
        .sum   (norm_exp_base),
        . cout ()
    );
    assign norm_exp_plus1 = norm_exp_base + EXP_W'(1'b1);
    wire [WA-1:0] shifted_sum = abs_sum << lz_count;
    wire [26:0] aligned_bits = shifted_sum[WA-1 -: 27];
    wire [23:0] norm_man   = aligned_bits[26:3];
    wire        guard_bit  = aligned_bits[2];
    wire        round_bit  = aligned_bits[1];
    wire        sticky_bit = aligned_bits[0] | (|shifted_sum[WA-27:0]) | sticky_in;
    wire        lsb_bit    = norm_man[0];
    wire round_up = guard_bit && (round_bit || sticky_bit || lsb_bit);
    wire [24:0] man_plus_zero = {1'b0, norm_man};
    wire [24:0] man_plus_one;
    VX_ks_adder #(
        .N(25),
        .BYPASS (0)
    ) round_adder (
        .cin   (1'b1),
        .dataa (man_plus_zero),
        .datab (25'd0),
        .sum   (man_plus_one),
        . cout ()
    );
    wire [24:0] rounded_sig_full = round_up ? man_plus_one : man_plus_zero;
    wire carry_out = rounded_sig_full[24];
    wire [22:0] final_man = carry_out ? rounded_sig_full[23:1] : rounded_sig_full[22:0];
    wire signed [EXP_W-1:0] final_exp_s = carry_out ? norm_exp_plus1 : norm_exp_base;
    logic [7:0] packed_exp;
    logic exp_overflow, exp_underflow;
    always_comb begin
        if (final_exp_s >= 255) begin
            packed_exp = 8'hFF;
            exp_overflow = 1'b1;
            exp_underflow = 1'b0;
        end else if (final_exp_s <= 0) begin
            packed_exp = 8'h00;
            exp_overflow = 1'b0;
            exp_underflow = 1'b1;
        end else begin
            packed_exp = final_exp_s[7:0];
            exp_overflow = 1'b0;
            exp_underflow = 1'b0;
        end
    end
    wire [31:0] fp_nan_result = {1'b0, 8'hFF, 1'b1, 22'd0};
    wire [31:0] fp_inf_result = {exceptions.sign, 8'hFF, 23'd0};
    wire [31:0] fp_zero_result = {sum_sign, 8'd0, 23'd0};
    wire [31:0] fp_overflow_result = {sum_sign, 8'hFF, 23'd0};
    wire [31:0] fp_normal_result = {sum_sign, packed_exp, final_man};
    logic [31:0] fp_result;
    always_comb begin
        if (exceptions.is_nan) begin
            fp_result = fp_nan_result;
        end else if (exceptions.is_inf) begin
            fp_result = fp_inf_result;
        end else begin
            if (zero_sum || exp_underflow) begin
                 fp_result = fp_zero_result;
            end else if (exp_overflow) begin
                 fp_result = fp_overflow_result;
            end else begin
                 fp_result = fp_normal_result;
            end
        end
    end
    assign result = fp_result;
endmodule
module VX_pipe_register #(
    parameter DATAW  = 1,
    parameter RESETW = 0,
    parameter DEPTH  = 1,
    parameter [(((RESETW) > 0) ? (RESETW) : 1)-1:0] INIT_VALUE = {(((RESETW) > 0) ? (RESETW) : 1){1'b0}}
) (
    input wire              clk,
    input wire              reset,
    input wire              enable,
    input wire [DATAW-1:0]  data_in,
    output wire [DATAW-1:0] data_out
);
    if (DEPTH == 0) begin : g_passthru
        assign data_out = data_in;
    end else begin : g_pipe
        wire [DEPTH-1:0][DATAW-1:0] pipe_out;
        if (RESETW == DATAW) begin : g_full_reset
            reg [DEPTH-1:0][DATAW-1:0] pipe;
            always_ff @(posedge clk) begin
                if (reset) begin
                    pipe <= {DEPTH{INIT_VALUE}};
                end else if (enable) begin
                    pipe[0] <= data_in;
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe[i] <= pipe[i-1];
                    end
                end
            end
            assign pipe_out = pipe;
        end else if (RESETW != 0) begin : g_partial_reset
            localparam FREEW = DATAW - RESETW;
            reg [DEPTH-1:0][RESETW-1:0] pipe_rst;
            reg [DEPTH-1:0][FREEW-1:0]  pipe_free;
            always_ff @(posedge clk) begin
                if (reset) begin
                    for (int i = 0; i < DEPTH; ++i) begin
                        pipe_rst[i] <= INIT_VALUE;
                    end
                end else if (enable) begin
                    pipe_rst[0] <= data_in[DATAW-1 : FREEW];
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe_rst[i] <= pipe_rst[i-1];
                    end
                end
            end
            always_ff @(posedge clk) begin
                if (enable) begin
                    pipe_free[0] <= data_in[FREEW-1 : 0];
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe_free[i] <= pipe_free[i-1];
                    end
                end
            end
            for (genvar i = 0; i < DEPTH; ++i) begin : g_join
                assign pipe_out[i] = {pipe_rst[i], pipe_free[i]};
            end
        end else begin : g_no_reset
            reg [DEPTH-1:0][DATAW-1:0] pipe;
            always_ff @(posedge clk) begin
                if (enable) begin
                    pipe[0] <= data_in;
                    for (int i = 1; i < DEPTH; ++i) begin
                        pipe[i] <= pipe[i-1];
                    end
                end
            end
            assign pipe_out = pipe;
        end
        assign data_out = pipe_out[DEPTH-1];
    end
endmodule
module VX_tcu_tfr_exc_reduce import VX_tcu_pkg::*; #(
    parameter TCK = 4
) (
    input  fedp_excep_t [TCK:0] exc_in,
    output fedp_excep_t         exc_out
);
    logic [TCK-1:0] lane_nan;
    logic [TCK-1:0] lane_inf;
    logic [TCK-1:0] lane_sign;
    for (genvar i = 0; i < TCK; ++i) begin : g_unpack
        assign lane_nan[i]  = exc_in[i].is_nan;
        assign lane_inf[i]  = exc_in[i].is_inf;
        assign lane_sign[i] = exc_in[i].sign;
    end
    wire c_is_nan = exc_in[TCK].is_nan;
    wire c_is_inf = exc_in[TCK].is_inf;
    wire c_sign   = exc_in[TCK].sign;
    wire [TCK-1:0] p_pos_inf = lane_inf & ~lane_sign;
    wire [TCK-1:0] p_neg_inf = lane_inf &  lane_sign;
    wire has_pos = (|p_pos_inf) | (c_is_inf & ~c_sign);
    wire has_neg = (|p_neg_inf) | (c_is_inf &  c_sign);
    wire res_nan = (|lane_nan) | c_is_nan | (has_pos & has_neg);
    wire res_inf = (has_pos | has_neg) & ~res_nan;
    assign exc_out.is_nan = res_nan;
    assign exc_out.is_inf = res_inf;
    assign exc_out.sign   = has_neg & ~has_pos;
endmodule
module VX_tcu_tfr_lane_mask import VX_tcu_pkg::*; #(
    parameter N   = 2,
    parameter TCK = 2 * N
) (
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [4:0]                fmt_s,
    output logic [TCK-1:0]          lane_mask
);
    wire [TCK-1:0] mask_32;
    wire [TCK-1:0] mask_16;
    wire [TCK-1:0] mask_8;
    wire [TCK-1:0] mask_4;
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_32
        if ((i % 2) == 0) begin : g_even_lane
            assign mask_32[i] = vld_mask[i * 4];
        end else begin : g_odd_lane
            assign mask_32[i] = 1'b0;
        end
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_16
        assign mask_16[i] = vld_mask[i * 4];
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_8
        assign mask_8[i] = vld_mask[i * 4 + 0] | vld_mask[i * 4 + 2];
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mask_4
        assign mask_4[i] = vld_mask[i * 4 + 0]
                         | vld_mask[i * 4 + 1]
                         | vld_mask[i * 4 + 2]
                         | vld_mask[i * 4 + 3];
    end
    always_comb begin
        case (fmt_s)
            TCU_FP16_ID,
            TCU_BF16_ID: lane_mask = mask_16;
            TCU_TF32_ID: lane_mask = mask_32;
            TCU_FP8_ID,
            TCU_BF8_ID:  lane_mask = mask_8;
            TCU_MXFP8_ID,
            TCU_MXBF8_ID:lane_mask = mask_8;
            TCU_MXFP4_ID:lane_mask = mask_4;
            TCU_NVFP4_ID:lane_mask = mask_4;
            default:     lane_mask = '0;
        endcase
    end
endmodule
module VX_tcu_tfr_max_exp import VX_tcu_pkg::*; #(
    parameter N     = 5,
    parameter WIDTH = 8
) (
    input  wire [N-1:0][WIDTH-1:0] exponents,
    output wire [N-1:0]            sel_exp
);
    wire [N-2:0][N-2:0] sign_mat;
    for (genvar i = 0; i < N-1; i++) begin : g_row
        for (genvar j = 0; j < N-1; j++) begin : g_col
            if (j < i) begin : g_lower
                assign sign_mat[i][j] = ~sign_mat[j][i];
            end else begin : g_upper
                assign sign_mat[i][j] = (exponents[i] < exponents[j+1]);
            end
        end
    end
    for (genvar i = 0; i < N; i++) begin : g_index
        wire and_left, or_right;
        if (i == 0) begin : g_first
            assign and_left = 1'b1;
        end else begin : g_and_left
            wire [i-1:0] left_signals;
            for (genvar jl = 0; jl < i; jl++) begin : g_left
                assign left_signals[jl] = sign_mat[jl][i-1];
            end
            assign and_left = &left_signals;
        end
        if (i == N-1) begin : g_last
            assign or_right = 1'b0;
        end else begin : g_or_right
            wire [N-2-i:0] right_signals;
            for (genvar jr = i+1; jr < N; jr++) begin : g_right
                assign right_signals[jr-i-1] = sign_mat[i][jr-1];
            end
            assign or_right = |right_signals;
        end
        assign sel_exp[i] = and_left & (~or_right);
    end
endmodule
module VX_tcu_tfr_classifier import VX_tcu_pkg::*; #(
    parameter EXP_W = 8,
    parameter MAN_W = 23
) (
    input wire [EXP_W-1:0] exp,
    input wire [MAN_W-1:0] man,
    output fedp_class_t    cls
);
    wire exp_zero = ~|exp;
    wire exp_ones = &exp;
    wire man_non_zero = |man;
    wire man_zero     = ~man_non_zero;
    assign cls.is_zero = exp_zero & man_zero;
    assign cls.is_sub  = exp_zero & man_non_zero;
    assign cls.is_inf  = exp_ones & man_zero;
    assign cls.is_nan  = exp_ones & man_non_zero;
endmodule
module VX_wallace_mul #(
    parameter N = 8,
    parameter P = 2 * N,
    parameter CPA_KS = 1  
) (
    input wire [N-1:0]  a,
    input wire [N-1:0]  b,
    output wire [P-1:0] p
);
    wire [N-1:0][2*N-1:0] pp;     
    for (genvar g = 0; g < N; g++) begin: g_pp_loop
        for (genvar h = 0; h < N; h++) begin: g_and_loop
            assign pp[g][h+g] = a[h] & b[g];
        end
        if (g != 0) begin : g_bit_fill
            assign pp[g][g-1:0] = {g{1'b0}};     
        end
        assign pp[g][2*N-1:N+g] = {(N-g){1'b0}};     
    end
    wire [P-1:0] sum_vec, carry_vec;
    VX_csa_tree #(
        .N (N),
        .W (2*N),
        .S (P)
    ) pp_acc (
        .operands (pp),
        .sum  (sum_vec),
        .carry(carry_vec)
    );
    VX_ks_adder #(
        .N(P),
        .BYPASS(CPA_KS == 0)
    ) final_add (
        .dataa(sum_vec),
        .datab(carry_vec),
        .cin(1'b0),
        .sum(p),
        . cout ()
    );
endmodule
module VX_tcu_tfr_wmul #(
    parameter N        = 4,        
    parameter M        = N,        
    parameter LANES    = 1,        
    parameter SHARED_B = 0,        
    parameter P        = N + M,    
    parameter USE_DSP  = 0,
    parameter OUT_REG  = 0         
) (
    input  wire                    clk,
    input  wire                    enable,
    input  wire [LANES-1:0][N-1:0] a,
    input  wire [LANES-1:0][M-1:0] b,
    output wire [LANES-1:0][P-1:0] p
);
    if (USE_DSP == 0) begin : g_lut
        wire [LANES-1:0][P-1:0] p_w;
        for (genvar i = 0; i < LANES; ++i) begin : g_mul
            localparam BI = (SHARED_B != 0) ? 0 : i;
            if (N == M) begin : g_wal
                VX_wallace_mul #(
                    .N (N),
                    .P (P),
                    .CPA_KS (!0)
                ) u_mul (
                    .a (a[i]),
                    .b (b[BI]),
                    .p (p_w[i])
                );
            end else begin : g_inf
                assign p_w[i] = a[i] * b[BI];
            end
        end
        if (SHARED_B != 0 && LANES > 1) begin : g_unused
        end
        VX_pipe_register #(
            .DATAW (LANES * P),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (p_w),
            .data_out (p)
        );
    end else if (LANES == 1) begin : g_dsp1
        (* use_dsp = "yes" *) wire [P-1:0] prod = a[0] * b[0];
        VX_pipe_register #(
            .DATAW (P),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (prod),
            .data_out (p[0])
        );
    end else if (SHARED_B != 0) begin : g_dsp_shared
        localparam K  = P;                   
        localparam AW = K + N;
        wire [AW-1:0]      pa   = {a[1], {(K-N){1'b0}}, a[0]};
        (* use_dsp = "yes" *) wire [AW+M-1:0] prod = pa * b[0];
        wire [AW+M-1:0] prod_r;
        VX_pipe_register #(
            .DATAW (AW + M),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (prod),
            .data_out (prod_r)
        );
        assign p[0] = prod_r[P-1:0];
        assign p[1] = prod_r[K +: P];
    end else begin : g_dsp_indep
        localparam K  = P + 1;               
        localparam AW = K + N;
        localparam BW = K + M;
        wire [AW-1:0]      pa   = {a[1], {(K-N){1'b0}}, a[0]};
        wire [BW-1:0]      pb   = {b[1], {(K-M){1'b0}}, b[0]};
        (* use_dsp = "yes" *) wire [AW+BW-1:0] prod = pa * pb;
        wire [AW+BW-1:0] prod_r;
        VX_pipe_register #(
            .DATAW (AW + BW),
            .DEPTH (OUT_REG)
        ) prod_reg (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (prod),
            .data_out (prod_r)
        );
        assign p[0] = prod_r[P-1:0];
        assign p[1] = prod_r[2*K +: P];
    end
endmodule
module VX_tcu_tfr_mul_f16 import VX_tcu_pkg::*;
#(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0,  
    parameter EXTERNAL_MUL = 0
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output wire [TCK-1:0][10:0]     mantissa_a,
    output wire [TCK-1:0][10:0]     mantissa_b,
    input wire [TCK-1:0][21:0]      external_products,
    output wire  [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions
);
    if (!EXTERNAL_MUL) begin : g_unused_external
    end
    logic sig_en;
    always_comb begin
        case (fmt_f)
            TCU_FP16_ID,
            TCU_BF16_ID: sig_en = 1'b1;
            TCU_TF32_ID: sig_en = 1'b1;
            default:     sig_en = 1'b0;
        endcase
    end
    wire sig_en_r;
    VX_pipe_register #(
        .DATAW (1),
        .DEPTH (PROD_REG)
    ) pipe_sig_en (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (sig_en),
        .data_out (sig_en_r)
    );
    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + S_FP32 - S_SUPER - W + WA - 1 + 128;
    localparam E_TF32 = VX_tcu_pkg::exp_bits(TCU_TF32_ID);
    localparam S_TF32 = VX_tcu_pkg::sign_pos(TCU_TF32_ID);
    localparam B_TF32 = (1 << (E_TF32 - 1)) - 1;
    localparam [7:0] BIAS_CONST_TF32 = 8'(BIAS_BASE - 2*B_TF32);
    localparam E_FP16 = VX_tcu_pkg::exp_bits(TCU_FP16_ID);
    localparam S_FP16 = VX_tcu_pkg::sign_pos(TCU_FP16_ID);
    localparam B_FP16 = (1 << (E_FP16 - 1)) - 1;
    localparam [7:0] BIAS_CONST_FP16 = 8'(BIAS_BASE - 2*B_FP16);
    localparam E_BF16 = VX_tcu_pkg::exp_bits(TCU_BF16_ID);
    localparam S_BF16 = VX_tcu_pkg::sign_pos(TCU_BF16_ID);
    localparam B_BF16 = (1 << (E_BF16 - 1)) - 1;
    localparam [7:0] BIAS_CONST_BF16 = 8'(BIAS_BASE - 2*B_BF16);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire lane_valid = vld_mask[i*4];
        localparam OFF_16 = (i % 2) * 16;
        logic [7:0] raw_ea, raw_eb;
        logic [9:0] raw_ma, raw_mb;
        logic       raw_sa, raw_sb;
        logic [7:0] bias_sel;
        always_comb begin
            case (fmt_f)
                TCU_FP16_ID: begin
                    raw_ea    = 8'(a_row[i/2][S_FP16-1+OFF_16 -: E_FP16]);
                    raw_eb    = 8'(b_col[i/2][S_FP16-1+OFF_16 -: E_FP16]);
                    raw_ma    = a_row[i/2][9+OFF_16 -: 10];
                    raw_mb    = b_col[i/2][9+OFF_16 -: 10];
                    raw_sa    = a_row[i/2][15+OFF_16];
                    raw_sb    = b_col[i/2][15+OFF_16];
                    bias_sel  = BIAS_CONST_FP16;
                end
                TCU_BF16_ID: begin
                    raw_ea    = a_row[i/2][S_BF16-1+OFF_16 -: E_BF16];
                    raw_eb    = b_col[i/2][S_BF16-1+OFF_16 -: E_BF16];
                    raw_ma    = {a_row[i/2][6+OFF_16 -: 7], 3'b0};
                    raw_mb    = {b_col[i/2][6+OFF_16 -: 7], 3'b0};
                    raw_sa    = a_row[i/2][15+OFF_16];
                    raw_sb    = b_col[i/2][15+OFF_16];
                    bias_sel  = BIAS_CONST_BF16;
                end
                TCU_TF32_ID: begin
                    if ((i % 2) == 0) begin
                        raw_ea    = a_row[i/2][S_TF32-1 -: E_TF32];
                        raw_eb    = b_col[i/2][S_TF32-1 -: E_TF32];
                        raw_ma    = a_row[i/2][9:0];
                        raw_mb    = b_col[i/2][9:0];
                        raw_sa    = a_row[i/2][18];
                        raw_sb    = b_col[i/2][18];
                        bias_sel  = BIAS_CONST_TF32;
                    end else begin
                        raw_ea    = '0;
                        raw_eb    = '0;
                        raw_ma    = '0;
                        raw_mb    = '0;
                        raw_sa    = '0;
                        raw_sb    = '0;
                        bias_sel  = '0;
                    end
                end
                default: begin
                    raw_ea    = '0;
                    raw_eb    = '0;
                    raw_ma    = '0;
                    raw_mb    = '0;
                    raw_sa    = '0;
                    raw_sb    = '0;
                    bias_sel  = '0;
                end
            endcase
        end
        fedp_class_t cls_a_f16;
        VX_tcu_tfr_classifier #(
            .EXP_W (E_FP16),
            .MAN_W (10)
        ) class_a_f16 (
            .exp (raw_ea[E_FP16-1:0]),
            .man (raw_ma),
            .cls (cls_a_f16)
        );
        fedp_class_t cls_b_f16;
        VX_tcu_tfr_classifier #(
            .EXP_W (E_FP16),
            .MAN_W (10)
        ) class_b_f16 (
            .exp (raw_eb[E_FP16-1:0]),
            .man (raw_mb),
            .cls (cls_b_f16)
        );
        fedp_class_t cls_a_wide;
        VX_tcu_tfr_classifier #(
            .EXP_W (8),
            .MAN_W (10)
        ) class_a_wide (
            .exp (raw_ea),
            .man (raw_ma),
            .cls (cls_a_wide)
        );
        fedp_class_t cls_b_wide;
        VX_tcu_tfr_classifier #(
            .EXP_W (8),
            .MAN_W (10)
        ) class_b_wide (
            .exp (raw_eb),
            .man (raw_mb),
            .cls (cls_b_wide)
        );
        fedp_class_t cls_a;
        fedp_class_t cls_b;
        always_comb begin
            if (fmt_f == TCU_FP16_ID) begin
                cls_a = cls_a_f16;
                cls_b = cls_b_f16;
            end else begin
                cls_a = cls_a_wide;
                cls_b = cls_b_wide;
            end
        end
        wire is_ea_zero = ~|raw_ea;
        wire is_eb_zero = ~|raw_eb;
        wire [7:0] ea_sel = is_ea_zero ? 8'b1 : raw_ea;
        wire [7:0] eb_sel = is_eb_zero ? 8'b1 : raw_eb;
        wire [10:0] ma_sel = {~is_ea_zero, raw_ma};
        wire [10:0] mb_sel = {~is_eb_zero, raw_mb};
        wire sign_sel = raw_sa ^ raw_sb;
        wire zero_sel = cls_a.is_zero | cls_b.is_zero;
        wire nan_in = cls_a.is_nan | cls_b.is_nan;
        wire inf_z  = (cls_a.is_inf & cls_b.is_zero) | (cls_a.is_zero & cls_b.is_inf);
        wire inf_op = cls_a.is_inf | cls_b.is_inf;
        wire nan_sel = nan_in | inf_z;
        wire inf_sel = inf_op & ~inf_z;
        wire [EXP_W-1:0] exp_final = EXP_W'(bias_sel) + EXP_W'(ea_sel) + EXP_W'(eb_sel);
        assign result_exp[i] = (~zero_sel && lane_valid) ? exp_final : '0;
        wire [21:0] man_prod;
        assign mantissa_a[i] = ma_sel;
        assign mantissa_b[i] = mb_sel;
        if (EXTERNAL_MUL) begin : g_external
            assign man_prod = external_products[i];
        end else begin : g_internal
            VX_tcu_tfr_wmul #(
                .N       (11),
                .USE_DSP (USE_DSP),
                .OUT_REG (PROD_REG)
            ) wtmul (
                .clk    (clk),
                .enable (enable),
                .a      (ma_sel),
                .b      (mb_sel),
                .p      (man_prod)
            );
        end
        wire sign_sel_r;
        VX_pipe_register #(
            .DATAW (1),
            .DEPTH (PROD_REG)
        ) pipe_sign (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (sign_sel),
            .data_out (sign_sel_r)
        );
        assign result_sig[i] = sig_en_r ? {sign_sel_r, man_prod, 2'b0} : '0;
        assign exceptions[i].is_nan = nan_sel && lane_valid;
        assign exceptions[i].is_inf = inf_sel && lane_valid;
        assign exceptions[i].sign   = sign_sel;
    end
endmodule
module VX_tcu_tfr_mul_f4 import VX_tcu_pkg::*;
#(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0   
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    input wire [7:0]                sf_a,
    input wire [7:0]                sf_b,
    output logic [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions,
    output logic [TCK-1:0]            sig_zero
);
    wire [3:0] fmt_f_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_f),
        .data_out (fmt_f_r)
    );
    wire [TCK-1:0][24:0]      result_sig_mxfp4;
    wire [TCK-1:0][EXP_W-1:0] result_exp_mxfp4;
    fedp_excep_t [TCK-1:0]    exceptions_mxfp4;
    wire [TCK-1:0]            sig_zero_mxfp4;
    localparam F32_BIAS_MXFP4  = 127;
    localparam S_FP32_MXFP4    = 23;
    localparam S_SUPER_MXFP4   = 22;
    localparam BIAS_BASE_MXFP4 = F32_BIAS_MXFP4 + 2*(S_FP32_MXFP4 - S_SUPER_MXFP4) - W + WA - 1 + 128;
    localparam SIG_SHIFT_MXFP4 = 11;
    localparam F4_EXP_BIAS_MXFP4   = 1;
    localparam EXP_TERM_W_MXFP4    = 6;
    localparam EXP_TERM_BIAS_MXFP4 = 1 << (EXP_TERM_W_MXFP4 - 1);
    localparam EXP_COMP_MXFP4      = -(2 * F4_EXP_BIAS_MXFP4 + 10);
    localparam [EXP_TERM_W_MXFP4-1:0] EXP_ADJ_MXFP4 = EXP_TERM_W_MXFP4'(EXP_TERM_BIAS_MXFP4 + EXP_COMP_MXFP4);
    localparam [EXP_W-1:0] EXP_BASE_BIASED_MXFP4 = EXP_W'(BIAS_BASE_MXFP4 + EXP_COMP_MXFP4);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane_mxfp4
        localparam K_WORD = i / 2;
        wire [3:0][23:0] term_mag_shifted;
        wire [3:0][EXP_TERM_W_MXFP4-1:0] term_exp_biased;
        wire [3:0] term_valid;
        wire [3:0] term_sign;
        wire [3:0][1:0] a_man, b_man;
        wire [3:0][3:0] f4_man_prod;
        for (genvar j = 0; j < 4; ++j) begin : g_term
            localparam OFF = (i % 2) * 16 + j * 4;
            wire lane_valid = vld_mask[i * 4 + j];
            wire [3:0] raw_a = a_row[K_WORD][OFF +: 4];
            wire [3:0] raw_b = b_col[K_WORD][OFF +: 4];
            wire a_zero = ~|raw_a[2:0];
            wire b_zero = ~|raw_b[2:0];
            assign term_valid[j] = lane_valid && !a_zero && !b_zero;
            assign term_sign[j]  = raw_a[3] ^ raw_b[3];
            assign a_man[j] = ~|raw_a[2:1] ? 2'b01 : {1'b1, raw_a[0]};
            assign b_man[j] = ~|raw_b[2:1] ? 2'b01 : {1'b1, raw_b[0]};
            wire [1:0] a_exp, b_exp;
            assign a_exp[0] = raw_a[2] & ~raw_a[1];
            assign a_exp[1] = raw_a[2] & raw_a[1];
            assign b_exp[0] = raw_b[2] & ~raw_b[1];
            assign b_exp[1] = raw_b[2] & raw_b[1];
            wire signed [5:0] exp_biased_raw = 6'(10'(EXP_ADJ_MXFP4)
                                                + 10'(a_exp)
                                                + 10'(b_exp));
            assign term_exp_biased[j] = term_valid[j] ? exp_biased_raw : '0;
        end
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP),
            .OUT_REG (PROD_REG)
        ) f4m01 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[1:0]),
            .b (b_man[1:0]),
            .p (f4_man_prod[1:0])
        );
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP),
            .OUT_REG (PROD_REG)
        ) f4m23 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[3:2]),
            .b (b_man[3:2]),
            .p (f4_man_prod[3:2])
        );
        wire [EXP_TERM_W_MXFP4-1:0] max_exp_01 = (term_exp_biased[0] >= term_exp_biased[1]) ? term_exp_biased[0] : term_exp_biased[1];
        wire [EXP_TERM_W_MXFP4-1:0] max_exp_23 = (term_exp_biased[2] >= term_exp_biased[3]) ? term_exp_biased[2] : term_exp_biased[3];
        wire [EXP_TERM_W_MXFP4-1:0] max_exp_biased = (max_exp_01 >= max_exp_23) ? max_exp_01 : max_exp_23;
        wire [3:0] term_valid_r, term_sign_r;
        wire [3:0][EXP_TERM_W_MXFP4-1:0] shift_amt_r;
        wire [3:0][EXP_TERM_W_MXFP4-1:0] shift_amt_w;
        VX_pipe_register #(
            .DATAW (4 + 4 + 4 * EXP_TERM_W_MXFP4),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({term_valid,   term_sign,   shift_amt_w}),
            .data_out ({term_valid_r, term_sign_r, shift_amt_r})
        );
        wire [3:0][26:0] term_signed;
        for (genvar j = 0; j < 4; ++j) begin : g_align
            VX_ks_adder #(
                .N(EXP_TERM_W_MXFP4),
                .BYPASS(0)
            ) shift_ksa (
                .dataa(max_exp_biased),
                .datab(~term_exp_biased[j]),
                .cin(1'b1),
                .sum(shift_amt_w[j]),
                . cout ()
            );
            assign term_mag_shifted[j] = term_valid_r[j] ? (24'(f4_man_prod[j]) << SIG_SHIFT_MXFP4) : 24'd0;
            wire [23:0] aligned_mag = (shift_amt_r[j] >= EXP_TERM_W_MXFP4'(24)) ? 24'd0 : (term_mag_shifted[j] >> shift_amt_r[j][4:0]);
            wire [26:0] aligned_ext = {3'b0, aligned_mag};
            wire [26:0] neg_term;
            VX_ks_adder #(
                .N(27),
                .BYPASS(0)
            ) term_neg_ksa (
                .dataa(~aligned_ext),
                .datab(27'd0),
                .cin(1'b1),
                .sum(neg_term),
                . cout ()
            );
            assign term_signed[j] = term_sign_r[j] ? neg_term : aligned_ext;
        end
        wire [26:0] sum_vec, carry_vec;
        VX_csa_tree #(
            .N(4),
            .W(27),
            .S(27)
        ) term_csa (
            .operands (term_signed),
            .sum      (sum_vec),
            .carry    (carry_vec)
        );
        wire [26:0] signed_sum;
        VX_ks_adder #(
            .N(27),
            .BYPASS(0)
        ) sum_ksa (
            .dataa(sum_vec),
            .datab(carry_vec),
            .cin(1'b0),
            .sum(signed_sum),
            . cout ()
        );
        wire sum_sign = signed_sum[26];
        wire [25:0] neg_sum_raw;
        VX_ks_adder #(
            .N(26),
            .BYPASS(0)
        ) sum_neg_ksa (
            .dataa(~signed_sum[25:0]),
            .datab(26'd0),
            .cin(1'b1),
            .sum(neg_sum_raw),
            . cout ()
        );
        wire [25:0] abs_sum = sum_sign ? neg_sum_raw : signed_sum[25:0];
        wire is_zero_out = ~|abs_sum;
        assign result_sig_mxfp4[i] = {sum_sign & ~is_zero_out, abs_sum[23:0]};
        assign sig_zero_mxfp4[i]   = is_zero_out;
        assign result_exp_mxfp4[i] = EXP_W'(max_exp_biased) + EXP_W'(EXP_BASE_BIASED_MXFP4)
                                  + EXP_W'(sf_a) + EXP_W'(sf_b) - EXP_W'(254);
        assign exceptions_mxfp4[i].is_nan = (sf_a == 8'hff || sf_b == 8'hff) && (|vld_mask[i*4 +: 4]);
        assign exceptions_mxfp4[i].is_inf = 1'b0;
        assign exceptions_mxfp4[i].sign   = 1'b0;
    end
    wire [TCK-1:0][24:0]      result_sig_nvfp4;
    wire [TCK-1:0][EXP_W-1:0] result_exp_nvfp4;
    fedp_excep_t [TCK-1:0]    exceptions_nvfp4;
    wire [TCK-1:0]            sig_zero_nvfp4;
    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + 2*(S_FP32 - S_SUPER) - W + WA - 1 + 128;
    localparam SIG_SHIFT = 11;
    localparam F4_EXP_BIAS     = 1;
    localparam SF_EXP_BIAS     = 7;
    localparam SF_MAN_BITS     = 3;
    localparam EXP_TERM_W      = 6;
    localparam EXP_TERM_BIAS   = 1 << (EXP_TERM_W - 1);
    localparam EXP_COMP_NVFP4  = -(2 * F4_EXP_BIAS + 2 * (SF_EXP_BIAS + SF_MAN_BITS));
    localparam [5:0] EXP_ADJ_NVFP4 = 6'(EXP_TERM_BIAS + EXP_COMP_NVFP4);
    localparam [EXP_W-1:0] EXP_BASE_BIASED = EXP_W'(BIAS_BASE + EXP_COMP_NVFP4);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane_nvfp4
        localparam K_WORD = i / 2;
        wire [3:0] sf_man_a = {(|sf_a[6:3]), sf_a[2:0]};
        wire [3:0] sf_man_b = {(|sf_b[6:3]), sf_b[2:0]};
        wire [3:0] sf_exp_a = (|sf_a[6:3]) ? sf_a[6:3] : 4'd1;
        wire [3:0] sf_exp_b = (|sf_b[6:3]) ? sf_b[6:3] : 4'd1;
        wire [7:0] sf_man_prod;
        VX_tcu_tfr_wmul #(
            .N(4),
            .USE_DSP(USE_DSP)
        ) sf_wtmul (
            .clk    (clk),
            .enable (enable),
            .a(sf_man_a),
            .b(sf_man_b),
            .p(sf_man_prod)
        );
        wire [3:0][23:0] term_mag_shifted;
        wire [3:0][5:0]  term_exp_biased;
        wire [3:0]       term_valid;
        wire [3:0]       term_sign;
        wire [3:0][1:0]  a_man, b_man;
        wire [3:0][3:0]  f4_man_prod;
        wire [3:0][11:0] term_man_prod;
        for (genvar j = 0; j < 4; ++j) begin : g_term
            localparam OFF = (i % 2) * 16 + j * 4;
            wire lane_valid = vld_mask[i * 4 + j];
            wire [3:0] raw_a = a_row[K_WORD][OFF +: 4];
            wire [3:0] raw_b = b_col[K_WORD][OFF +: 4];
            wire a_zero = ~|raw_a[2:0];
            wire b_zero = ~|raw_b[2:0];
            assign term_valid[j] = lane_valid && !a_zero && !b_zero;
            assign term_sign[j]  = raw_a[3] ^ raw_b[3];
            assign a_man[j] = ~|raw_a[2:1] ? 2'b01 : {1'b1, raw_a[0]};
            assign b_man[j] = ~|raw_b[2:1] ? 2'b01 : {1'b1, raw_b[0]};
            wire [1:0] a_exp, b_exp;
            assign a_exp[0] = raw_a[2] & ~raw_a[1];
            assign a_exp[1] = raw_a[2] & raw_a[1];
            assign b_exp[0] = raw_b[2] & ~raw_b[1];
            assign b_exp[1] = raw_b[2] & raw_b[1];
            wire [5:0] exp_sum_vec, exp_carry_vec;
            VX_csa_tree #(
                .N(5),
                .W(6),
                .S(6)
            ) exp_csa (
                .operands ({EXP_ADJ_NVFP4, 6'(sf_exp_a), 6'(sf_exp_b), 6'(a_exp), 6'(b_exp)}),
                .sum      (exp_sum_vec),
                .carry    (exp_carry_vec)
            );
            wire [5:0] exp_biased_raw;
            VX_ks_adder #(
                .N(6),
                .BYPASS(0)
            ) exp_ksa (
                .dataa(exp_sum_vec),
                .datab(exp_carry_vec),
                .cin(1'b0),
                .sum(exp_biased_raw),
                . cout ()
            );
            assign term_exp_biased[j] = term_valid[j] ? exp_biased_raw : 6'd0;
        end
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP)
        ) f4m01 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[1:0]),
            .b (b_man[1:0]),
            .p (f4_man_prod[1:0])
        );
        VX_tcu_tfr_wmul #(
            .N       (2),
            .LANES   (2),
            .USE_DSP (USE_DSP)
        ) f4m23 (
            .clk    (clk),
            .enable (enable),
            .a (a_man[3:2]),
            .b (b_man[3:2]),
            .p (f4_man_prod[3:2])
        );
        VX_tcu_tfr_wmul #(
            .N        (4),
            .M        (8),
            .LANES    (2),
            .SHARED_B (1),
            .USE_DSP  (USE_DSP),
            .OUT_REG  (PROD_REG)
        ) tm01 (
            .clk    (clk),
            .enable (enable),
            .a (f4_man_prod[1:0]),
            .b ({8'b0, sf_man_prod}),
            .p (term_man_prod[1:0])
        );
        VX_tcu_tfr_wmul #(
            .N        (4),
            .M        (8),
            .LANES    (2),
            .SHARED_B (1),
            .USE_DSP  (USE_DSP),
            .OUT_REG  (PROD_REG)
        ) tm23 (
            .clk    (clk),
            .enable (enable),
            .a (f4_man_prod[3:2]),
            .b ({8'b0, sf_man_prod}),
            .p (term_man_prod[3:2])
        );
        wire [5:0] max_exp_01 = (term_exp_biased[0] >= term_exp_biased[1]) ? term_exp_biased[0] : term_exp_biased[1];
        wire [5:0] max_exp_23 = (term_exp_biased[2] >= term_exp_biased[3]) ? term_exp_biased[2] : term_exp_biased[3];
        wire [5:0] max_exp_biased = (max_exp_01 >= max_exp_23) ? max_exp_01 : max_exp_23;
        wire [3:0] term_valid_r, term_sign_r;
        wire [3:0][5:0] shift_amt_r;
        wire [3:0][5:0] shift_amt_w;
        VX_pipe_register #(
            .DATAW (4 + 4 + 4 * 6),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({term_valid,   term_sign,   shift_amt_w}),
            .data_out ({term_valid_r, term_sign_r, shift_amt_r})
        );
        wire [3:0][26:0] term_signed;
        for (genvar j = 0; j < 4; ++j) begin : g_align
            VX_ks_adder #(
                .N(6),
                .BYPASS(0)
            ) shift_ksa (
                .dataa(max_exp_biased),
                .datab(~term_exp_biased[j]),
                .cin(1'b1),
                .sum(shift_amt_w[j]),
                . cout ()
            );
            assign term_mag_shifted[j] = term_valid_r[j] ? (24'(term_man_prod[j][10:0]) << SIG_SHIFT) : 24'd0;
            wire [23:0] aligned_mag = (shift_amt_r[j] >= 6'd24) ? 24'd0 : (term_mag_shifted[j] >> shift_amt_r[j][4:0]);
            wire [26:0] aligned_ext = {3'b0, aligned_mag};
            wire [26:0] neg_term;
            VX_ks_adder #(
                .N(27),
                .BYPASS(0)
            ) term_neg_ksa (
                .dataa(~aligned_ext),
                .datab(27'd0),
                .cin(1'b1),
                .sum(neg_term),
                . cout ()
            );
            assign term_signed[j] = term_sign_r[j] ? neg_term : aligned_ext;
        end
        wire [26:0] sum_vec, carry_vec;
        VX_csa_tree #(
            .N(4),
            .W(27),
            .S(27)
        ) term_csa (
            .operands (term_signed),
            .sum      (sum_vec),
            .carry    (carry_vec)
        );
        wire [26:0] signed_sum;
        VX_ks_adder #(
            .N(27),
            .BYPASS(0)
        ) sum_ksa (
            .dataa(sum_vec),
            .datab(carry_vec),
            .cin(1'b0),
            .sum(signed_sum),
            . cout ()
        );
        wire sum_sign = signed_sum[26];
        wire [25:0] neg_sum_raw;
        VX_ks_adder #(
            .N(26),
            .BYPASS(0)
        ) sum_neg_ksa (
            .dataa(~signed_sum[25:0]),
            .datab(26'd0),
            .cin(1'b1),
            .sum(neg_sum_raw),
            . cout ()
        );
        wire [25:0] abs_sum = sum_sign ? neg_sum_raw : signed_sum[25:0];
        wire is_zero_out = ~|abs_sum;
        assign result_sig_nvfp4[i] = {sum_sign & ~is_zero_out, abs_sum[23:0]};
        assign sig_zero_nvfp4[i]   = is_zero_out;
        assign result_exp_nvfp4[i] = EXP_W'(max_exp_biased) + EXP_W'(EXP_BASE_BIASED);
        assign exceptions_nvfp4[i].is_nan = ((&sf_a[6:0]) || (&sf_b[6:0])) && (|vld_mask[i*4 +: 4]);
        assign exceptions_nvfp4[i].is_inf = 1'b0;
        assign exceptions_nvfp4[i].sign   = 1'b0;
    end
    always_comb begin
        result_exp = '0;
        exceptions = '0;
        case (fmt_f)
            4'(TCU_MXFP4_ID): begin
                result_exp = result_exp_mxfp4;
                exceptions = exceptions_mxfp4;
            end
            4'(TCU_NVFP4_ID): begin
                result_exp = result_exp_nvfp4;
                exceptions = exceptions_nvfp4;
            end
            default: begin
                result_exp = '0;
                exceptions = '0;
            end
        endcase
    end
    always_comb begin
        result_sig = '0;
        sig_zero   = '0;
        case (fmt_f_r)
            4'(TCU_MXFP4_ID): begin
                result_sig = result_sig_mxfp4;
                sig_zero   = sig_zero_mxfp4;
            end
            4'(TCU_NVFP4_ID): begin
                result_sig = result_sig_nvfp4;
                sig_zero   = sig_zero_nvfp4;
            end
            default: begin
                result_sig = '0;
                sig_zero   = '0;
            end
        endcase
    end
endmodule
module VX_tcu_tfr_mul_f8 import VX_tcu_pkg::*;
#(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0,   
    parameter EXTERNAL_MUL = 0
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_f,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output wire [TCK-1:0][1:0][3:0] mantissa_a,
    output wire [TCK-1:0][1:0][3:0] mantissa_b,
    input wire [TCK-1:0][1:0][7:0] external_products,
    input wire [7:0]                sf_a,
    input wire [7:0]                sf_b,
    output logic [TCK-1:0][24:0]      result_sig,
    output logic [TCK-1:0][EXP_W-1:0] result_exp,
    output fedp_excep_t [TCK-1:0]     exceptions,
    output wire  [TCK-1:0]            sig_zero
);
    localparam F32_BIAS  = 127;
    localparam S_FP32    = 23;
    localparam S_SUPER   = 22;
    localparam BIAS_BASE = F32_BIAS + 2*(S_FP32 - S_SUPER) - W + WA - 1 + 128;
    localparam E_FP8 = VX_tcu_pkg::exp_bits(TCU_FP8_ID);
    localparam S_FP8 = VX_tcu_pkg::sign_pos(TCU_FP8_ID);
    localparam B_FP8 = (1 << (E_FP8 - 1)) - 1;
    localparam [7:0] BIAS_CONST_FP8  = 8'(BIAS_BASE - 2*B_FP8);
    localparam E_BF8 = VX_tcu_pkg::exp_bits(TCU_BF8_ID);
    localparam S_BF8 = VX_tcu_pkg::sign_pos(TCU_BF8_ID);
    localparam B_BF8 = (1 << (E_BF8 - 1)) - 1;
    localparam [7:0] BIAS_CONST_BF8  = 8'(BIAS_BASE - 2*B_BF8);
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire [1:0] lane_valid = {vld_mask[i * 4 + 2], vld_mask[i * 4 + 0]};
        wire is_bfloat = tcu_fmt_is_bfloat(fmt_f);
        wire [1:0][4:0] ea_sel, eb_sel;
        wire [1:0][3:0] ma_sel, mb_sel;
        wire [1:0]      zero_sel, sign_sel, nan_sel, inf_sel;
        for (genvar j = 0; j < 2; ++j) begin : g_extract
            localparam OFF = (i % 2) * 16 + j * 8;
            wire [7:0] raw_a = a_row[i/2][OFF +: 8];
            wire [7:0] raw_b = b_col[i/2][OFF +: 8];
            logic [4:0] raw_ea, raw_eb;
            logic [2:0] raw_ma, raw_mb;
            logic       raw_sa, raw_sb;
            always_comb begin
                if (is_bfloat) begin  
                    raw_ea  = 5'(raw_a[S_BF8-1 -: E_BF8]);
                    raw_eb  = 5'(raw_b[S_BF8-1 -: E_BF8]);
                    raw_ma  = {raw_a[1:0], 1'b0};
                    raw_mb  = {raw_b[1:0], 1'b0};
                    raw_sa  = raw_a[7];
                    raw_sb  = raw_b[7];
                end else begin        
                    raw_ea  = 5'(raw_a[S_FP8-1 -: E_FP8]);
                    raw_eb  = 5'(raw_b[S_FP8-1 -: E_FP8]);
                    raw_ma  = raw_a[2:0];
                    raw_mb  = raw_b[2:0];
                    raw_sa  = raw_a[7];
                    raw_sb  = raw_b[7];
                end
            end
            fedp_class_t cls_a;
            VX_tcu_tfr_classifier #(
                .EXP_W (5),
                .MAN_W (3)
            ) class_a (
                .exp (raw_ea),
                .man (raw_ma),
                .cls (cls_a)
            );
            fedp_class_t cls_b;
            VX_tcu_tfr_classifier #(
                .EXP_W (5),
                .MAN_W (3)
            ) class_b (
                .exp (raw_eb),
                .man (raw_mb),
                .cls (cls_b)
            );
            wire is_ea_zero = (raw_ea == 0);
            wire is_eb_zero = (raw_eb == 0);
            assign ea_sel[j] = is_ea_zero ? 5'b1 : raw_ea;
            assign eb_sel[j] = is_eb_zero ? 5'b1 : raw_eb;
            assign ma_sel[j] = lane_valid[j] ? {~is_ea_zero, raw_ma} : 4'b0;
            assign mb_sel[j] = {~is_eb_zero, raw_mb};
            assign sign_sel[j] = raw_sa ^ raw_sb;
            assign zero_sel[j] = cls_a.is_zero | cls_b.is_zero;
            wire a_is_inf = is_bfloat ? cls_a.is_inf : 1'b0;
            wire b_is_inf = is_bfloat ? cls_b.is_inf : 1'b0;
            wire a_is_nan = is_bfloat ? cls_a.is_nan : (raw_ea == 5'h0F) && (raw_ma == 3'b111);
            wire b_is_nan = is_bfloat ? cls_b.is_nan : (raw_eb == 5'h0F) && (raw_mb == 3'b111);
            wire nan_in = a_is_nan | b_is_nan;
            wire inf_z  = (a_is_inf & cls_b.is_zero) | (cls_a.is_zero & b_is_inf);
            wire inf_op = a_is_inf | b_is_inf;
            assign nan_sel[j] = nan_in | inf_z;
            assign inf_sel[j] = inf_op & ~inf_z;
        end
        wire [5:0] pre_sum_0, pre_sum_1;
        VX_ks_adder #(
            .N(6),
            .BYPASS(0)
        ) exp_add1_0 (
            .dataa(6'(ea_sel[0])),
            .datab(6'(eb_sel[0])),
            .cin(1'b0),
            .sum(pre_sum_0),
            . cout ()
        );
        VX_ks_adder #(
            .N(6),
            .BYPASS(0)
        ) exp_add1_1 (
            .dataa(6'(ea_sel[1])),
            .datab(6'(eb_sel[1])),
            .cin(1'b0),
            .sum(pre_sum_1),
            . cout ()
        );
        wire v0 = ~zero_sel[0] && lane_valid[0];
        wire v1 = ~zero_sel[1] && lane_valid[1];
        wire [6:0] diff_0_minus_1 = {1'b0, pre_sum_0} - {1'b0, pre_sum_1};
        wire [6:0] diff_1_minus_0 = {1'b0, pre_sum_1} - {1'b0, pre_sum_0};
        wire term0_ge_term1 = ~diff_0_minus_1[6];
        wire term0_is_max = v0 && (!v1 || term0_ge_term1);
        wire diff_sign = term0_is_max;
        wire [5:0] diff_abs = term0_is_max ? diff_0_minus_1[5:0] : diff_1_minus_0[5:0];
        wire [5:0] max_pre_sum = term0_is_max ? pre_sum_0 : pre_sum_1;
        wire [7:0] bias_sel = is_bfloat ? BIAS_CONST_BF8 : BIAS_CONST_FP8;
        wire [EXP_W-1:0] max_pre_sum_cpa, bias_sel_cpa;
        wire [EXP_W-1:0] final_exp;
        wire [EXP_W-1:0] bias_cpa_sum, bias_cpa_carry;
        wire [3*EXP_W-1:0] sf_comp = fmt_f[3] ? {EXP_W'(sf_a), EXP_W'(sf_b), -EXP_W'(254)} : (3*EXP_W)'(0);
        VX_csa_tree #(
            .N(4),
            .W(EXP_W),
            .S(EXP_W)
        ) exp_sf_csa (
            .operands ({EXP_W'(bias_sel), sf_comp}),
            .sum      (bias_cpa_sum),
            .carry    (bias_cpa_carry)
        );
        VX_ks_adder #(
            .N(EXP_W),
            .BYPASS(0)
        ) exp_bias_add (
            .dataa(bias_cpa_sum),
            .datab(bias_cpa_carry),
            .cin(1'b0),
            .sum(bias_sel_cpa),
            . cout ()
        );
        assign max_pre_sum_cpa = EXP_W'(max_pre_sum);
        VX_ks_adder #(
            .N(EXP_W),
            .BYPASS(0)
        ) exp_final_add (
            .dataa(EXP_W'(max_pre_sum_cpa)),
            .datab(EXP_W'(bias_sel_cpa)),
            .cin(1'b0),
            .sum(final_exp),
            . cout ()
        );
        wire [1:0][7:0] man_prod;
        assign mantissa_a[i] = ma_sel;
        assign mantissa_b[i] = mb_sel;
        if (EXTERNAL_MUL) begin : g_external
            assign man_prod = external_products[i];
        end else begin : g_internal
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (USE_DSP),
                .OUT_REG (PROD_REG)
            ) wtmul (
                .clk    (clk),
                .enable (enable),
                .a (ma_sel),
                .b (mb_sel),
                .p (man_prod)
            );
        end
        wire       diff_sign_r;
        wire       diff_ge_32_r;
        wire [4:0] shamt_r;
        wire [1:0] sign_sel_r;
        wire       pre_sum_eq_r;
        VX_pipe_register #(
            .DATAW (1 + 1 + 5 + 2 + 1),
            .DEPTH (PROD_REG)
        ) pipe_ctrl (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  ({diff_sign,   diff_abs[5],  diff_abs[4:0], sign_sel,   (pre_sum_0 == pre_sum_1)}),
            .data_out ({diff_sign_r, diff_ge_32_r, shamt_r,       sign_sel_r, pre_sum_eq_r})
        );
        wire [7:0] prod_max = diff_sign_r ? man_prod[0] : man_prod[1];
        wire [7:0] prod_min = diff_sign_r ? man_prod[1] : man_prod[0];
        wire       sign_max = diff_sign_r ? sign_sel_r[0] : sign_sel_r[1];
        wire       sign_min = diff_sign_r ? sign_sel_r[1] : sign_sel_r[0];
        wire [23:0] sig_max = {prod_max, 16'b0};
        wire [23:0] sig_min_shifted = diff_ge_32_r ? 24'b0 : ({prod_min, 16'b0} >> shamt_r);
        wire [24:0] sig_max_ext = {1'b0, sig_max};
        wire [24:0] sig_min_ext = {1'b0, sig_min_shifted};
        wire do_sub = sign_sel_r[0] ^ sign_sel_r[1];
        wire [24:0] add_raw;
        VX_ks_adder #(
            .N(25),
            .BYPASS(0)
        ) add_adder (
            .dataa(sig_max_ext),
            .datab(sig_min_ext),
            .cin(1'b0),
            .sum(add_raw),
            . cout ()
        );
        wire [24:0] sub_raw;
        VX_ks_adder #(
            .N(25),
            .BYPASS(0)
        ) sub_adder (
            .dataa(sig_max_ext),
            .datab(~sig_min_ext),
            .cin(1'b1),
            .sum(sub_raw),
            . cout ()
        );
        wire sub_neg = sub_raw[24];
        wire [24:0] sub_abs = sub_neg ? -sub_raw : sub_raw;
        wire [24:0] sig_add_raw = do_sub ? sub_abs : add_raw;
        wire [23:0] sig_add = sig_add_raw[24:1];
        wire mag_is_equal = pre_sum_eq_r && (man_prod[0] == man_prod[1]);
        wire is_zero_out = do_sub && mag_is_equal;
        wire sig_sign_raw = sub_neg ? sign_min : sign_max;
        wire sig_sign = is_zero_out ? 1'b0 : sig_sign_raw;
        assign result_sig[i] = {sig_sign, sig_add};
        assign sig_zero[i]   = is_zero_out;
        assign result_exp[i] = (v0 || v1) ? final_exp : '0;
        wire pos_inf_0 = inf_sel[0] && ~sign_sel[0] && lane_valid[0];
        wire neg_inf_0 = inf_sel[0] &&  sign_sel[0] && lane_valid[0];
        wire pos_inf_1 = inf_sel[1] && ~sign_sel[1] && lane_valid[1];
        wire neg_inf_1 = inf_sel[1] &&  sign_sel[1] && lane_valid[1];
        wire add_nan = (pos_inf_0 && neg_inf_1) || (neg_inf_0 && pos_inf_1);
        wire any_nan = (|(nan_sel & lane_valid)) || add_nan;
        wire any_inf = (|(inf_sel & lane_valid)) && ~any_nan;
        wire final_sign_inf = inf_sel[0] && lane_valid[0] ? sign_sel[0] : sign_sel[1];
        assign exceptions[i].is_nan = any_nan;
        assign exceptions[i].is_inf = any_inf;
        assign exceptions[i].sign   = final_sign_inf;
    end
endmodule
module VX_tcu_tfr_mul_i4 import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N   = 2,
    parameter TCK = 2 * N,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0   
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_i,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output logic [TCK-1:0][24:0]    result
);
    wire is_signed_int = fmt_i[3] || tcu_fmt_is_signed_int(fmt_i);
    wire [3:0] fmt_i_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_i),
        .data_out (fmt_i_r)
    );
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire signed [3:0][9:0] y_prod_i4;
        wire [3:0][3:0] raw_a, raw_b;
        wire [3:0]      pvalid;
        for (genvar j = 0; j < 4; ++j) begin : g_ext
            assign raw_a[j]  = a_row[i/2][(i%2)*16 + j*4 +: 4];
            assign raw_b[j]  = b_col[i/2][(i%2)*16 + j*4 +: 4];
            assign pvalid[j] = vld_mask[i * 4 + j];
        end
        wire [3:0] pvalid_r;
        VX_pipe_register #(
            .DATAW (4),
            .DEPTH (PROD_REG)
        ) pipe_valid (
            .clk      (clk),
            .reset    (1'b0),
            .enable   (enable),
            .data_in  (pvalid),
            .data_out (pvalid_r)
        );
        if (USE_DSP != 0) begin : g_dsp
            wire [3:0][3:0] mag_a, mag_b;
            wire [3:0]      psign;
            for (genvar j = 0; j < 4; ++j) begin : g_mag
                wire sgn_a = is_signed_int & raw_a[j][3];
                wire sgn_b = is_signed_int & raw_b[j][3];
                assign mag_a[j] = sgn_a ? (4'(~raw_a[j]) + 4'b1) : raw_a[j];   
                assign mag_b[j] = sgn_b ? (4'(~raw_b[j]) + 4'b1) : raw_b[j];   
                assign psign[j] = sgn_a ^ sgn_b;
            end
            wire [3:0][7:0] magp;
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (1),
                .OUT_REG (PROD_REG)
            ) m01 (
                .clk    (clk),
                .enable (enable),
                .a (mag_a[1:0]),
                .b (mag_b[1:0]),
                .p (magp[1:0])
            );
            VX_tcu_tfr_wmul #(
                .N       (4),
                .LANES   (2),
                .USE_DSP (1),
                .OUT_REG (PROD_REG)
            ) m23 (
                .clk    (clk),
                .enable (enable),
                .a (mag_a[3:2]),
                .b (mag_b[3:2]),
                .p (magp[3:2])
            );
            wire [3:0] psign_r;
            VX_pipe_register #(
                .DATAW (4),
                .DEPTH (PROD_REG)
            ) pipe_sign (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (psign),
                .data_out (psign_r)
            );
            for (genvar j = 0; j < 4; ++j) begin : g_sign
                wire signed [9:0] pf = psign_r[j] ? -$signed({2'b0, magp[j]})
                                                  :  $signed({2'b0, magp[j]});
                assign y_prod_i4[j] = pf & {10{pvalid_r[j]}};
            end
        end else begin : g_lut
            for (genvar j = 0; j < 4; ++j) begin : g_mul
                wire signed [4:0] s_a = is_signed_int ? $signed({raw_a[j][3], raw_a[j]}) : $signed({1'b0, raw_a[j]});
                wire signed [4:0] s_b = is_signed_int ? $signed({raw_b[j][3], raw_b[j]}) : $signed({1'b0, raw_b[j]});
                wire signed [9:0] prod_full = s_a * s_b;
                wire [9:0] prod_r;
                VX_pipe_register #(
                    .DATAW (10),
                    .DEPTH (PROD_REG)
                ) pipe_prod (
                    .clk      (clk),
                    .reset    (1'b0),
                    .enable   (enable),
                    .data_in  (prod_full),
                    .data_out (prod_r)
                );
                assign y_prod_i4[j] = prod_r & {10{pvalid_r[j]}};
            end
        end
        wire [9:0] y_i4_sum, y_i4_carry;
        VX_csa_tree #(
            .N (4),
            .W (10),
            .S (10)
        ) i4_csa (
            .operands (y_prod_i4),
            .sum      (y_i4_sum),
            .carry    (y_i4_carry)
        );
        wire [9:0] y_i4_add_res;
        VX_ks_adder #(
            .N (10),
            .BYPASS (0)
        ) i4_ksa (
            .cin   (1'b0),
            .dataa (y_i4_sum),
            .datab (y_i4_carry),
            .sum   (y_i4_add_res),
            . cout ()
        );
        always_comb begin
            case ({1'b1, fmt_i_r})
                TCU_I4_ID: result[i] = 25'($signed(y_i4_add_res));
                TCU_U4_ID: result[i] = {15'b0, y_i4_add_res};
                default:   result[i] = '0;
            endcase
        end
    end
endmodule
module VX_tcu_tfr_mul_i8 import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N   = 2,
    parameter TCK = 2 * N,
    parameter USE_DSP = 0,   
    parameter PROD_REG = 0   
) (
    input wire                      clk,
    input wire                      enable,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [3:0]                fmt_i,
    input wire [N-1:0][31:0]        a_row,
    input wire [N-1:0][31:0]        b_col,
    output logic [TCK-1:0][24:0]    result
);
    for (genvar i = 1; i < TCU_MAX_INPUTS; i += 2) begin : g_unused_vld
    end
    wire is_signed_int = fmt_i[3] || tcu_fmt_is_signed_int(fmt_i);
    wire [3:0] fmt_i_r;
    VX_pipe_register #(
        .DATAW (4),
        .DEPTH (PROD_REG)
    ) pipe_fmt (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  (fmt_i),
        .data_out (fmt_i_r)
    );
    for (genvar i = 0; i < TCK; ++i) begin : g_lane
        wire signed [16:0] y_prod_i8 [2];
        for (genvar j = 0; j < 2; ++j) begin : g_i8
            wire lane_valid = vld_mask[i * 4 + j * 2];
            wire [7:0] raw_a = a_row[i/2][(i%2)*16 + j*8 +: 8];
            wire [7:0] raw_b = b_col[i/2][(i%2)*16 + j*8 +: 8];
            wire signed [8:0] s_a = is_signed_int ? $signed({raw_a[7], raw_a}) : $signed({1'b0, raw_a});
            wire signed [8:0] s_b = is_signed_int ? $signed({raw_b[7], raw_b}) : $signed({1'b0, raw_b});
            wire signed [16:0] prod_full;
            if (USE_DSP != 0) begin : g_dsp
                (* use_dsp = "yes" *) wire signed [16:0] dsp_prod = s_a * s_b;
                assign prod_full = dsp_prod;
            end else begin : g_lut
                assign prod_full = s_a * s_b;
            end
            wire [16:0] prod_r;
            VX_pipe_register #(
                .DATAW (17),
                .DEPTH (PROD_REG)
            ) pipe_prod (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (prod_full),
                .data_out (prod_r)
            );
            wire lane_valid_r;
            VX_pipe_register #(
                .DATAW (1),
                .DEPTH (PROD_REG)
            ) pipe_valid (
                .clk      (clk),
                .reset    (1'b0),
                .enable   (enable),
                .data_in  (lane_valid),
                .data_out (lane_valid_r)
            );
            assign y_prod_i8[j] = prod_r & {17{lane_valid_r}};
        end
        wire [16:0] y_i8_add_res;
        VX_ks_adder #(
            .N(17),
            .BYPASS (0)
        ) i8_ksa (
            .cin   (1'b0),
            .dataa (y_prod_i8[0]),
            .datab (y_prod_i8[1]),
            .sum   (y_i8_add_res),
            . cout ()
        );
        always_comb begin
            case ({1'b1, fmt_i_r})
                TCU_I8_ID: result[i] = 25'($signed(y_i8_add_res));
                TCU_U8_ID: result[i] = {8'b0, y_i8_add_res};
                default:   result[i] = '0;
            endcase
        end
    end
endmodule
module VX_tcu_tfr_mul_join import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N     = 2,
    parameter TCK   = 2 * N,
    parameter W     = 25,
    parameter WA    = 28,
    parameter EXP_W = 10
) (
    input wire                      clk,
    input wire                      valid_in,
    input wire [31:0]               req_id,
    input wire [4:0]                fmt_s,
    input wire [31:0]               c_val,
    input wire [TCK-1:0][EXP_W-1:0] exp_f16,
    input fedp_excep_t [TCK-1:0]    exc_f16,
    input wire [TCK-1:0][EXP_W-1:0] exp_f8,
    input fedp_excep_t [TCK-1:0]    exc_f8,
    input wire [TCK-1:0][EXP_W-1:0] exp_f4,
    input fedp_excep_t [TCK-1:0]    exc_f4,
    output logic [TCK:0][EXP_W-1:0] exp_out,
    output fedp_excep_t [TCK:0]     exc_out,
    output wire [24:0]              c_sig
);
    logic [TCK-1:0][EXP_W-1:0] exp_sel;
    fedp_excep_t [TCK-1:0]     exc_sel;
    always_comb begin
        case (fmt_s)
            TCU_FP16_ID,
            TCU_BF16_ID: begin
                exp_sel = exp_f16;
                exc_sel = exc_f16;
            end
            TCU_TF32_ID: begin
                exp_sel = exp_f16;
                exc_sel = exc_f16;
            end
            TCU_FP8_ID, TCU_BF8_ID
            , TCU_MXFP8_ID, TCU_MXBF8_ID
            : begin
                exp_sel = exp_f8;
                exc_sel = exc_f8;
            end
            TCU_MXFP4_ID: begin
                exp_sel = exp_f4;
                exc_sel = exc_f4;
            end
            TCU_NVFP4_ID: begin
                exp_sel = exp_f4;
                exc_sel = exc_f4;
            end
            default: begin
                exp_sel = '0;
                exc_sel = '0;
            end
        endcase
    end
    wire c_is_int = tcu_fmt_is_int(fmt_s);
    fedp_class_t cls_c;
    VX_tcu_tfr_classifier #(
        .EXP_W (8),
        .MAN_W (23)
    ) class_c (
        .exp (c_val[30:23]),
        .man (c_val[22:0]),
        .cls (cls_c)
    );
    wire c_sign = c_val[31];
    assign c_sig = c_is_int ? c_val[24:0] : (cls_c.is_zero ? 25'd0 : {c_val[31], (cls_c.is_sub ? 1'b0 : 1'b1), c_val[22:0]});
    wire [7:0] c_exp_raw = (cls_c.is_sub || cls_c.is_zero) ? 8'd1 : c_val[30:23];
    wire [EXP_W-1:0] c_exp_adj = EXP_W'(c_exp_raw) - EXP_W'(W-1) + EXP_W'(WA-1) + 128;
    wire [EXP_W-1:0] c_exp_final = cls_c.is_zero ? '0 : c_exp_adj;
    assign exp_out = {c_exp_final, exp_sel};
    for (genvar i = 0; i < TCK; ++i) begin : g_exc
        assign exc_out[i] = exc_sel[i];
    end
    assign exc_out[TCK].is_nan = cls_c.is_nan;
    assign exc_out[TCK].is_inf = cls_c.is_inf;
    assign exc_out[TCK].sign   = c_sign;
endmodule
module VX_tcu_tfr_shared_mul import VX_tcu_pkg::*;  #(
    parameter  INSTANCE_ID = "",
    parameter N = 2,             
    parameter W = 25,            
    parameter WA = 28,           
    parameter EXP_W = 10,        
    parameter TCK = 2 * N,       
    parameter SF = 1,            
    parameter USE_DSP = 0,       
    parameter PROD_REG = 0,      
    parameter EXTERNAL_MUL = 0,
    parameter EXTERNAL_EXP = 0,
    parameter EXTERNAL_F8 = 0
) (
    input wire              clk,
    input wire              enable,
    input wire              valid_in,
    input wire [31:0]       req_id,
    input wire [TCU_MAX_INPUTS-1:0] vld_mask,
    input wire [4:0]        fmt_s,
    input wire [N-1:0][31:0] a_row,
    input wire [N-1:0][31:0] b_col,
    input wire [31:0]        c_val,
    output wire [TCK-1:0][10:0] mantissa_a,
    output wire [TCK-1:0][10:0] mantissa_b,
    input wire [TCK-1:0][21:0] external_products,
    input wire                external_exp_enable,
    input wire [TCK:0][EXP_W-1:0] external_exponents,
    output wire [TCK-1:0][1:0][3:0] f8_mantissa_a,
    output wire [TCK-1:0][1:0][3:0] f8_mantissa_b,
    input wire [TCK-1:0][1:0][7:0] external_f8_products,
    input wire [SF-1:0][7:0] sf_a,
    input wire [SF-1:0][7:0] sf_b,
    output wire [TCK:0][EXP_W-1:0] exponents,
    output wire [TCK:0]            exp_sel,
    output wire [TCK:0][24:0] raw_sigs,
    output fedp_excep_t       exceptions,
    output wire [TCK-1:0]     lane_mask
);
    if (!1 && !1) begin : g_sf_unused
    end
    wire [TCK-1:0][24:0]      mul_f16_sig;
    wire [TCK-1:0][EXP_W-1:0] mul_f16_exp;
    fedp_excep_t [TCK-1:0]    mul_f16_exc;
    VX_tcu_tfr_mul_f16 #(
        .N(N),
        .TCK(TCK),
        .W(W),
        .WA(WA),
        .EXP_W(EXP_W),
        .USE_DSP(USE_DSP),
        .PROD_REG(PROD_REG),
        .EXTERNAL_MUL(EXTERNAL_MUL)
    ) mul_f16 (
        .clk        (clk),
        .enable     (enable),
        .valid_in   (valid_in),
        .req_id     (req_id),
        .vld_mask   (vld_mask),
        .fmt_f      (fmt_s[3:0]),
        .a_row      (a_row),
        .b_col      (b_col),
        .mantissa_a (mantissa_a),
        .mantissa_b (mantissa_b),
        .external_products (external_products),
        .result_sig (mul_f16_sig),
        .result_exp (mul_f16_exp),
        .exceptions (mul_f16_exc)
    );
    wire [TCK-1:0][24:0]      mul_f8_sig;
    wire [TCK-1:0][EXP_W-1:0] mul_f8_exp;
    fedp_excep_t [TCK-1:0]    mul_f8_exc;
    wire [TCK-1:0]            mul_f8_zero;
    wire [SF-1:0][TCK-1:0][24:0]      mul_f8_sig_s;
    wire [SF-1:0][TCK-1:0][EXP_W-1:0] mul_f8_exp_s;
    fedp_excep_t [SF-1:0][TCK-1:0]    mul_f8_exc_s;
    wire [SF-1:0][TCK-1:0]            mul_f8_zero_s;
    wire [SF-1:0][TCK-1:0][1:0][3:0] f8_ma, f8_mb;
    assign f8_mantissa_a = f8_ma[0];
    assign f8_mantissa_b = f8_mb[0];
    for (genvar s = 0; s < SF; ++s) begin : g_mul_f8_sf
        VX_tcu_tfr_mul_f8 #(
            .N(N),
            .TCK(TCK),
            .W(W),
            .WA(WA),
            .EXP_W(EXP_W),
            .USE_DSP(USE_DSP),
            .PROD_REG(PROD_REG),
            .EXTERNAL_MUL(EXTERNAL_F8)
        ) mul_f8 (
            .clk        (clk),
            .enable     (enable),
            .valid_in   (valid_in),
            .req_id     (req_id),
            .vld_mask   (vld_mask),
            .fmt_f      (fmt_s[3:0]),
            .a_row      (a_row),
            .b_col      (b_col),
            .mantissa_a (f8_ma[s]),
            .mantissa_b (f8_mb[s]),
            .external_products (external_f8_products),
            .sf_a       (sf_a[s]),
            .sf_b       (sf_b[s]),
            .result_sig (mul_f8_sig_s[s]),
            .result_exp (mul_f8_exp_s[s]),
            .exceptions (mul_f8_exc_s[s]),
            .sig_zero   (mul_f8_zero_s[s])
        );
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mul_f8_lane
        localparam SF_SLOT = (i * SF) / TCK;
        assign mul_f8_sig[i]  = mul_f8_sig_s[SF_SLOT][i];
        assign mul_f8_exp[i]  = mul_f8_exp_s[SF_SLOT][i];
        assign mul_f8_exc[i]  = mul_f8_exc_s[SF_SLOT][i];
        assign mul_f8_zero[i] = mul_f8_zero_s[SF_SLOT][i];
    end
    wire [TCK-1:0][24:0]      mul_f4_sig;
    wire [TCK-1:0][EXP_W-1:0] mul_f4_exp;
    fedp_excep_t [TCK-1:0]    mul_f4_exc;
    wire [TCK-1:0]            mul_f4_zero;
    wire [SF-1:0][TCK-1:0][24:0]      mul_f4_sig_s;
    wire [SF-1:0][TCK-1:0][EXP_W-1:0] mul_f4_exp_s;
    fedp_excep_t [SF-1:0][TCK-1:0]    mul_f4_exc_s;
    wire [SF-1:0][TCK-1:0]            mul_f4_zero_s;
    for (genvar s = 0; s < SF; ++s) begin : g_mul_f4_sf
        VX_tcu_tfr_mul_f4 #(
            .N(N),
            .TCK(TCK),
            .W(W),
            .WA(WA),
            .EXP_W(EXP_W),
            .USE_DSP(USE_DSP),
            .PROD_REG(PROD_REG)
        ) mul_f4 (
            .clk        (clk),
            .enable     (enable),
            .valid_in   (valid_in),
            .req_id     (req_id),
            .vld_mask   (vld_mask),
            .fmt_f      (fmt_s[3:0]),
            .a_row      (a_row),
            .b_col      (b_col),
            .sf_a       (sf_a[s]),
            .sf_b       (sf_b[s]),
            .result_sig (mul_f4_sig_s[s]),
            .result_exp (mul_f4_exp_s[s]),
            .exceptions (mul_f4_exc_s[s]),
            .sig_zero   (mul_f4_zero_s[s])
        );
    end
    for (genvar i = 0; i < TCK; ++i) begin : g_mul_f4_lane
        localparam SF_SLOT = (i * SF) / TCK;
        assign mul_f4_sig[i]  = mul_f4_sig_s[SF_SLOT][i];
        assign mul_f4_exp[i]  = mul_f4_exp_s[SF_SLOT][i];
        assign mul_f4_exc[i]  = mul_f4_exc_s[SF_SLOT][i];
        assign mul_f4_zero[i] = mul_f4_zero_s[SF_SLOT][i];
    end
    wire [TCK:0][EXP_W-1:0] join_exp;
    fedp_excep_t [TCK:0]    join_exc;
    wire [24:0]             c_sig;
    VX_tcu_tfr_mul_join #(
        .N(N),
        .TCK(TCK),
        .W(W),
        .WA(WA),
        .EXP_W(EXP_W)
    ) join_stage (
        .clk        (clk),
        .valid_in   (valid_in),
        .req_id     (req_id),
        .fmt_s      (fmt_s),
        .c_val      (c_val),
        .exp_f16    (mul_f16_exp),
        .exc_f16    (mul_f16_exc),
        .exp_f8     (mul_f8_exp),
        .exc_f8     (mul_f8_exc),
        .exp_f4     (mul_f4_exp),
        .exc_f4     (mul_f4_exc),
        .exp_out    (join_exp),
        .exc_out    (join_exc),
        .c_sig      (c_sig)
    );
    fedp_excep_t exceptions_w;
    VX_tcu_tfr_exc_reduce #(
        .TCK (TCK)
    ) exc_reduce (
        .exc_in  (join_exc),
        .exc_out (exceptions_w)
    );
    wire [TCK-1:0] lane_mask_w;
    VX_tcu_tfr_lane_mask #(
        .N   (N),
        .TCK (TCK)
    ) lane_mask_inst (
        .vld_mask (vld_mask),
        .fmt_s    (fmt_s),
        .lane_mask(lane_mask_w)
    );
    localparam EXC_W = $bits(fedp_excep_t);
    wire [TCK:0][EXP_W-1:0] join_exp_r;
    wire [24:0]             c_sig_r;
    fedp_excep_t            exceptions_r;
    wire [TCK-1:0]          lane_mask_r;
    wire [4:0]              fmt_s_r;
    VX_pipe_register #(
        .DATAW ((TCK+1)*EXP_W + 25 + EXC_W + TCK + 5),
        .DEPTH (PROD_REG)
    ) pipe_seam (
        .clk      (clk),
        .reset    (1'b0),
        .enable   (enable),
        .data_in  ({join_exp,   c_sig,   exceptions_w, lane_mask_w, fmt_s}),
        .data_out ({join_exp_r, c_sig_r, exceptions_r, lane_mask_r, fmt_s_r})
    );
    logic [TCK-1:0][24:0] sig_sel;
    logic [TCK-1:0]       sig_zero;
    always_comb begin
        case (fmt_s_r)
            TCU_FP16_ID,
            TCU_BF16_ID: begin
                sig_sel  = mul_f16_sig;
                sig_zero = '0;
            end
            TCU_TF32_ID: begin
                sig_sel  = mul_f16_sig;
                sig_zero = '0;
            end
            TCU_FP8_ID, TCU_BF8_ID
            , TCU_MXFP8_ID, TCU_MXBF8_ID
            : begin
                sig_sel  = mul_f8_sig;
                sig_zero = mul_f8_zero;
            end
            TCU_MXFP4_ID: begin
                sig_sel  = mul_f4_sig;
                sig_zero = mul_f4_zero;
            end
            TCU_NVFP4_ID: begin
                sig_sel  = mul_f4_sig;
                sig_zero = mul_f4_zero;
            end
            default: begin
                sig_sel  = '0;
                sig_zero = '0;
            end
        endcase
    end
    assign raw_sigs = {c_sig_r, sig_sel};
    for (genvar i = 0; i < TCK; ++i) begin : g_exp_kill
        assign exponents[i] = EXTERNAL_EXP && external_exp_enable ? external_exponents[i]
                            : sig_zero[i] ? '0 : join_exp_r[i];
    end
    assign exponents[TCK] = EXTERNAL_EXP && external_exp_enable ? external_exponents[TCK] : join_exp_r[TCK];
    VX_tcu_tfr_max_exp #(
        .N     (TCK+1),
        .WIDTH (EXP_W)
    ) find_max_exp (
        .exponents (exponents),
        .sel_exp   (exp_sel)
    );
    assign exceptions = exceptions_r;
    assign lane_mask  = lane_mask_r;
endmodule
module VX_ucc_dpa16_comb import VX_tcu_pkg::*; (
    input  wire [4:0]           fmt,
    input  wire [63:0]          mask,
    input  wire [7:0][31:0]     a,
    input  wire [7:0][31:0]     b,
    input  wire [3:0][7:0]      scale_a,
    input  wire [3:0][7:0]      scale_b,
    input  wire [31:0]          c,
    output wire [31:0]          result
);
    wire [16:0][TCU_EXP_BITS-1:0] exponents;
    wire [16:0] exp_sel;
    wire [16:0][24:0] raw_sigs;
    fedp_excep_t exceptions;
    wire [15:0] lane_mask;
    wire [TCU_EXP_BITS-1:0] max_exp;
    wire [16:0][31:0] aligned;
    wire [16:0] sticky, negs;
    wire [31:0] magnitude;
    wire sign, sum_sticky;
    VX_tcu_tfr_shared_mul #(
        .N        (8),
        .W        (25),
        .WA       (32),
        .SF       (4),
        .USE_DSP  (0),
        .PROD_REG (0)
    ) mul (
        .clk        (1'b0),
        .enable     (1'b1),
        .valid_in   (1'b0),
        .req_id     (32'd0),
        .vld_mask   (mask),
        .fmt_s      (fmt),
        .a_row      (a),
        .b_col      (b),
        .c_val      (c),
        . mantissa_a (),
        . mantissa_b (),
        .external_products ('0),
        .external_exp_enable (1'b0),
        .external_exponents ('0),
        . f8_mantissa_a (),
        . f8_mantissa_b (),
        .external_f8_products ('0),
        .sf_a       (scale_a),
        .sf_b       (scale_b),
        .exponents  (exponents),
        .exp_sel    (exp_sel),
        .raw_sigs   (raw_sigs),
        .exceptions (exceptions),
        .lane_mask  (lane_mask)
    );
    VX_tcu_tfr_align #(
        .N  (17),
        .WI (25),
        .WO (32)
    ) align (
        .clk         (1'b0),
        .valid_in    (1'b0),
        .req_id      (32'd0),
        .exponents   (exponents),
        .sel_exp     (exp_sel),
        .lane_mask   (lane_mask),
        .sigs_in     (raw_sigs),
        .is_int      (1'b0),
        .external_shift (1'b0),
        .external_data (52'd0),
        .external_amount (8'd0),
        . external_result (),
        . external_sticky (),
        .max_exp     (max_exp),
        .sigs_out    (aligned),
        .sticky_bits (sticky),
        .fp_negs     (negs)
    );
    VX_tcu_tfr_acc #(
        .N  (17),
        .WO (32)
    ) acc (
        .clk        (1'b0),
        .valid_in   (1'b0),
        .req_id     (32'd0),
        .sigs_in    (aligned),
        .sticky_in  (sticky),
        .fp_negs    (negs),
        . sum_out (),
        .sig_out    (magnitude),
        .sign_out   (sign),
        .sticky_out (sum_sticky)
    );
    VX_tcu_tfr_norm_round #(
        .WA     (32),
        .C_HI_W (7)
    ) norm (
        .clk        (1'b0),
        .valid_in   (1'b0),
        .req_id     (32'd0),
        .max_exp    (max_exp),
        .acc_sig    (magnitude),
        .acc_sign   (sign),
        .cval_hi    (7'd0),
        .is_int     (1'b0),
        .sticky_in  (sum_sticky),
        .exceptions (exceptions),
        .result     (result)
    );
endmodule
