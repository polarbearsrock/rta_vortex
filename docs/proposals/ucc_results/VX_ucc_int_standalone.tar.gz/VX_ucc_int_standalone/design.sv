module FullAdder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    assign sum = a ^ b ^ cin;
    assign cout = (a & b) | ((a ^ b) & cin);
endmodule
module VX_csa_32 #(
    parameter N = 3,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N-1:0] carry_int;
    for (genvar i = 0; i < N; i++) begin : g_compress_3_2
        FullAdder FA (
            .a    (a[i]),
            .b    (b[i]),
            .cin  (c[i]),
            .sum  (sum_int[i]),
            .cout (carry_int[i])
        );
    end
    assign sum = WIDTH_O'(sum_int);
    assign carry = WIDTH_O'({1'b0, carry_int, 1'b0});
endmodule
module counter_5to3(
    input wire x1, x2, x3, x4, cin,
    output wire sum, carry, cout
);
    wire s1 = x1 ^ x2 ^ x3;
    assign cout = (x1 & x2) | (x2 & x3) | (x1 & x3);
    assign sum = s1 ^ x4 ^ cin;
    assign carry = (s1 & x4) | (x4 & cin) | (s1 & cin);
endmodule
module VX_csa_42 #(
    parameter N = 4,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    input  wire [N-1:0] d,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N:0]   cin;
    wire [N-1:0] cout;
    wire [N-1:0] carry_int;
    assign cin[0] = 1'b0;
    for (genvar i = 0; i < N; i++) begin : g_compress_4_2
        counter_5to3 u_counter_5to3(
            .x1(a[i]),
            .x2(b[i]),
            .x3(c[i]),
            .x4(d[i]),
            .cin(cin[i]),
            .sum(sum_int[i]),
            .carry(carry_int[i]),
            .cout(cout[i])
        );
        assign cin[i+1] = cout[i];
    end
    wire [1:0] carry_temp;
    assign sum = WIDTH_O'(sum_int);
    assign carry_temp = {carry_int[N-1] & cin[N], carry_int[N-1] ^ cin[N]};
    assign carry = WIDTH_O'({carry_temp, carry_int[N-2:0], 1'b0});
endmodule
module VX_csa_block #(
    parameter N = 4,
    parameter W = 8,
    parameter S = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    ;
    function automatic integer calc_4to2_levels(integer n);
        integer remaining = n;
        integer levels_4to2 = 0;
        while (remaining >= 4) begin
            levels_4to2 = levels_4to2 + 1;
            remaining = remaining - 2;
        end
        return levels_4to2;
    endfunction
    localparam LEVELS_4TO2 = calc_4to2_levels(N);
    localparam TOTAL_LEVELS = LEVELS_4TO2 + ((N - LEVELS_4TO2 * 2) == 3 ? 1 : 0);
    localparam WN_CALC = W + TOTAL_LEVELS + 2;
    localparam WN = (WN_CALC > S) ? WN_CALC : S;
    wire [WN-1:0] St [0:TOTAL_LEVELS];
    wire [WN-1:0] Ct [0:TOTAL_LEVELS];
    assign St[0] = WN'(operands[0]);
    assign Ct[0] = WN'(operands[1]);
    for (genvar i = 0; i < LEVELS_4TO2; i++) begin : g_4to2_levels
        localparam WI = W + i;
        localparam WO = WI + 2;
        localparam OP_A_IDX = 2 + (i * 2);
        localparam OP_B_IDX = 3 + (i * 2);
        wire [WO-1:0] st, ct;
        VX_csa_42 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_42 (
            .a(WI'(St[i])),
            .b(WI'(Ct[i])),
            .c(WI'(operands[OP_A_IDX])),
            .d(WI'(operands[OP_B_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[i+1] = WN'(st);
        assign Ct[i+1] = WN'(ct);
    end
    if ((N - LEVELS_4TO2 * 2) == 3) begin : g_final_3to2
        localparam FINAL_OP_IDX = 2 + (LEVELS_4TO2 * 2);
        localparam WI = W + LEVELS_4TO2;
        localparam WO = WI + 2;
        wire [WO-1:0] st, ct;
        VX_csa_32 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_32 (
            .a(WI'(St[LEVELS_4TO2])),
            .b(WI'(Ct[LEVELS_4TO2])),
            .c(WI'(operands[FINAL_OP_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[LEVELS_4TO2+1] = WN'(st);
        assign Ct[LEVELS_4TO2+1] = WN'(ct);
    end
    else begin : g_no_final_3to2
        if (LEVELS_4TO2 < TOTAL_LEVELS) begin : g_pass_through
            assign St[LEVELS_4TO2+1] = St[LEVELS_4TO2];
            assign Ct[LEVELS_4TO2+1] = Ct[LEVELS_4TO2];
        end
    end
    assign sum  = St[TOTAL_LEVELS][S-1:0];
    assign carry = Ct[TOTAL_LEVELS][S-1:0];
endmodule
module VX_csa_tree #(
    parameter N   = 16,  
    parameter W   = 8,   
    parameter K   = 6,   
    parameter BAL = 1,   
    parameter S   = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    localparam CLUSTER_W    = (K == 1) ? W : (W + K + 2);
    localparam NUM_CLUSTERS = (K == 1) ? N : ((N + K - 1) / K);
    localparam TOP_N        = (K == 1) ? N : (NUM_CLUSTERS * 2);
    function automatic integer next_lev_ragged(integer n_in);
        integer n_rem = n_in % 4;
        return (n_rem == 3) ? ((n_in/4)*2 + 2) : ((n_in/4)*2 + n_rem);
    endfunction
    function automatic integer next_lev_balanced(integer n_in);
        integer n_rem = n_in % 4;
        if (n_in <= 3) return (n_rem == 3) ? 2 : n_rem;
        if (n_rem == 0) return (n_in/4) * 2;
        if (n_rem == 1 || n_rem == 2) return ((n_in/4)-1)*2 + 4;
        return ((n_in/4)*2) + 2;
    endfunction
    function automatic integer get_next_sz(integer n, integer use_bal);
        return (use_bal != 0) ? next_lev_balanced(n) : next_lev_ragged(n);
    endfunction
    function automatic integer calc_depth(integer n_in);
        integer d = 0;
        integer count = n_in;
        while (count > 2) begin
            count = get_next_sz(count, BAL);
            d = d + 1;
        end
        return d;
    endfunction
    function automatic integer get_cnt_at_lev(integer l, integer start_n);
        integer c = start_n;
        for(integer k=0; k<l; k++) c = get_next_sz(c, BAL);
        return c;
    endfunction
    wire [TOP_N-1:0][CLUSTER_W-1:0] tree_inputs;
    if (K == 1) begin : g_no_cluster
        for (genvar i = 0; i < N; ++i) begin : g_map
            assign tree_inputs[i] = CLUSTER_W'(operands[i]);
        end
    end else begin : g_do_cluster
        for (genvar i = 0; i < NUM_CLUSTERS; ++i) begin : g_clusters
            localparam C_SIZE = (i == NUM_CLUSTERS - 1) ? (N - i*K) : K;
            if (C_SIZE == 1) begin : g_c1
                assign tree_inputs[2*i]     = CLUSTER_W'(operands[i*K]);
                assign tree_inputs[2*i + 1] = '0;
            end else begin : g_lin
                wire [CLUSTER_W-1:0] s_loc, c_loc;
                wire [C_SIZE-1:0][W-1:0] sub_ops;
                for(genvar j=0; j<C_SIZE; ++j) begin : g_slice
                    assign sub_ops[j] = operands[i*K + j];
                end
                VX_csa_block #(
                    .N(C_SIZE),
                    .W(W),
                    .S(CLUSTER_W)
                ) cluster_linear (
                    .operands(sub_ops),
                    .sum(s_loc),
                    .carry(c_loc)
                );
                assign tree_inputs[2*i]     = s_loc;
                assign tree_inputs[2*i + 1] = c_loc;
            end
        end
    end
    localparam DEPTH = calc_depth(TOP_N);
    localparam MAX_WN = CLUSTER_W + (DEPTH * 2) + 4;
    localparam WN = (S < MAX_WN) ? S : MAX_WN;
    wire [DEPTH:0][TOP_N-1:0][WN-1:0] tree_sig;
    for (genvar i = 0; i < TOP_N; i++) begin : g_init_l0
        assign tree_sig[0][i] = WN'(tree_inputs[i]);
    end
    for (genvar lev = 0; lev < DEPTH; lev++) begin : g_levels
        localparam integer NUM_IN = get_cnt_at_lev(lev, TOP_N);
        localparam integer WI = CLUSTER_W + (lev * 2);
        localparam integer WO = WI + 2;
        if (BAL == 1) begin : g_balanced
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            localparam integer CORE = (REM == 1 || REM == 2) ? (N_42 - 1) : N_42;
            for (genvar i = 0; i < CORE; i++) begin : g_core
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 1) begin : g_r1
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
                assign tree_sig[lev+1][OB+2] = tree_sig[lev][B+3]; assign tree_sig[lev+1][OB+3] = tree_sig[lev][B+4];
            end
            else if (REM == 2) begin : g_r2
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s1, c1, s2, c2;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cA (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s1),
                    .carry(c1)
                );
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cB (
                    .a(WI'(tree_sig[lev][B+3])),
                    .b(WI'(tree_sig[lev][B+4])),
                    .c(WI'(tree_sig[lev][B+5])),
                    .sum(s2),
                    .carry(c2)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s1); assign tree_sig[lev+1][OB+1] = WN'(c1);
                assign tree_sig[lev+1][OB+2] = WN'(s2); assign tree_sig[lev+1][OB+3] = WN'(c2);
            end
            else if (REM == 3) begin : g_r3
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
            end
        end
        else begin : g_ragged
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            for (genvar i = 0; i < N_42; i++) begin : g_csa42
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 3) begin : g_rem3
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][N_42*4])),
                    .b(WI'(tree_sig[lev][N_42*4+1])),
                    .c(WI'(tree_sig[lev][N_42*4+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][N_42*2] = WN'(s);
                assign tree_sig[lev+1][N_42*2+1] = WN'(c);
            end
            else begin : g_pass
                for(genvar p=0; p<REM; p++) begin : g_rem
                    assign tree_sig[lev+1][N_42*2+p] = tree_sig[lev][N_42*4+p];
                end
            end
        end
    end
    assign sum   = S'(tree_sig[DEPTH][0]);
    assign carry = (get_cnt_at_lev(DEPTH, TOP_N) > 1) ? S'(tree_sig[DEPTH][1]) : '0;
endmodule
module VX_ks_adder #(
    parameter N = 16,
    parameter BYPASS = 0
) (
    input  wire [N-1:0] dataa,
    input  wire [N-1:0] datab,
    input  wire         cin,
    output wire [N-1:0] sum,
    output wire         cout
);
    if (BYPASS) begin : g_bypass
        assign {cout, sum} = dataa + datab + N'(cin);
    end else begin : g_KS
        localparam LEVELS = $clog2(N);
        wire [LEVELS:0][N-1:0] G;
        wire [LEVELS:0][N-1:0] P;
        for (genvar i = 0; i < N; i++) begin : g_initial_gp
            assign G[0][i] = dataa[i] & datab[i];
            assign P[0][i] = dataa[i] ^ datab[i];
        end
        for (genvar k = 1; k <= LEVELS; k++) begin : g_ks_levels
            localparam STEP = 1 << (k - 1);
            for (genvar i = 0; i < N; i++) begin : g_ks_nodes
                if (i >= STEP) begin : g_compute_gp
                    assign G[k][i] = G[k-1][i] | (P[k-1][i] & G[k-1][i-STEP]);
                    assign P[k][i] = P[k-1][i] & P[k-1][i-STEP];
                end else begin : g_passthrough_gp
                    assign G[k][i] = G[k-1][i];
                    assign P[k][i] = P[k-1][i];
                end
            end
        end
        assign sum[0] = P[0][0] ^ cin;
        for (genvar i = 1; i < N; i++) begin : g_sum
            wire carry_in_i = G[LEVELS][i-1] | (P[LEVELS][i-1] & cin);
            assign sum[i] = P[0][i] ^ carry_in_i;
        end
        assign cout = G[LEVELS][N-1] | (P[LEVELS][N-1] & cin);
    end
endmodule
module VX_find_first #(
    parameter N       = 1,
    parameter DATAW   = 1,
    parameter REVERSE = 0  
) (
    input  wire [N-1:0][DATAW-1:0] data_in,
    input  wire [N-1:0]            valid_in,
    output wire [DATAW-1:0]        data_out,
    output wire                    valid_out
);
    localparam LOGN = $clog2(N);
    localparam TL   = (1 << LOGN) - 1;
    localparam TN   = (1 << (LOGN+1)) - 1;
    reg             valid_r;
    reg [DATAW-1:0] data_r;
    always @(*) begin : g_scan
        reg [TN-1:0]       s_n;
        reg [TN*DATAW-1:0] d_n;
        s_n = '0;
        d_n = '0;
        for (integer i = 0; i < N; ++i) begin
            s_n[TL+i] = REVERSE ? valid_in[N-1-i] : valid_in[i];
            d_n[(TL+i)*DATAW +: DATAW] = REVERSE ? data_in[N-1-i] : data_in[i];
        end
        for (integer k = TL-1; k >= 0; --k) begin
            s_n[k] = s_n[2*k+2] | s_n[2*k+1];
            d_n[k*DATAW +: DATAW] = s_n[2*k+1] ? d_n[(2*k+1)*DATAW +: DATAW] : d_n[(2*k+2)*DATAW +: DATAW];
        end
        valid_r = s_n[0];
        data_r  = d_n[0 +: DATAW];
    end
    assign valid_out = valid_r;
    assign data_out  = data_r;
endmodule
module VX_lzc #(
    parameter N       = 2,
    parameter REVERSE = 0,   
    parameter LOGN    = (((N) > 1) ? $clog2(N) : 1)
) (
    input  wire [N-1:0]    data_in,
    output wire [LOGN-1:0] data_out,
    output wire            valid_out
);
    if (N == 1) begin : g_passthru
        assign data_out  = '0;
        assign valid_out = data_in;
    end else begin : g_lzc
        wire [N-1:0][LOGN-1:0] indices;
        for (genvar i = 0; i < N; ++i) begin : g_indices
            assign indices[i] = REVERSE ? LOGN'(i) : LOGN'(N-1-i);
        end
        VX_find_first #(
            .N       (N),
            .DATAW   (LOGN),
            .REVERSE (!REVERSE)
        ) find_first (
            .valid_in  (data_in),
            .data_in   (indices),
            .data_out  (data_out),
            .valid_out (valid_out)
        );
    end
endmodule
module VX_ucc_boolean (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [31:0] c,
    input  wire [7:0]  immediate,
    input  wire [2:0]  op,
    output logic [31:0] result
);
    wire [31:0] lop3;
    for (genvar i = 0; i < 32; ++i) begin : g_lop3
        assign lop3[i] = immediate[{a[i], b[i], c[i]}];
    end
    always_comb begin
        case (op)
            3'd0: result = a & b;
            3'd1: result = a | b;
            3'd2: result = a ^ b;
            3'd3: result = ~a;
            3'd4: result = lop3;
            3'd5: result = c[0] ? a : b;
            3'd6: result = a;
            default: result = '0;
        endcase
    end
endmodule
module VX_ucc_shift_jam #(
    parameter W = 80,
    parameter SW = 10
) (
    input  wire [W-1:0]  data_in,
    input  wire [SW-1:0] amount,
    input  wire          left,
    input  wire          fill,
    output wire [W-1:0] data_out,
    output wire          sticky
);
    localparam LEVELS = $clog2(W);
    wire [LEVELS:0][W-1:0] stage;
    wire [LEVELS:0] lost;
    wire [W-1:0] shifted;
    wire over = amount >= SW'(W);
    assign lost[0] = 1'b0;
    for (genvar i = 0; i < W; ++i) begin : g_reverse
        assign stage[0][i] = left ? data_in[W-1-i] : data_in[i];
        assign shifted[i] = left ? stage[LEVELS][W-1-i] : stage[LEVELS][i];
    end
    for (genvar s = 0; s < LEVELS; ++s) begin : g_stage
        localparam D = 1 << s;
        assign stage[s+1] = amount[s] ? {{D{fill && !left}}, stage[s][W-1:D]} : stage[s];
        assign lost[s+1] = lost[s] | (amount[s] && (|stage[s][D-1:0]));
    end
    assign data_out = over ? {W{fill && !left}} : shifted;
    assign sticky = !left && (over ? (|data_in) : lost[LEVELS]);
endmodule
module VX_ucc_int_standalone (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [31:0] c,
    input  wire [7:0]  op,
    input  wire [7:0]  immediate,
    output wire [31:0] result,
    output wire        predicate
);
    wire [63:0] product = a * b;
    wire high = op >= 8'h15 && op <= 8'h17;
    wire compare_op = op >= 8'h18 && op <= 8'h2f;
    wire negate = op == 8'h12 || (op == 8'h13 && a[31]);
    wire subtract = op == 8'h11 || compare_op;
    wire correction_a = high && op != 8'h15 && a[31];
    wire correction_b = high && op == 8'h16 && b[31];
    wire [3:0][32:0] operands;
    assign operands[0] = {1'b0, high ? product[63:32] : negate ? ~a : a};
    assign operands[1] = {1'b0, high ? (correction_a ? ~b : 32'd0)
                                     : subtract ? ~b : op == 8'h10 ? b : 32'd0};
    assign operands[2] = {1'b0, correction_b ? ~a : 32'd0};
    assign operands[3] = 33'(high ? (2'(correction_a) + 2'(correction_b)) : 2'(negate || subtract));
    wire [32:0] sum_vec, carry_vec;
    VX_csa_tree #(
        .N (4),
        .W (33),
        .S (33)
    ) reduction (
        .operands (operands),
        .sum      (sum_vec),
        .carry    (carry_vec)
    );
    wire [31:0] sum;
    wire carry;
    VX_ks_adder #(
        .N (32),
        .BYPASS (0)
    ) adder (
        .cin   (1'b0),
        .dataa (sum_vec[31:0]),
        .datab (carry_vec[31:0]),
        .sum   (sum),
        .cout  (carry)
    );
    wire borrow = !(sum_vec[32] ^ carry_vec[32] ^ carry);
    wire less = !op[5] && a[31] != b[31] ? a[31] : borrow;
    wire equal = sum == 0;
    logic comparison;
    always_comb begin
        case (op[2:0])
            3'd0: comparison = equal;
            3'd1: comparison = !equal;
            3'd2: comparison = less;
            3'd3: comparison = less || equal;
            3'd4: comparison = !(less || equal);
            3'd5: comparison = !less;
            default: comparison = less;
        endcase
    end
    wire minmax = compare_op && op[2:1] == 3;
    wire [31:0] shifted;
    VX_ucc_shift_jam #(
        .W (32),
        .SW (6)
    ) shifter (
        .data_in  (a),
        .amount   ({1'b0, b[4:0]}),
        .left     (op == 8'h30),
        .fill     (op == 8'h32 && a[31]),
        .data_out (shifted),
        . sticky ()
    );
    wire [4:0] lz;
    wire nonzero;
    VX_lzc #(
        .N (32)
    ) leading_zeros (
        .data_in   (a),
        .data_out  (lz),
        .valid_out (nonzero)
    );
    wire [31:0] boolean_result;
    VX_ucc_boolean boolean_unit (
        .a         (a),
        .b         (b),
        .c         (c),
        .op        (op[2:0]),
        .immediate (immediate),
        .result    (boolean_result)
    );
    assign predicate = compare_op && comparison;
    assign result = op[7:4] == 5 ? boolean_result
                  : op == 8'h33 ? (nonzero ? 32'(lz) : 32'd32)
                  : op[7:4] == 3 ? shifted
                  : op == 8'h14 ? product[31:0]
                  : minmax ? ((less ^ op[0]) ? a : b)
                  : compare_op ? {31'd0, comparison} : sum;
endmodule
