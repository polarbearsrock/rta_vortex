package VX_gpu_pkg;
    localparam NC_BITS = $clog2(1);
    localparam NW_BITS = $clog2(4);
    localparam NT_BITS = $clog2(64);
    localparam NB_BITS = $clog2(8);
    localparam NC_WIDTH = (((NC_BITS) > 0) ? (NC_BITS) : 1);
    localparam NW_WIDTH = (((NW_BITS) > 0) ? (NW_BITS) : 1);
    localparam NT_WIDTH = (((NT_BITS) > 0) ? (NT_BITS) : 1);
    localparam NB_WIDTH = (((NB_BITS) > 0) ? (NB_BITS) : 1);
    localparam NUM_CTA_MAX = 4;
    localparam NCTA_BITS  = $clog2(NUM_CTA_MAX);
    localparam NCTA_WIDTH = (((NCTA_BITS) > 0) ? (NCTA_BITS) : 1);
    localparam XLENB    = 32 / 8;
    localparam XLENB_W  = $clog2(XLENB);
    localparam BYTESEL_BITS = (XLENB_W + XLENB_W);
    localparam [BYTESEL_BITS-1:0] BYTESEL_DEFAULT = {XLENB_W'(XLENB-1), XLENB_W'(0)};
    localparam RV_REGS = 32;
    localparam RV_REGS_BITS = 5;
    localparam RV_RD  = 0;
    localparam RV_RS1 = 1;
    localparam RV_RS2 = 2;
    localparam RV_RS3 = 3;
    localparam REG_TYPE_I = 0;
    localparam REG_TYPE_F = 1;
    localparam REG_TYPES = 1 + 1;
    localparam NUM_REGS = (REG_TYPES * RV_REGS);
    localparam REG_TYPE_BITS = (((REG_TYPES) > 1) ? $clog2(REG_TYPES) : 1);
    localparam NUM_REGS_BITS = $clog2(NUM_REGS);
    localparam XREG_0      = 0;
    localparam XREG_1      = 1;
    localparam NUM_XREGS   = 2;
    localparam DV_STACK_SIZE = (((64-1) > 0) ? (64-1) : 1);
    localparam DV_STACK_SIZEW = (((DV_STACK_SIZE) > 1) ? $clog2(DV_STACK_SIZE) : 1);
    localparam PERF_CTR_BITS = 44;
    localparam SIMD_COUNT = 64 / 64;
    localparam SIMD_IDX_BITS = $clog2(SIMD_COUNT);
    localparam SIMD_IDX_W = (((SIMD_IDX_BITS) > 0) ? (SIMD_IDX_BITS) : 1);
    localparam NUM_OPCS_BITS = $clog2(1);
    localparam NUM_OPCS_W = (((NUM_OPCS_BITS) > 0) ? (NUM_OPCS_BITS) : 1);
    localparam BAR_ADDR_BITS = NW_BITS + NB_BITS;
    localparam BAR_ADDR_W = (((BAR_ADDR_BITS) > 0) ? (BAR_ADDR_BITS) : 1);
    localparam BAR_ID_SHIFT = 8;
    localparam BAR_SIZE_W = ((((((NW_WIDTH) > (NC_WIDTH)) ? (NW_WIDTH) : (NC_WIDTH))) > ($clog2(32))) ? ((((NW_WIDTH) > (NC_WIDTH)) ? (NW_WIDTH) : (NC_WIDTH))) : ($clog2(32)));
    localparam UOP_PACKLD = 0;
    localparam UOP_TCU = UOP_PACKLD + 1;
    localparam UOP_GFX = UOP_TCU + 1;
    localparam UOP_MAX = UOP_GFX + 0;
    localparam UOP_CTR_W = 8;
    localparam CTA_TID_WIDTH = (((NW_BITS + NT_BITS) > 0) ? (NW_BITS + NT_BITS) : 1);
    localparam UUID_WIDTH = 44;
    localparam PC_BITS = 32;
    function automatic logic [32-1:0] to_fullPC(input logic[PC_BITS-1:0] pc);
        to_fullPC = 32'(pc);
    endfunction
    function automatic logic [PC_BITS-1:0] from_fullPC(input logic[32-1:0] pc);
        from_fullPC = pc;
    endfunction
    localparam NUM_SRC_OPDS = 3;
    localparam SRC_OPD_BITS = $clog2(NUM_SRC_OPDS);
    localparam SRC_OPD_WIDTH = (((SRC_OPD_BITS) > 0) ? (SRC_OPD_BITS) : 1);
    localparam NUM_SOCKETS = (((1 / 1) > 0) ? (1 / 1) : 1);
    localparam NUM_STACKS = 1 * NUM_SOCKETS * 1 * 4 * 64;
    localparam [32-1:0] STACK_WINDOW_TOP    = 32'(32'hFFFF0000);
    localparam [32-1:0] STACK_WINDOW_SPAN   = 32'(NUM_STACKS) << 13;
    localparam [32-1:0] STACK_WINDOW_BOTTOM = STACK_WINDOW_TOP - STACK_WINDOW_SPAN;
    localparam HART_ID_BITS = NC_BITS + NW_BITS + NT_BITS;
    localparam HART_ID_WIDTH = (((HART_ID_BITS) > 0) ? (HART_ID_BITS) : 1);
    typedef enum logic [3:0] {
        AMO_OP_LR    = 4'h0,
        AMO_OP_SC    = 4'h1,
        AMO_OP_ADD   = 4'h2,
        AMO_OP_SWAP  = 4'h3,
        AMO_OP_XOR   = 4'h4,
        AMO_OP_OR    = 4'h5,
        AMO_OP_AND   = 4'h6,
        AMO_OP_MIN   = 4'h7,
        AMO_OP_MAX   = 4'h8,
        AMO_OP_CAS   = 4'h9
    } amo_op_e;
    typedef struct packed {
        logic [HART_ID_WIDTH-1:0]   hart_id;
        logic                        amo_unsigned;
        amo_op_e                     amo_op;
        logic                        amo_valid;
    } amo_req_t;
    localparam AMO_REQ_BITS = $bits(amo_req_t);
    typedef struct packed {
        amo_req_t                    amo;            
        logic                        is_addr_om;     
        logic                        is_addr_local;  
        logic                        is_addr_io;     
        logic                        is_flush;       
    } mem_bus_attr_t;
    localparam MEM_ATTR_FLUSH_OFFS  = 0;
    localparam MEM_ATTR_IO_OFFS     = 1;
    localparam MEM_ATTR_LOCAL_OFFS  = 2;
    localparam MEM_ATTR_OM_OFFS     = 3;
    localparam MEM_ATTR_AMO_OFFS    = 4;
    localparam MEM_ATTR_WIDTH = $bits(mem_bus_attr_t);
    localparam VX_DCR_ADDR_WIDTH = 12;
    localparam VX_DCR_DATA_WIDTH = 32;
    localparam STALL_TIMEOUT = 100000;
    localparam EX_ALU = 0;
    localparam EX_LSU = 1;
    localparam EX_SFU = 2;
    localparam EX_FPU = (EX_SFU + 1);
    localparam EX_TCU = (EX_FPU + 1);
    localparam NUM_EX_UNITS = EX_TCU + 1;
    localparam EX_BITS = $clog2(NUM_EX_UNITS);
    localparam EX_WIDTH = (((EX_BITS) > 0) ? (EX_BITS) : 1);
    localparam SFU_BITS = $clog2(2);
    localparam SFU_WIDTH = (((SFU_BITS) > 0) ? (SFU_BITS) : 1);
    localparam SFU_CSRS = 0;
    localparam SFU_WCTL = 1;
    localparam NUM_SFU_UNITS = (2);
    localparam INST_LUI =        7'b0110111;
    localparam INST_AUIPC =      7'b0010111;
    localparam INST_JAL =        7'b1101111;
    localparam INST_JALR =       7'b1100111;
    localparam INST_B =          7'b1100011;  
    localparam INST_L =          7'b0000011;  
    localparam INST_S =          7'b0100011;  
    localparam INST_I =          7'b0010011;  
    localparam INST_R =          7'b0110011;  
    localparam INST_V =          7'b1010111;  
    localparam INST_FENCE =      7'b0001111;  
    localparam INST_AMO =        7'b0101111;  
    localparam INST_SYS =        7'b1110011;  
    localparam INST_I_W =        7'b0011011;  
    localparam INST_R_W =        7'b0111011;  
    localparam INST_FL =         7'b0000111;  
    localparam INST_FS =         7'b0100111;  
    localparam INST_FMADD =      7'b1000011;
    localparam INST_FMSUB =      7'b1000111;
    localparam INST_FNMSUB =     7'b1001011;
    localparam INST_FNMADD =     7'b1001111;
    localparam INST_FCI =        7'b1010011;  
    localparam INST_EXT1 =       7'b0001011;  
    localparam INST_EXT2 =       7'b0101011;  
    localparam INST_EXT3 =       7'b1011011;  
    localparam INST_EXT4 =       7'b1111011;  
    localparam INST_R_F7_MUL =   7'b0000001;
    localparam INST_R_F7_ZICOND= 7'b0000111;
    localparam INST_FRM_RNE =    3'b000;   
    localparam INST_FRM_RTZ =    3'b001;   
    localparam INST_FRM_RDN =    3'b010;   
    localparam INST_FRM_RUP =    3'b011;   
    localparam INST_FRM_RMM =    3'b100;   
    localparam INST_FRM_DYN =    3'b111;   
    localparam INST_FRM_BITS =   3;
    localparam INST_OP_BITS =    4;
    localparam INST_FMT_BITS =   2;
    localparam INST_ALU_ADD =    4'b0000;
    localparam INST_ALU_LUI =    4'b0010;
    localparam INST_ALU_AUIPC =  4'b0011;
    localparam INST_ALU_SLTU =   4'b0100;
    localparam INST_ALU_SLT =    4'b0101;
    localparam INST_ALU_SUB =    4'b0111;
    localparam INST_ALU_SRL =    4'b1000;
    localparam INST_ALU_SRA =    4'b1001;
    localparam INST_ALU_CZEQ =   4'b1010;
    localparam INST_ALU_CZNE =   4'b1011;
    localparam INST_ALU_AND =    4'b1100;
    localparam INST_ALU_OR =     4'b1101;
    localparam INST_ALU_XOR =    4'b1110;
    localparam INST_ALU_SLL =    4'b1111;
    localparam INST_ALU_BITS =   4;
    localparam ALU_TYPE_BITS =   2;
    localparam ALU_TYPE_ARITH =  0;
    localparam ALU_TYPE_BRANCH = 1;
    localparam ALU_TYPE_MULDIV = 2;
    localparam ALU_TYPE_OTHER =  3;
    function automatic logic [1:0] inst_alu_class(input logic [INST_ALU_BITS-1:0] op);
        return op[3:2];
    endfunction
    function automatic logic inst_alu_signed(input logic [INST_ALU_BITS-1:0] op);
        return op[0];
    endfunction
    function automatic logic inst_alu_is_sub(input logic [INST_ALU_BITS-1:0] op);
        return op[1];
    endfunction
    function automatic logic inst_alu_is_czero(input logic [INST_ALU_BITS-1:0] op);
        return (op[3:1] == 3'b101);
    endfunction
    localparam INST_BR_BEQ =     4'b0000;
    localparam INST_BR_BNE =     4'b0010;
    localparam INST_BR_BLTU =    4'b0100;
    localparam INST_BR_BGEU =    4'b0110;
    localparam INST_BR_BLT =     4'b0101;
    localparam INST_BR_BGE =     4'b0111;
    localparam INST_BR_JAL =     4'b1000;
    localparam INST_BR_JALR =    4'b1001;
    localparam INST_BR_ECALL =   4'b1010;
    localparam INST_BR_EBREAK =  4'b1011;
    localparam INST_BR_URET =    4'b1100;
    localparam INST_BR_SRET =    4'b1101;
    localparam INST_BR_MRET =    4'b1110;
    localparam INST_BR_OTHER =   4'b1111;
    localparam INST_BR_BITS =    4;
    function automatic logic [1:0] inst_br_class(input logic [INST_BR_BITS-1:0] op);
        return {1'b0, ~op[3]};
    endfunction
    function automatic logic inst_br_is_neg(input logic [INST_BR_BITS-1:0] op);
        return op[1];
    endfunction
    function automatic logic inst_br_is_less(input logic [INST_BR_BITS-1:0] op);
        return op[2];
    endfunction
    function automatic logic inst_br_is_static(input logic [INST_BR_BITS-1:0] op);
        return op[3];
    endfunction
    localparam INST_VOTE_ALL =   2'b00;
    localparam INST_VOTE_ANY =   2'b01;
    localparam INST_VOTE_UNI =   2'b10;
    localparam INST_VOTE_BAL =   2'b11;
    localparam INST_SHFL_UP =    2'b00;
    localparam INST_SHFL_DOWN =  2'b01;
    localparam INST_SHFL_BFLY =  2'b10;
    localparam INST_SHFL_IDX =   2'b11;
    localparam INST_VOTE_BITS =  2;
    localparam INST_SHFL_BITS =  2;
    localparam INST_WGATHER =    4'h8;  
    localparam INST_M_MUL =      3'b000;
    localparam INST_M_MULHU =    3'b001;
    localparam INST_M_MULH =     3'b010;
    localparam INST_M_MULHSU =   3'b011;
    localparam INST_M_DIV =      3'b100;
    localparam INST_M_DIVU =     3'b101;
    localparam INST_M_REM =      3'b110;
    localparam INST_M_REMU =     3'b111;
    localparam INST_M_BITS =     3;
    function automatic logic inst_m_signed(input logic [INST_M_BITS-1:0] op);
        return (~op[0]);
    endfunction
    function automatic logic inst_m_is_mulx(input logic [INST_M_BITS-1:0] op);
        return (~op[2]);
    endfunction
    function automatic logic inst_m_is_mulh(input logic [INST_M_BITS-1:0] op);
        return (op[1:0] != 0);
    endfunction
    function automatic logic inst_m_signed_a(input logic [INST_M_BITS-1:0] op);
        return (op[1:0] != 1);
    endfunction
    function automatic logic inst_m_is_rem(input logic [INST_M_BITS-1:0] op);
        return op[1];
    endfunction
    localparam LSU_FMT_B =       3'b000;
    localparam LSU_FMT_H =       3'b001;
    localparam LSU_FMT_W =       3'b010;
    localparam LSU_FMT_D =       3'b011;
    localparam LSU_FMT_BU =      3'b100;
    localparam LSU_FMT_HU =      3'b101;
    localparam LSU_FMT_WU =      3'b110;
    localparam INST_LSU_LB =     4'b0000;
    localparam INST_LSU_LH =     4'b0001;
    localparam INST_LSU_LW =     4'b0010;
    localparam INST_LSU_LD =     4'b0011;  
    localparam INST_LSU_LBU =    4'b0100;
    localparam INST_LSU_LHU =    4'b0101;
    localparam INST_LSU_LWU =    4'b0110;  
    localparam INST_LSU_SB =     4'b1000;
    localparam INST_LSU_SH =     4'b1001;
    localparam INST_LSU_SW =     4'b1010;
    localparam INST_LSU_SD =     4'b1011;  
    localparam INST_LSU_FENCE =  4'b1111;
    localparam INST_LSU_BITS =   4;
    localparam INST_FENCE_BITS = 1;
    localparam INST_FENCE_D =    1'h0;
    localparam INST_FENCE_I =    1'h1;
    function automatic logic [2:0] inst_lsu_fmt(input logic [INST_LSU_BITS-1:0] op);
        return op[2:0];
    endfunction
    function automatic logic [1:0] inst_lsu_wsize(input logic [INST_LSU_BITS-1:0] op);
        return op[1:0];
    endfunction
    function automatic logic inst_lsu_is_fence(input logic [INST_LSU_BITS-1:0] op);
        return (op == INST_LSU_FENCE);
    endfunction
    localparam INST_FPU_ADD =    4'b0000;  
    localparam INST_FPU_MUL =    4'b0001;
    localparam INST_FPU_MADD =   4'b0010;  
    localparam INST_FPU_NMADD =  4'b0011;  
    localparam INST_FPU_DIV =    4'b0100;
    localparam INST_FPU_SQRT =   4'b0101;
    localparam INST_FPU_F2I =    4'b1000;  
    localparam INST_FPU_F2U =    4'b1001;  
    localparam INST_FPU_I2F =    4'b1010;  
    localparam INST_FPU_U2F =    4'b1011;  
    localparam INST_FPU_CMP =    4'b1100;  
    localparam INST_FPU_F2F =    4'b1101;  
    localparam INST_FPU_MISC =   4'b1110;  
    localparam INST_FPU_F2H =    4'b1111;
    localparam INST_FPU_BITS =   4;
    function automatic logic inst_fpu_is_class(input logic [INST_FPU_BITS-1:0] op, input logic [INST_FRM_BITS-1:0] frm);
        return (op == INST_FPU_MISC && frm == 3);
    endfunction
    function automatic logic inst_fpu_is_mvxw(input logic [INST_FPU_BITS-1:0] op, input logic [INST_FRM_BITS-1:0] frm);
        return (op == INST_FPU_MISC && frm == 4);
    endfunction
    localparam INST_SFU_TMC =    4'h0;
    localparam INST_SFU_WSPAWN = 4'h1;
    localparam INST_SFU_SPLIT =  4'h2;
    localparam INST_SFU_JOIN =   4'h3;
    localparam INST_SFU_BAR =    4'h4;
    localparam INST_SFU_PRED =   4'h5;
    localparam INST_SFU_CSRRW =  4'h6;
    localparam INST_SFU_CSRRS =  4'h7;
    localparam INST_SFU_CSRRC =  4'h8;
    localparam INST_SFU_WSYNC =  4'hA;
    localparam INST_SFU_BITS =   4;
    function automatic logic [3:0] inst_sfu_csr(input logic [2:0] funct3);
        return (4'h6 + 4'(funct3[1:0]) - 4'h1);
    endfunction
    function automatic logic inst_sfu_is_wctl(input logic [INST_SFU_BITS-1:0] op);
        return (op == INST_SFU_TMC)
            || (op == INST_SFU_WSPAWN)
            || (op == INST_SFU_SPLIT)
            || (op == INST_SFU_JOIN)
            || (op == INST_SFU_BAR)
            || (op == INST_SFU_PRED)
            || (op == INST_SFU_WSYNC);
    endfunction
    function automatic logic inst_sfu_is_csr(input logic [INST_SFU_BITS-1:0] op);
        return (op >= 6 && op <= 8);
    endfunction
    localparam ISSUE_ISW_BITS = $clog2(1);
    localparam ISSUE_ISW_SIZEW = $clog2(1 + 1);
    localparam ISSUE_ISW_W = (((ISSUE_ISW_BITS) > 0) ? (ISSUE_ISW_BITS) : 1);
    localparam PER_ISSUE_WARPS = 4 / 1;
    localparam ISSUE_WIS_BITS = $clog2(PER_ISSUE_WARPS);
    localparam ISSUE_WIS_W = (((ISSUE_WIS_BITS) > 0) ? (ISSUE_WIS_BITS) : 1);
    localparam NUM_TRAP_CSRS = 5;
    localparam DISPATCH_QSIZE = 4;
    localparam PER_OPC_WARPS = PER_ISSUE_WARPS / 1;
    localparam PER_OPC_NW_BITS = $clog2(PER_OPC_WARPS);
    localparam PER_OPC_NW_W = (((PER_OPC_NW_BITS) > 0) ? (PER_OPC_NW_BITS) : 1);
    function automatic logic [NW_WIDTH-1:0] wis_to_wid(
        input logic [ISSUE_WIS_W-1:0] wis,
        input logic [ISSUE_ISW_W-1:0] isw
    );
        if (ISSUE_WIS_BITS == 0) begin
            wis_to_wid = NW_WIDTH'(isw);
        end else if (ISSUE_ISW_BITS == 0) begin
            wis_to_wid = NW_WIDTH'(wis);
        end else begin
            wis_to_wid = NW_WIDTH'({wis, isw});
        end
    endfunction
    function automatic logic [ISSUE_ISW_W-1:0] wid_to_isw(
        input logic [NW_WIDTH-1:0] wid
    );
        if (ISSUE_ISW_BITS != 0) begin
            wid_to_isw = wid[ISSUE_ISW_W-1:0];
        end else begin
            wid_to_isw = 0;
        end
    endfunction
    function automatic logic [ISSUE_WIS_W-1:0] wid_to_wis(
        input logic [NW_WIDTH-1:0] wid
    );
        if (ISSUE_WIS_BITS != 0) begin
            wid_to_wis = ISSUE_WIS_W'(wid >> ISSUE_ISW_BITS);
        end else begin
            wid_to_wis = 0;
        end
    endfunction
    localparam INST_TCU_WMMA       = 4'h0;
    localparam INST_TCU_LD         = 4'h5;
    localparam INST_TCU_BITS = 4;
    typedef struct packed {
        logic [64-1:0] tmask;
    } tmc_t;
    typedef struct packed {
        logic [4-1:0]  wmask;
        logic [PC_BITS-1:0]     pc;
    } wspawn_t;
    typedef struct packed {
        logic                   is_dvg;
        logic [64-1:0] then_tmask;
        logic [64-1:0] else_tmask;
        logic [PC_BITS-1:0]     next_pc;
    } split_t;
    typedef struct packed {
        logic [64-1:0] tmask;
        logic [DV_STACK_SIZEW-1:0] stack_ptr;
    } join_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0]    id;
        logic                   is_event;
        logic                   is_global;
        logic                   is_arrive;
        logic                   is_sync;
        logic                   phase;
        logic [BAR_SIZE_W-1:0]  size_m1;
    } barrier_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0] id;
        logic [NC_WIDTH-1:0] size_m1;
        logic [NC_WIDTH-1:0] core_id;
    } gbar_req_t;
    typedef struct packed {
        logic [NB_WIDTH-1:0] id;
    } gbar_rsp_t;
    typedef struct packed {
        logic [BAR_ADDR_W-1:0] addr;
        logic                  is_done;
    } txbar_t;
    typedef struct packed {
        logic                         rw;
        logic [VX_DCR_ADDR_WIDTH-1:0] addr;
        logic [VX_DCR_DATA_WIDTH-1:0] data;
    } dcr_req_t;
    typedef struct packed {
        logic [VX_DCR_DATA_WIDTH-1:0] data;
    } dcr_rsp_t;
    localparam FRAG_STAMP_BITS = 2 * (15 - 1) + 4 + 16;
    localparam FRAG_QUAD_LANES = 4;
    localparam FRAG_LANE_BITS  = FRAG_STAMP_BITS / FRAG_QUAD_LANES;
    localparam KMU_FRAG_BITS = 0;
    localparam KMU_FRAG_PAYLOAD_BITS = 0;
    localparam KMU_COMPUTE_BITS = 3*32                     
                                + 3*32                     
                                + 3*(CTA_TID_WIDTH+1)      
                                + (CTA_TID_WIDTH+1)        
                                + 3*CTA_TID_WIDTH          
                                + (NW_WIDTH+1)             
                                + 1;                       
    localparam KMU_ARGS_BITS = (((KMU_COMPUTE_BITS) > (KMU_FRAG_PAYLOAD_BITS)) ? (KMU_COMPUTE_BITS) : (KMU_FRAG_PAYLOAD_BITS)) + 1;
    typedef struct packed {
        logic [KMU_ARGS_BITS-KMU_COMPUTE_BITS-1:0] __padding;
        logic [2:0][31:0]              grid_dim;
        logic [2:0][31:0]              block_idx;
        logic [2:0][CTA_TID_WIDTH:0]   block_dim;
        logic [CTA_TID_WIDTH:0]        block_size;
        logic [2:0][CTA_TID_WIDTH-1:0] warp_step;
        logic [NW_WIDTH:0]             cluster_size;
        logic                          is_first_of_cluster;
    } kmu_compute_args_t;
    typedef union packed {
        kmu_compute_args_t  compute;
    } kmu_args_t;
    typedef struct packed {
        logic                              kind;    
        logic [PC_BITS-1:0]                PC;
        logic [PC_BITS-1:0]                entry;
        logic [32-1:0] param;
        logic [7:0]                        ctx_id;
        logic [17:0]    aligned_lmem_size;
        kmu_args_t                         args;    
    } kmu_req_t;
    localparam KMU_DATAW = $bits(kmu_req_t);
    localparam KMU_KIND_COMPUTE  = 1'b0;    
    localparam KMU_KIND_FRAGMENT = 1'b1;    
    localparam KMU_KIND_BITS     = 1;
    localparam KMU_DEST_W = ((($clog2(1 * 1)) > 0) ? ($clog2(1 * 1)) : 1);
    localparam KMU_DEST_LSB_SOCKET  = 0;
    localparam KMU_DEST_LSB_CLUSTER = $clog2(1);
    localparam KMU_DEST_LSB_DEVICE  = KMU_DEST_LSB_CLUSTER + $clog2(NUM_SOCKETS);
    typedef struct packed {
        logic [NCTA_WIDTH-1:0] cta_id;
        logic [NW_WIDTH-1:0] cta_rank;
        logic [NW_WIDTH:0] cta_size;
        logic [2:0][31:0] block_idx;
        logic [2:0][CTA_TID_WIDTH:0] block_dim;
        logic [2:0][31:0] grid_dim;
        logic [PC_BITS-1:0] entry;
        logic [32-1:0] param;
        logic [32-1:0] lmem_addr;
        logic [31:0] cluster_size;
    } cta_csrs_t;
    typedef struct packed {
        logic [NW_WIDTH:0]              cta_size;
        logic [2:0][31:0]               block_idx;
        logic [2:0][CTA_TID_WIDTH:0]    block_dim;
        logic [2:0][31:0]               grid_dim;
        logic [PC_BITS-1:0]             entry;
        logic [32-1:0] param;
        logic [32-1:0] lmem_addr;
        logic [31:0]                    cluster_size;
    } cta_ctx_t;
    localparam CTA_TID_LANE_BITS = 3 * CTA_TID_WIDTH;
    localparam LANE_LAUNCH_BITS = CTA_TID_LANE_BITS;
    typedef logic [LANE_LAUNCH_BITS-1:0] cta_lane_t;
    typedef struct packed {
        logic [NW_WIDTH-1:0]                     cta_rank;
        cta_lane_t [64-1:0]     lane_launch;
    } cta_warp_t;
    localparam INST_ARGS_BITS = 3 + ALU_TYPE_BITS + 20 + 2;
    typedef struct packed {
        logic [1:0] __padding;
        logic use_PC;
        logic use_imm;
        logic is_w;
        logic [ALU_TYPE_BITS-1:0] xtype;
        logic [19:0] imm20;
    } alu_args_t;
    typedef struct packed {
        logic [1:0] __padding;
        logic use_PC;
        logic use_imm;
        logic is_rvc;
        logic [ALU_TYPE_BITS-1:0] xtype;
        logic [19:0] imm20;
    } br_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-INST_FRM_BITS-INST_FMT_BITS)-1:0] __padding;
        logic [INST_FRM_BITS-1:0] frm;
        logic [INST_FMT_BITS-1:0] fmt;
    } fpu_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-1-1-12-2-1-1-$bits(amo_op_e)-2-2)-1:0] __padding;
        logic [1:0]                 export_mask;
        logic                       amo_valid;
        logic                       amo_unsigned;
        amo_op_e                    amo_op;
        logic                       amo_aq;
        logic                       amo_rl;
        logic [1:0]                 pack;
        logic                       is_store;
        logic                       is_float;
        logic [11:0]                offset;
    } lsu_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-1-12-5)-1:0] __padding;
        logic use_imm;
        logic [12-1:0] addr;
        logic [4:0] imm5;
    } csr_args_t;
    typedef struct packed {
        logic [(INST_ARGS_BITS-3)-1:0] __padding;
        logic is_cond_neg;
        logic is_sync_bar;
        logic is_bar_arrive;
    } wctl_args_t;
    typedef struct packed {
        logic is_last_uop;     
        logic is_first_uop;    
        logic a_from_smem;     
        logic [1:0] cd_nregs;  
        logic [4:0] fmt_d;
        logic [4:0] fmt_s;
        logic [3:0] step_k;
        logic [3:0] step_n;
        logic [3:0] step_m;
    } tcu_args_t;
    typedef union packed {
        alu_args_t  alu;
        br_args_t   br;
        fpu_args_t  fpu;
        lsu_args_t  lsu;
        csr_args_t  csr;
        wctl_args_t wctl;
        tcu_args_t  tcu;
    } op_args_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]  uuid;
        logic [NW_WIDTH-1:0]    wid;
        logic [NCTA_WIDTH-1:0]  cta_id;
        logic [64-1:0] tmask;
        logic [PC_BITS-1:0]     PC;
        logic [31:0]            instr;
    } fetch_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       rd_xregs;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
    } decode_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       rd_xregs;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
        logic                       fu_lock;
        logic                       fu_unlock;
    } ibuffer_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]      uuid;
        logic [ISSUE_WIS_W-1:0]     wis;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [64-1:0]    tmask;
        logic [PC_BITS-1:0]         PC;
        logic [EX_BITS-1:0]         ex_type;
        logic [INST_OP_BITS-1:0]    op_type;
        op_args_t                   op_args;
        logic                       wb;
        logic [NUM_XREGS-1:0]       wr_xregs;
        logic [NUM_SRC_OPDS-1:0]    used_rs;
        logic [NUM_REGS_BITS-1:0]   rd;
        logic [BYTESEL_BITS-1:0]    bytesel;
        logic [NUM_REGS_BITS-1:0]   rs1;
        logic [NUM_REGS_BITS-1:0]   rs2;
        logic [NUM_REGS_BITS-1:0]   rs3;
    } scoreboard_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic [EX_BITS-1:0]                 ex_type;
        logic [INST_OP_BITS-1:0]            op_type;
        op_args_t                           op_args;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [64-1:0][32-1:0]  rs1_data;
        logic [64-1:0][32-1:0]  rs2_data;
        logic [64-1:0][32-1:0]  rs3_data;
        logic                               sop;
        logic                               eop;
    } operands_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [INST_OP_BITS-1:0]            op_type;
        op_args_t                           op_args;
        logic [64-1:0][32-1:0]  rs1_data;
        logic [64-1:0][32-1:0]  rs2_data;
        logic [64-1:0][32-1:0]  rs3_data;
        logic                               sop;
        logic                               eop;
    } dispatch_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [NW_WIDTH-1:0]                wid;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [BYTESEL_BITS-1:0]            bytesel;
        logic [64-1:0][32-1:0]  data;
        logic                               sop;
        logic                               eop;
    } commit_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [ISSUE_WIS_W-1:0]             wis;
        logic [PER_ISSUE_WARPS-1:0]         eop_wis;  
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [SIMD_IDX_W-1:0]              sid;
        logic [64-1:0]             tmask;
        logic [PC_BITS-1:0]                 PC;
        logic                               wb;
        logic [NUM_XREGS-1:0]               wr_xregs;
        logic [NUM_REGS_BITS-1:0]           rd;
        logic [64-1:0][XLENB-1:0]  byteen;
        logic [64-1:0][32-1:0]  data;
        logic                               sop;
        logic                               eop;
    } writeback_t;
    typedef struct packed {
        logic [UUID_WIDTH-1:0]              uuid;
        logic [NW_WIDTH-1:0]                wid;
        logic [NCTA_WIDTH-1:0]              cta_id;
        logic [64-1:0]            tmask;
        logic [PC_BITS-1:0]                 PC;
    } schedule_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } alu_header_t; 
    typedef struct packed { 
        alu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } alu_execute_t; 
    typedef struct packed { 
        alu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } alu_result_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } lsu_header_t; 
    typedef struct packed { 
        lsu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } lsu_execute_t; 
    typedef struct packed { 
        lsu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } lsu_result_t;
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } sfu_header_t; 
    typedef struct packed { 
        sfu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } sfu_execute_t; 
    typedef struct packed { 
        sfu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } sfu_result_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] read_misses;
        logic [PERF_CTR_BITS-1:0] write_misses;
        logic [PERF_CTR_BITS-1:0] evictions;
        logic [PERF_CTR_BITS-1:0] bank_stalls;
        logic [PERF_CTR_BITS-1:0] mshr_stalls;
        logic [PERF_CTR_BITS-1:0] mem_stalls;
        logic [PERF_CTR_BITS-1:0] crsp_stalls;
    } cache_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] bank_stalls;
        logic [PERF_CTR_BITS-1:0] crsp_stalls;
    } lmem_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] misses;
    } coalescer_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] tlb_reads;
        logic [PERF_CTR_BITS-1:0] tlb_hits;
        logic [PERF_CTR_BITS-1:0] tlb_misses;
        logic [PERF_CTR_BITS-1:0] tlb_evictions;
        logic [PERF_CTR_BITS-1:0] ptw_walks;
        logic [PERF_CTR_BITS-1:0] ptw_latency;
    } mmu_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] lmem_reads;         
        logic [PERF_CTR_BITS-1:0] tbuf_cache_hits;    
        logic [PERF_CTR_BITS-1:0] wgmma_stalls;       
        logic [PERF_CTR_BITS-1:0] wgmma_instrs;       
        logic [PERF_CTR_BITS-1:0] tbuf_stalls;          
    } tcu_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] reads;
        logic [PERF_CTR_BITS-1:0] writes;
        logic [PERF_CTR_BITS-1:0] latency;
    } mem_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] idles;
        logic [PERF_CTR_BITS-1:0] active_warps;
        logic [PERF_CTR_BITS-1:0] stalled_warps;
        logic [PERF_CTR_BITS-1:0] issued_warps;
        logic [PERF_CTR_BITS-1:0] issued_threads;
        logic [PERF_CTR_BITS-1:0] branches;
        logic [PERF_CTR_BITS-1:0] divergence;
    } sched_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] stalls;
    } fetch_perf_t;
    typedef struct packed {
        logic [PERF_CTR_BITS-1:0] ibf_stalls;
        logic [PERF_CTR_BITS-1:0] scb_stalls;
        logic [PERF_CTR_BITS-1:0] opd_stalls;
        logic [NUM_EX_UNITS-1:0][PERF_CTR_BITS-1:0] dispatch_stalls;
        logic [NUM_EX_UNITS-1:0][PERF_CTR_BITS-1:0] dispatch_instrs;
    } issue_perf_t;
    typedef struct packed {
        cache_perf_t icache;
        cache_perf_t dcache;
        cache_perf_t l2cache;
        cache_perf_t l3cache;
        lmem_perf_t  lmem;
        coalescer_perf_t coalescer;
        mem_perf_t   mem;
    } sysmem_perf_t;
    typedef struct packed {
        sched_perf_t              sched;
        fetch_perf_t              fetch;
        issue_perf_t              issue;
        tcu_perf_t                tcu;
        logic [PERF_CTR_BITS-1:0] ifetches;
        logic [PERF_CTR_BITS-1:0] loads;
        logic [PERF_CTR_BITS-1:0] stores;
        logic [PERF_CTR_BITS-1:0] ifetch_latency;
        logic [PERF_CTR_BITS-1:0] load_latency;
   } pipeline_perf_t;
    localparam LSU_WORD_SIZE        = XLENB;
    localparam LSU_ADDR_WIDTH	    = (32 - $clog2(LSU_WORD_SIZE));
    localparam LSU_MEM_BATCHES      = 1;
    localparam LSU_TAG_ID_BITS      = ($clog2(8) + $clog2(LSU_MEM_BATCHES));
    localparam LSU_TAG_WIDTH        = (UUID_WIDTH + LSU_TAG_ID_BITS);
    localparam LSU_NUM_REQS	        = 1 * 64;
    localparam LSU_QUEUE_OUT_SIZE   = (((8) > (64 / LSU_WORD_SIZE)) ? (8) : (64 / LSU_WORD_SIZE));
    localparam LMEM_TAG_WIDTH_BASE  = LSU_TAG_WIDTH + $clog2(1);
    localparam LMEM_TAG_WIDTH       = LMEM_TAG_WIDTH_BASE;
    localparam LSU_CLIENT_TAG_WIDTH = $bits(lsu_header_t) + INST_LSU_BITS
                                    + (64 * $clog2(LSU_WORD_SIZE))
                                    + (((8) > 1) ? $clog2(8) : 1) + 1;
    typedef struct packed {
        logic                                                       rw;
        logic [64-1:0]                           mask;
        logic [64-1:0][LSU_WORD_SIZE-1:0]        byteen;
        logic [64-1:0][LSU_ADDR_WIDTH-1:0]       addr;
        logic [64-1:0][MEM_ATTR_WIDTH-1:0]       attr;
        logic [64-1:0][(LSU_WORD_SIZE*8)-1:0]    data;
        logic [LSU_CLIENT_TAG_WIDTH-1:0]                            tag;
    } lsu_req_data_t;
    typedef struct packed {
        logic [64-1:0]                           mask;
        logic [64-1:0][(LSU_WORD_SIZE*8)-1:0]    data;
        logic [LSU_CLIENT_TAG_WIDTH-1:0]                            tag;
        logic                                                       sop;
        logic                                                       eop;
    } lsu_rsp_data_t;
    localparam DXA_LMEM_ATTR_W = (BAR_ADDR_W + 1);
    localparam DXA_LMEM_ENGINE_TAG_W = UUID_WIDTH + 1;
    localparam DXA_LMEM_TAG_W = DXA_LMEM_ENGINE_TAG_W + NC_BITS;
    localparam DXA_LMEM_OUT_TAG_W = DXA_LMEM_TAG_W + ((1 > 1) ? $clog2(((1 + 1 - 1) / (1))) : 0);
    localparam TCU_LMEM_ATTR_W = 1;
    localparam TCU_LMEM_BLK_TAG_W = UUID_WIDTH + 1;
    localparam TCU_LMEM_NUM_MASTERS = 1 + 1;
    localparam TCU_LMEM_TAG_W = TCU_LMEM_BLK_TAG_W + ((TCU_LMEM_NUM_MASTERS > 1) ? $clog2(((TCU_LMEM_NUM_MASTERS + 1 - 1) / (1))) : 0);
    localparam LMEM_DMA_EN         = (0 + 0) != 0;
    localparam LMEM_DMA_DATA_SIZE  = 64 * LSU_WORD_SIZE;
    localparam LMEM_DMA_ADDR_WIDTH = 17 - $clog2(64 * LSU_WORD_SIZE);
    localparam LMEM_DMA_ATTR_W     = (((DXA_LMEM_ATTR_W) > (TCU_LMEM_ATTR_W)) ? (DXA_LMEM_ATTR_W) : (TCU_LMEM_ATTR_W));
    localparam LMEM_DMA_DXA_IDX    = 0;
    localparam LMEM_DMA_TCU_IDX    = LMEM_DMA_DXA_IDX + 0;
    localparam LMEM_DMA_INPUTS     = 0 + 0;
    localparam LMEM_DMA_IN_TAG_MAX = (((DXA_LMEM_OUT_TAG_W) > (TCU_LMEM_TAG_W)) ? (DXA_LMEM_OUT_TAG_W) : (TCU_LMEM_TAG_W));
    localparam LMEM_DMA_TAG_WIDTH  = LMEM_DMA_IN_TAG_MAX + ((LMEM_DMA_INPUTS > 1) ? $clog2(((LMEM_DMA_INPUTS + 1 - 1) / (1))) : 0);
    localparam ICACHE_WORD_SIZE	    = 4;
    localparam ICACHE_ADDR_WIDTH	= (32 - $clog2(ICACHE_WORD_SIZE));
    localparam ICACHE_LINE_SIZE	    = 64;
    localparam ICACHE_TAG_ID_BITS	= NW_WIDTH;
    localparam ICACHE_FETCH_TAG_WIDTH = (UUID_WIDTH + ICACHE_TAG_ID_BITS);
    localparam ICACHE_TAG_WIDTH_BASE = (ICACHE_FETCH_TAG_WIDTH + 1);
    localparam ICACHE_TAG_WIDTH       = ICACHE_TAG_WIDTH_BASE;
    localparam ICACHE_MEM_DATA_WIDTH = (ICACHE_LINE_SIZE * 8);
    localparam ICACHE_MEM_TAG_WIDTH = 
        (
        (UUID_WIDTH + $clog2(16) + $clog2(((1 + 1 - 1) / (1)))) + (((((1) > 0) ? (1) : 1) > 1) ? $clog2((((((1) > 0) ? (1) : 1) + 1 - 1) / (1))) : 0));
    localparam DCACHE_WORD_SIZE	    = 32;
    localparam DCACHE_ADDR_WIDTH	= (32 - $clog2(DCACHE_WORD_SIZE));
    localparam DCACHE_LINE_SIZE 	= 64;
    localparam DCACHE_SECTOR_SIZE   = 64;
    localparam DCACHE_CHANNELS	    = ((((64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE) > 0) ? ((64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE) : 1);
    localparam DCACHE_NUM_REQS	    = 1 * DCACHE_CHANNELS;
    localparam DCACHE_NUM_BANKS     = 1;
    localparam L1_MEM_PORTS         = 1;
    localparam DCACHE_MERGED_REQS   = (64 * LSU_WORD_SIZE) / DCACHE_WORD_SIZE;
    localparam DCACHE_MEM_BATCHES   = ((DCACHE_MERGED_REQS + DCACHE_CHANNELS - 1) / (DCACHE_CHANNELS));
    localparam DCACHE_TAG_ID_BITS   = ($clog2(LSU_QUEUE_OUT_SIZE) + $clog2(DCACHE_MEM_BATCHES));
    localparam DCACHE_CORE_TAG_WIDTH = (UUID_WIDTH + DCACHE_TAG_ID_BITS);
    localparam DCACHE_TAG_WIDTH_BASE = (DCACHE_CORE_TAG_WIDTH + 1);
    localparam DCACHE_TAG_WIDTH       = DCACHE_TAG_WIDTH_BASE;
    localparam DCACHE_MEM_DATA_WIDTH = (DCACHE_SECTOR_SIZE * 8);
    localparam DCACHE_MEM_TAG_WIDTH = 
        (
        ((((
        (UUID_WIDTH + $clog2(16) + $clog2(((DCACHE_NUM_BANKS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))))) > (
        ($clog2(((DCACHE_NUM_REQS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))) + $clog2(DCACHE_SECTOR_SIZE / DCACHE_WORD_SIZE) + 
        (DCACHE_TAG_WIDTH + ((1 > (((1) > 0) ? (1) : 1)) ? $clog2(((1 + (((1) > 0) ? (1) : 1) - 1) / ((((1) > 0) ? (1) : 1)))) : 0))))) ? (
        (UUID_WIDTH + $clog2(16) + $clog2(((DCACHE_NUM_BANKS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))))) : (
        ($clog2(((DCACHE_NUM_REQS + L1_MEM_PORTS - 1) / (L1_MEM_PORTS))) + $clog2(DCACHE_SECTOR_SIZE / DCACHE_WORD_SIZE) + 
        (DCACHE_TAG_WIDTH + ((1 > (((1) > 0) ? (1) : 1)) ? $clog2(((1 + (((1) > 0) ? (1) : 1) - 1) / ((((1) > 0) ? (1) : 1)))) : 0))))) + 1) + (((((1) > 0) ? (1) : 1) > 1) ? $clog2((((((1) > 0) ? (1) : 1) + 1 - 1) / (1))) : 0));
    localparam DCACHE_IS_LLC        = !0 && !0;
    localparam L1_MEM_TAG_WIDTH     = (((ICACHE_MEM_TAG_WIDTH) > (DCACHE_MEM_TAG_WIDTH)) ? (ICACHE_MEM_TAG_WIDTH) : (DCACHE_MEM_TAG_WIDTH));
    localparam ICACHE_MEM_ARB_IDX   = 0;
    localparam DCACHE_MEM_ARB_IDX   = ICACHE_MEM_ARB_IDX + 1;
    localparam TCACHE_MEM_ARB_IDX   = DCACHE_MEM_ARB_IDX + 1;
    localparam RTCACHE_MEM_ARB_IDX  = TCACHE_MEM_ARB_IDX + 0;
    localparam DXA_MEM_ARB_IDX      = RTCACHE_MEM_ARB_IDX + 0;
    localparam SOCKET_MEM_ARB_REQS  = 2 + 0 + 0 + 0;
    localparam SOCKET_MEM_TAG_W1    = L1_MEM_TAG_WIDTH;
    localparam SOCKET_MEM_TAG_WIDTH = SOCKET_MEM_TAG_W1;
    localparam SOCKET_MEM_ARB_TAG_WIDTH = (SOCKET_MEM_TAG_WIDTH + $clog2(SOCKET_MEM_ARB_REQS));
    localparam L2_WORD_SIZE	        = 64;
    localparam L2_SECTOR_SIZE       = 64;
    localparam L2_SOCKET_REQS       = NUM_SOCKETS * L1_MEM_PORTS;
    localparam L2_GFX_REQS          = 0 + 0;
    localparam L2_GFX_RASTER_IDX    = L2_SOCKET_REQS;
    localparam L2_GFX_OM_IDX        = L2_GFX_RASTER_IDX + 0;
    localparam PTW_ON_L2            = ((0 != 0)
                                    && (1 == 1)
                                    && (0 != 0)
                                    && (0 == 0)) ? 1 : 0;
    localparam L2_PTW_REQS          = PTW_ON_L2;
    localparam L2_PTW_IDX           = L2_SOCKET_REQS + L2_GFX_REQS;
    localparam L2_NUM_REQS          = L2_SOCKET_REQS + L2_GFX_REQS + L2_PTW_REQS;
    localparam L2_NUM_BANKS         = 1;
    localparam L2_MEM_PORTS         = 0;
    localparam L2_TAG_WIDTH         = SOCKET_MEM_ARB_TAG_WIDTH;
    localparam L1_TLB_ID_WIDTH       = $clog2(4);
    localparam TLB_SOCKET_ID_WIDTH   = L1_TLB_ID_WIDTH + ((2 > 1) ? $clog2(((2 + 1 - 1) / (1))) : 0);
    localparam TLB_CLUSTER_ID_WIDTH  = TLB_SOCKET_ID_WIDTH + ((NUM_SOCKETS > 1) ? $clog2(((NUM_SOCKETS + 1 - 1) / (1))) : 0);
    localparam L2_TLB_SLOT_WIDTH     = $clog2(8);
    localparam TLB_DEV_ID_WIDTH      = L2_TLB_SLOT_WIDTH + ((1 > 1) ? $clog2(((1 + 1 - 1) / (1))) : 0);
    localparam L2_MEM_DATA_WIDTH	= (L2_SECTOR_SIZE * 8);
    localparam L2_MEM_TAG_WIDTH     = 
        ($clog2(((L2_NUM_REQS + L2_MEM_PORTS - 1) / (L2_MEM_PORTS))) + $clog2(L2_SECTOR_SIZE / L2_WORD_SIZE) + L2_TAG_WIDTH);
    localparam L2_IS_LLC            = 0 && !0;
    localparam L3_WORD_SIZE	        = L2_SECTOR_SIZE;
    localparam L3_SECTOR_SIZE       = 64;
    localparam L3_PTW_IDX           = 1 * L2_MEM_PORTS;
    localparam L3_NUM_REQS	        = 1 * L2_MEM_PORTS
                                    + ((0 != 0) && (PTW_ON_L2 == 0) ? 1 : 0);
    localparam L3_NUM_BANKS         = 1;
    localparam L3_MEM_PORTS         = 0;
    localparam L3_TAG_WIDTH	        = L2_MEM_TAG_WIDTH;
    localparam L3_MEM_DATA_WIDTH	= (L3_SECTOR_SIZE * 8);
    localparam L3_MEM_TAG_WIDTH     = 
        ($clog2(((L3_NUM_REQS + L3_MEM_PORTS - 1) / (L3_MEM_PORTS))) + $clog2(L3_SECTOR_SIZE / L3_WORD_SIZE) + L3_TAG_WIDTH);
    localparam L3_IS_LLC            = 0;
    localparam VX_MEM_PORTS =           L3_MEM_PORTS;
    localparam VX_MEM_BYTEEN_WIDTH =    L3_SECTOR_SIZE;
    localparam VX_MEM_ADDR_WIDTH =      (32 - $clog2(L3_SECTOR_SIZE));
    localparam VX_MEM_DATA_WIDTH =      (L3_SECTOR_SIZE * 8);
    localparam VX_MEM_TAG_WIDTH =       L3_MEM_TAG_WIDTH;
    function automatic logic [SFU_WIDTH-1:0] op_to_sfu_type(
        input logic [INST_OP_BITS-1:0] op_type
    );
        case (op_type)
            INST_SFU_CSRRW,
            INST_SFU_CSRRS,
            INST_SFU_CSRRC: op_to_sfu_type = SFU_CSRS;
            default: op_to_sfu_type = SFU_WCTL;
        endcase
    endfunction
    function automatic logic [NUM_REGS_BITS-1:0] make_reg_num(input logic [REG_TYPE_BITS-1:0] rtype, logic [RV_REGS_BITS-1:0] idx);
        return (NUM_REGS_BITS'(rtype) << RV_REGS_BITS) | NUM_REGS_BITS'(idx);
    endfunction
    function automatic logic [REG_TYPE_BITS-1:0] get_reg_type(input logic [NUM_REGS_BITS-1:0] reg_num);
        return REG_TYPE_BITS'(reg_num >> RV_REGS_BITS);
    endfunction
    function automatic logic [RV_REGS_BITS-1:0] get_reg_idx(input logic [NUM_REGS_BITS-1:0] reg_num);
        return reg_num[RV_REGS_BITS-1:0];
    endfunction
    function automatic logic [UUID_WIDTH-1:0] get_uop_uuid(input logic [UUID_WIDTH-1:0] uuid, input logic [UOP_CTR_W-1:0] uop_idx);
        logic [31:0] uuid_lo = {uop_idx[0 +: UOP_CTR_W], uuid[0 +: (32 - UOP_CTR_W)]};
        return {uuid[UUID_WIDTH-1:32], uuid_lo};
    endfunction
endpackage
package VX_tcu_pkg;
    import VX_gpu_pkg::*;
    localparam TCU_FP32_ID  = 0;
    localparam TCU_TF32_ID  = 1;
    localparam TCU_FP16_ID  = 2;
    localparam TCU_BF16_ID  = 3;
    localparam TCU_FP8_ID   = 4;
    localparam TCU_BF8_ID   = 5;
    localparam TCU_MXFP8_ID = 8;
    localparam TCU_MXBF8_ID = 9;
    localparam TCU_MXFP4_ID = 10;
    localparam TCU_NVFP4_ID = 11;
    localparam TCU_I32_ID   = 16;
    localparam TCU_I8_ID    = 17;
    localparam TCU_U8_ID    = 18;
    localparam TCU_I4_ID    = 19;
    localparam TCU_U4_ID    = 20;
    localparam TCU_FMT_WIDTH= 5;
    localparam TCU_NT = 64;
    localparam TCU_WG_NRA = 4;   
    localparam TCU_WG_NR = 32;   
    localparam TCU_NR = 8;
    localparam TCU_DK = 0;
    localparam TCU_DP = 0;
    localparam TCU_TILE_CAP = TCU_NT * TCU_NR;
    localparam TCU_LG_TILE_CAP = $clog2(TCU_TILE_CAP);
    localparam TCU_TILE_EN = TCU_LG_TILE_CAP / 2;
    localparam TCU_TILE_EM = TCU_LG_TILE_CAP - TCU_TILE_EN;
    localparam TCU_TILE_M = 1 << TCU_TILE_EM;
    localparam TCU_TILE_N = 1 << TCU_TILE_EN;
    localparam TCU_TILE_K = (TCU_DK != 0) ? TCU_DK : (TCU_DP != 0) ? TCU_DP : (TCU_TILE_CAP / ((TCU_TILE_M > TCU_TILE_N) ? TCU_TILE_M : TCU_TILE_N));
    localparam TCU_BLOCK_CAP = TCU_NT;
    localparam TCU_LG_BLOCK_CAP = $clog2(TCU_BLOCK_CAP);
    localparam TCU_BLOCK_EN = TCU_LG_BLOCK_CAP / 2;
    localparam TCU_BLOCK_EM = TCU_LG_BLOCK_CAP - TCU_BLOCK_EN;
    localparam TCU_TC_M = 1 << TCU_BLOCK_EM;
    localparam TCU_TC_N = 1 << TCU_BLOCK_EN;
    localparam TCU_TC_K = (TCU_DP != 0) ? TCU_DP : (TCU_BLOCK_CAP / ((TCU_TC_M > TCU_TC_N) ? TCU_TC_M : TCU_TC_N));
    localparam TCU_M_STEPS = TCU_TILE_M / TCU_TC_M;
    localparam TCU_N_STEPS = TCU_TILE_N / TCU_TC_N;
    localparam TCU_K_STEPS = TCU_TILE_K / TCU_TC_K;
    localparam TCU_A_BLOCK_SIZE = TCU_TC_M * TCU_TC_K;
    localparam TCU_A_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_A_BLOCK_SIZE;
    localparam TCU_B_BLOCK_SIZE = TCU_TC_K * TCU_TC_N;
    localparam TCU_B_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_B_BLOCK_SIZE;
    localparam TCU_WG_TILE_M = 2 * TCU_TC_M;
    localparam TCU_WG_TILE_K = 2 * TCU_TC_K;
    localparam TCU_WG_FEDP_K = TCU_TC_K;
    localparam TCU_WG_TILE_N = (TCU_WG_NR * TCU_NT) / TCU_WG_TILE_M;
    localparam TCU_WG_M_STEPS = TCU_WG_TILE_M / TCU_TC_M;
    localparam TCU_WG_N_STEPS = TCU_WG_TILE_N / TCU_TC_N;
    localparam TCU_WG_K_STEPS = TCU_WG_TILE_K / TCU_WG_FEDP_K;
    localparam TCU_WG_UOPS = TCU_WG_M_STEPS * TCU_WG_N_STEPS * TCU_WG_K_STEPS;
    localparam TCU_WG_A_BLOCK_SIZE = TCU_TC_M * TCU_TC_K;
    localparam TCU_WG_A_DATA_SIZE  = TCU_TC_M * TCU_WG_FEDP_K;
    localparam TCU_WG_A_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_WG_A_BLOCK_SIZE;
    localparam TCU_WG_B_BLOCK_SIZE = TCU_WG_FEDP_K * TCU_TC_N;
    localparam TCU_WG_B_SUB_BLOCKS = TCU_BLOCK_CAP / TCU_WG_B_BLOCK_SIZE;
    localparam SYM_SPARSE = 0 ? 0 : (TCU_BLOCK_EM == TCU_BLOCK_EN);
    localparam TCU_B_BLOCK_SIZE_SP    = SYM_SPARSE ? TCU_BLOCK_CAP : (TCU_TC_K * TCU_TC_N) * 2;
    localparam TCU_B_SUB_BLOCKS_SP    = TCU_BLOCK_CAP / TCU_B_BLOCK_SIZE_SP;
    localparam TCU_WG_B_BLOCK_SIZE_SP = TCU_TC_K * TCU_TC_N * 2;
    localparam TCU_WG_RS2_WIDTH_DENSE =
        (TCU_WG_B_BLOCK_SIZE > TCU_BLOCK_CAP) ? TCU_WG_B_BLOCK_SIZE : TCU_BLOCK_CAP;
    localparam TCU_WG_RS2_WIDTH = 0
        ? ((TCU_WG_B_BLOCK_SIZE_SP > TCU_WG_RS2_WIDTH_DENSE) ? TCU_WG_B_BLOCK_SIZE_SP : TCU_WG_RS2_WIDTH_DENSE)
        : TCU_WG_RS2_WIDTH_DENSE;
    localparam TCU_MIN_FMT_WIDTH = 4;  
    localparam TCU_MAX_ELT_RATIO = 32 / TCU_MIN_FMT_WIDTH;
    localparam TCU_MAX_META_ROW_WIDTH   = TCU_TC_K * 2 * TCU_MAX_ELT_RATIO;
    localparam TCU_MAX_META_BLOCK_WIDTH = TCU_NT   * 2 * TCU_MAX_ELT_RATIO;
    localparam TCU_META_PER_WARP_DEPTH = TCU_M_STEPS * (TCU_K_STEPS / 2);
    localparam TCU_META_COLS_PER_LOAD  = (TCU_BLOCK_CAP >= TCU_META_PER_WARP_DEPTH)
        ? (TCU_BLOCK_CAP / TCU_META_PER_WARP_DEPTH) : 1;
    localparam TCU_BANKS_PER_STORE = (TCU_NT < TCU_META_PER_WARP_DEPTH)
        ? TCU_NT : TCU_META_PER_WARP_DEPTH;
    localparam TCU_STORES_PER_COL = (TCU_META_PER_WARP_DEPTH + TCU_NT - 1) / TCU_NT;
    localparam TCU_NRA = (TCU_TILE_M * TCU_TILE_K) / TCU_NT;
    localparam TCU_NRB = (TCU_TILE_N * TCU_TILE_K) / TCU_NT;
    localparam TCU_NRC = (TCU_TILE_M * TCU_TILE_N) / TCU_NT;
    localparam TCU_RC    = 0;
    localparam TCU_WG_RC = TCU_RC;   
    localparam TCU_WG_RA = 24;      
    localparam TCU_RA = 10;
    localparam TCU_RB = (TCU_NRB == 4) ? 28 : 24;
    localparam TCU_UOPS = TCU_M_STEPS * TCU_N_STEPS * TCU_K_STEPS;
    localparam TCU_MAX_INPUTS = TCU_TC_K * TCU_MAX_ELT_RATIO;
    function automatic int unsigned mx_fedp_sf_count(
        input int unsigned data_bits,
        input int unsigned block_elems
    );
        automatic int unsigned sparse_ratio = 0 ? 2 : 1;
        automatic int unsigned fedp_elems = TCU_WG_FEDP_K * (32 / data_bits) * sparse_ratio;
        return (fedp_elems + block_elems - 1) / block_elems;
    endfunction
    localparam TCU_MX_SF_FP8 = mx_fedp_sf_count(8, 32);
    localparam TCU_MX_SF_MXFP4 = mx_fedp_sf_count(4, 32);
    localparam TCU_MX_SF_NVFP4 = mx_fedp_sf_count(4, 16);
    localparam TCU_MX_MAX_SF = 
((((((TCU_MX_SF_FP8) > (TCU_MX_SF_MXFP4)) ? (TCU_MX_SF_FP8) : (TCU_MX_SF_MXFP4))) > (TCU_MX_SF_NVFP4)) ? ((((TCU_MX_SF_FP8) > (TCU_MX_SF_MXFP4)) ? (TCU_MX_SF_FP8) : (TCU_MX_SF_MXFP4))) : (TCU_MX_SF_NVFP4));
        localparam TCU_EXP_BITS = 10;
    typedef struct packed {
        logic is_zero;
        logic is_sub;
        logic is_inf;
        logic is_nan;
    } fedp_class_t;
    typedef struct packed {
        logic is_inf;
        logic is_nan;
        logic sign;
    } fedp_excep_t;
    function automatic int exp_bits(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 8;
            TCU_FP16_ID: return 5;
            TCU_BF16_ID: return 8;
            TCU_FP8_ID:  return 4;
            TCU_BF8_ID:  return 5;
            TCU_TF32_ID: return 8;
            default:     return 0;
        endcase
    endfunction
    function automatic int sig_bits(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 23;
            TCU_FP16_ID: return 10;
            TCU_BF16_ID: return 7;
            TCU_FP8_ID:  return 3;
            TCU_BF8_ID:  return 2;
            TCU_TF32_ID: return 10;
            default:     return 0;
        endcase
    endfunction
    function automatic int sign_pos(input int fmt);
        case (fmt)
            TCU_FP32_ID: return 31;
            TCU_FP16_ID: return 15;
            TCU_BF16_ID: return 15;
            TCU_FP8_ID:  return 7;
            TCU_BF8_ID:  return 7;
            TCU_TF32_ID: return 18;
            default:     return 0;
        endcase
    endfunction
    function automatic int unsigned tcu_fmt_width(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_FP16_ID, TCU_BF16_ID:
                return 16;
            TCU_MXFP4_ID, TCU_NVFP4_ID, TCU_I4_ID, TCU_U4_ID:
                return 4;
            TCU_FP8_ID,
            TCU_BF8_ID,
            TCU_I8_ID,
            TCU_U8_ID,
            TCU_MXFP8_ID,
            TCU_MXBF8_ID:
                return 8;
            TCU_FP32_ID,
            TCU_I32_ID,
            TCU_TF32_ID:
                return 32;
            default:
                return 0;
        endcase
    endfunction
    function automatic logic tcu_fmt_is_int(input logic [TCU_FMT_WIDTH-1:0] fmt);
        return fmt[TCU_FMT_WIDTH-1];
    endfunction
    function automatic logic tcu_fmt_is_signed_int(input logic [TCU_FMT_WIDTH-2:0] int_fmt);
        return int_fmt[0];
    endfunction
    function automatic logic tcu_fmt_is_bfloat(input logic [TCU_FMT_WIDTH-2:0] float_fmt);
        return float_fmt[0];
    endfunction
    function automatic logic tcu_fmt_is_mx(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_MXFP8_ID, TCU_MXBF8_ID, TCU_MXFP4_ID, TCU_NVFP4_ID:
                return 1'b1;
            default:
                return 1'b0;
        endcase
    endfunction
    function automatic int unsigned mx_scale_block_size(input logic [TCU_FMT_WIDTH-1:0] fmt);
        case (fmt)
            TCU_MXFP8_ID, TCU_MXBF8_ID, TCU_MXFP4_ID: return 32;
            TCU_NVFP4_ID:                                          return 16;
            default:                                               return 1;
        endcase
    endfunction
    function automatic int unsigned mx_scale_blocks_k_words(
        input logic [TCU_FMT_WIDTH-1:0] fmt,
        input int unsigned tile_k_words
    );
        automatic int unsigned data_bits = tcu_fmt_width(fmt);
        automatic int unsigned block_elems = mx_scale_block_size(fmt);
        automatic int unsigned tile_elems = (data_bits != 0) ? tile_k_words * (32 / data_bits) : 0;
        return (tile_elems + block_elems - 1) / block_elems;
    endfunction
    function automatic int unsigned mx_scale_blocks_k(input logic [TCU_FMT_WIDTH-1:0] fmt);
        return mx_scale_blocks_k_words(fmt, TCU_TILE_K);
    endfunction
    function automatic logic [4:0] meta_num_cols(input logic [TCU_FMT_WIDTH-1:0] fmt);
        automatic int hw = tcu_fmt_width(fmt) / 2;
        return 5'((TCU_BLOCK_CAP + hw - 1) / hw);
    endfunction
    function automatic int unsigned tcu_meta_stride_words(input logic [TCU_FMT_WIDTH-1:0] fmt);
        automatic int unsigned fb   = tcu_fmt_width(fmt);
        automatic int unsigned elr  = (fb != 0) ? (32 / fb) : 1;  
        automatic int unsigned rowb = TCU_TC_K * 2 * elr;
        return (TCU_TC_M * rowb + 31) / 32;
    endfunction
    typedef struct packed { 
        logic [UUID_WIDTH-1:0]           uuid; 
        logic [NW_WIDTH-1:0]             wid; 
        logic [NCTA_WIDTH-1:0]           cta_id; 
        logic [64-1:0]            tmask; 
        logic [(((64 / 64) > 1) ? $clog2(64 / 64) : 1)-1:0] pid; 
        logic                            sop; 
        logic                            eop; 
        logic [PC_BITS-1:0]              PC; 
        logic                            wb; 
        logic [NUM_XREGS-1:0]            wr_xregs; 
        logic [NUM_REGS_BITS-1:0]        rd; 
        logic [BYTESEL_BITS-1:0]         bytesel; 
    } tcu_header_t; 
    typedef struct packed { 
        tcu_header_t              header; 
        logic [INST_OP_BITS-1:0]         op_type; 
        op_args_t                        op_args; 
        logic [64-1:0][32-1:0] rs1_data; 
        logic [64-1:0][32-1:0] rs2_data; 
        logic [64-1:0][32-1:0] rs3_data; 
    } tcu_execute_t; 
    typedef struct packed { 
        tcu_header_t              header; 
        logic [64-1:0][32-1:0] data; 
    } tcu_result_t;
    typedef struct packed {
        logic                       valid;
        logic [UUID_WIDTH-1:0]      uuid;    
        logic [NW_WIDTH-1:0]        wid;
        logic [NCTA_WIDTH-1:0]      cta_id;
        logic [3:0]                 step_m;
        logic [3:0]                 step_n;
        logic [3:0]                 step_k;
        logic [1:0]                 cd_nregs;
        logic [32-1:0]    desc_a;
        logic [32-1:0]    desc_b;
        logic                       a_is_smem;
        logic                       is_first_uop;
        logic                       is_last_uop;
        logic                       setup_fire;
    } tcu_tbuf_req_t;
endpackage
module FullAdder (
    input  wire a,
    input  wire b,
    input  wire cin,
    output wire sum,
    output wire cout
);
    assign sum = a ^ b ^ cin;
    assign cout = (a & b) | ((a ^ b) & cin);
endmodule
module VX_csa_32 #(
    parameter N = 3,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N-1:0] carry_int;
    for (genvar i = 0; i < N; i++) begin : g_compress_3_2
        FullAdder FA (
            .a    (a[i]),
            .b    (b[i]),
            .cin  (c[i]),
            .sum  (sum_int[i]),
            .cout (carry_int[i])
        );
    end
    assign sum = WIDTH_O'(sum_int);
    assign carry = WIDTH_O'({1'b0, carry_int, 1'b0});
endmodule
module counter_5to3(
    input wire x1, x2, x3, x4, cin,
    output wire sum, carry, cout
);
    wire s1 = x1 ^ x2 ^ x3;
    assign cout = (x1 & x2) | (x2 & x3) | (x1 & x3);
    assign sum = s1 ^ x4 ^ cin;
    assign carry = (s1 & x4) | (x4 & cin) | (s1 & cin);
endmodule
module VX_csa_42 #(
    parameter N = 4,
    parameter WIDTH_O = N + 2
) (
    input  wire [N-1:0] a,
    input  wire [N-1:0] b,
    input  wire [N-1:0] c,
    input  wire [N-1:0] d,
    output wire [WIDTH_O-1:0] sum,
    output wire [WIDTH_O-1:0] carry
);
    wire [N-1:0] sum_int;
    wire [N:0]   cin;
    wire [N-1:0] cout;
    wire [N-1:0] carry_int;
    assign cin[0] = 1'b0;
    for (genvar i = 0; i < N; i++) begin : g_compress_4_2
        counter_5to3 u_counter_5to3(
            .x1(a[i]),
            .x2(b[i]),
            .x3(c[i]),
            .x4(d[i]),
            .cin(cin[i]),
            .sum(sum_int[i]),
            .carry(carry_int[i]),
            .cout(cout[i])
        );
        assign cin[i+1] = cout[i];
    end
    wire [1:0] carry_temp;
    assign sum = WIDTH_O'(sum_int);
    assign carry_temp = {carry_int[N-1] & cin[N], carry_int[N-1] ^ cin[N]};
    assign carry = WIDTH_O'({carry_temp, carry_int[N-2:0], 1'b0});
endmodule
module VX_csa_block #(
    parameter N = 4,
    parameter W = 8,
    parameter S = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    ;
    function automatic integer calc_4to2_levels(integer n);
        integer remaining = n;
        integer levels_4to2 = 0;
        while (remaining >= 4) begin
            levels_4to2 = levels_4to2 + 1;
            remaining = remaining - 2;
        end
        return levels_4to2;
    endfunction
    localparam LEVELS_4TO2 = calc_4to2_levels(N);
    localparam TOTAL_LEVELS = LEVELS_4TO2 + ((N - LEVELS_4TO2 * 2) == 3 ? 1 : 0);
    localparam WN_CALC = W + TOTAL_LEVELS + 2;
    localparam WN = (WN_CALC > S) ? WN_CALC : S;
    wire [WN-1:0] St [0:TOTAL_LEVELS];
    wire [WN-1:0] Ct [0:TOTAL_LEVELS];
    assign St[0] = WN'(operands[0]);
    assign Ct[0] = WN'(operands[1]);
    for (genvar i = 0; i < LEVELS_4TO2; i++) begin : g_4to2_levels
        localparam WI = W + i;
        localparam WO = WI + 2;
        localparam OP_A_IDX = 2 + (i * 2);
        localparam OP_B_IDX = 3 + (i * 2);
        wire [WO-1:0] st, ct;
        VX_csa_42 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_42 (
            .a(WI'(St[i])),
            .b(WI'(Ct[i])),
            .c(WI'(operands[OP_A_IDX])),
            .d(WI'(operands[OP_B_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[i+1] = WN'(st);
        assign Ct[i+1] = WN'(ct);
    end
    if ((N - LEVELS_4TO2 * 2) == 3) begin : g_final_3to2
        localparam FINAL_OP_IDX = 2 + (LEVELS_4TO2 * 2);
        localparam WI = W + LEVELS_4TO2;
        localparam WO = WI + 2;
        wire [WO-1:0] st, ct;
        VX_csa_32 #(
            .N(WI),
            .WIDTH_O(WO)
        ) csa_32 (
            .a(WI'(St[LEVELS_4TO2])),
            .b(WI'(Ct[LEVELS_4TO2])),
            .c(WI'(operands[FINAL_OP_IDX])),
            .sum(st),
            .carry(ct)
        );
        assign St[LEVELS_4TO2+1] = WN'(st);
        assign Ct[LEVELS_4TO2+1] = WN'(ct);
    end
    else begin : g_no_final_3to2
        if (LEVELS_4TO2 < TOTAL_LEVELS) begin : g_pass_through
            assign St[LEVELS_4TO2+1] = St[LEVELS_4TO2];
            assign Ct[LEVELS_4TO2+1] = Ct[LEVELS_4TO2];
        end
    end
    assign sum  = St[TOTAL_LEVELS][S-1:0];
    assign carry = Ct[TOTAL_LEVELS][S-1:0];
endmodule
module VX_csa_tree #(
    parameter N   = 16,  
    parameter W   = 8,   
    parameter K   = 6,   
    parameter BAL = 1,   
    parameter S   = W + $clog2(N)
) (
    input  wire [N-1:0][W-1:0] operands,
    output wire [S-1:0]        sum,
    output wire [S-1:0]        carry
);
    localparam CLUSTER_W    = (K == 1) ? W : (W + K + 2);
    localparam NUM_CLUSTERS = (K == 1) ? N : ((N + K - 1) / K);
    localparam TOP_N        = (K == 1) ? N : (NUM_CLUSTERS * 2);
    function automatic integer next_lev_ragged(integer n_in);
        integer n_rem = n_in % 4;
        return (n_rem == 3) ? ((n_in/4)*2 + 2) : ((n_in/4)*2 + n_rem);
    endfunction
    function automatic integer next_lev_balanced(integer n_in);
        integer n_rem = n_in % 4;
        if (n_in <= 3) return (n_rem == 3) ? 2 : n_rem;
        if (n_rem == 0) return (n_in/4) * 2;
        if (n_rem == 1 || n_rem == 2) return ((n_in/4)-1)*2 + 4;
        return ((n_in/4)*2) + 2;
    endfunction
    function automatic integer get_next_sz(integer n, integer use_bal);
        return (use_bal != 0) ? next_lev_balanced(n) : next_lev_ragged(n);
    endfunction
    function automatic integer calc_depth(integer n_in);
        integer d = 0;
        integer count = n_in;
        while (count > 2) begin
            count = get_next_sz(count, BAL);
            d = d + 1;
        end
        return d;
    endfunction
    function automatic integer get_cnt_at_lev(integer l, integer start_n);
        integer c = start_n;
        for(integer k=0; k<l; k++) c = get_next_sz(c, BAL);
        return c;
    endfunction
    wire [TOP_N-1:0][CLUSTER_W-1:0] tree_inputs;
    if (K == 1) begin : g_no_cluster
        for (genvar i = 0; i < N; ++i) begin : g_map
            assign tree_inputs[i] = CLUSTER_W'(operands[i]);
        end
    end else begin : g_do_cluster
        for (genvar i = 0; i < NUM_CLUSTERS; ++i) begin : g_clusters
            localparam C_SIZE = (i == NUM_CLUSTERS - 1) ? (N - i*K) : K;
            if (C_SIZE == 1) begin : g_c1
                assign tree_inputs[2*i]     = CLUSTER_W'(operands[i*K]);
                assign tree_inputs[2*i + 1] = '0;
            end else begin : g_lin
                wire [CLUSTER_W-1:0] s_loc, c_loc;
                wire [C_SIZE-1:0][W-1:0] sub_ops;
                for(genvar j=0; j<C_SIZE; ++j) begin : g_slice
                    assign sub_ops[j] = operands[i*K + j];
                end
                VX_csa_block #(
                    .N(C_SIZE),
                    .W(W),
                    .S(CLUSTER_W)
                ) cluster_linear (
                    .operands(sub_ops),
                    .sum(s_loc),
                    .carry(c_loc)
                );
                assign tree_inputs[2*i]     = s_loc;
                assign tree_inputs[2*i + 1] = c_loc;
            end
        end
    end
    localparam DEPTH = calc_depth(TOP_N);
    localparam MAX_WN = CLUSTER_W + (DEPTH * 2) + 4;
    localparam WN = (S < MAX_WN) ? S : MAX_WN;
    wire [DEPTH:0][TOP_N-1:0][WN-1:0] tree_sig;
    for (genvar i = 0; i < TOP_N; i++) begin : g_init_l0
        assign tree_sig[0][i] = WN'(tree_inputs[i]);
    end
    for (genvar lev = 0; lev < DEPTH; lev++) begin : g_levels
        localparam integer NUM_IN = get_cnt_at_lev(lev, TOP_N);
        localparam integer WI = CLUSTER_W + (lev * 2);
        localparam integer WO = WI + 2;
        if (BAL == 1) begin : g_balanced
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            localparam integer CORE = (REM == 1 || REM == 2) ? (N_42 - 1) : N_42;
            for (genvar i = 0; i < CORE; i++) begin : g_core
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 1) begin : g_r1
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
                assign tree_sig[lev+1][OB+2] = tree_sig[lev][B+3]; assign tree_sig[lev+1][OB+3] = tree_sig[lev][B+4];
            end
            else if (REM == 2) begin : g_r2
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s1, c1, s2, c2;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cA (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s1),
                    .carry(c1)
                );
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) cB (
                    .a(WI'(tree_sig[lev][B+3])),
                    .b(WI'(tree_sig[lev][B+4])),
                    .c(WI'(tree_sig[lev][B+5])),
                    .sum(s2),
                    .carry(c2)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s1); assign tree_sig[lev+1][OB+1] = WN'(c1);
                assign tree_sig[lev+1][OB+2] = WN'(s2); assign tree_sig[lev+1][OB+3] = WN'(c2);
            end
            else if (REM == 3) begin : g_r3
                localparam B = CORE*4; localparam OB = CORE*2;
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][B])),
                    .b(WI'(tree_sig[lev][B+1])),
                    .c(WI'(tree_sig[lev][B+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][OB+0] = WN'(s); assign tree_sig[lev+1][OB+1] = WN'(c);
            end
        end
        else begin : g_ragged
            localparam integer N_42 = NUM_IN / 4;
            localparam integer REM  = NUM_IN % 4;
            for (genvar i = 0; i < N_42; i++) begin : g_csa42
                wire [WO-1:0] s, c;
                VX_csa_42 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) csa (
                    .a(WI'(tree_sig[lev][i*4+0])),
                    .b(WI'(tree_sig[lev][i*4+1])),
                    .c(WI'(tree_sig[lev][i*4+2])),
                    .d(WI'(tree_sig[lev][i*4+3])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][i*2+0] = WN'(s);
                assign tree_sig[lev+1][i*2+1] = WN'(c);
            end
            if (REM == 3) begin : g_rem3
                wire [WO-1:0] s, c;
                VX_csa_32 #(
                    .N(WI),
                    .WIDTH_O(WO)
                ) c32 (
                    .a(WI'(tree_sig[lev][N_42*4])),
                    .b(WI'(tree_sig[lev][N_42*4+1])),
                    .c(WI'(tree_sig[lev][N_42*4+2])),
                    .sum(s),
                    .carry(c)
                );
                assign tree_sig[lev+1][N_42*2] = WN'(s);
                assign tree_sig[lev+1][N_42*2+1] = WN'(c);
            end
            else begin : g_pass
                for(genvar p=0; p<REM; p++) begin : g_rem
                    assign tree_sig[lev+1][N_42*2+p] = tree_sig[lev][N_42*4+p];
                end
            end
        end
    end
    assign sum   = S'(tree_sig[DEPTH][0]);
    assign carry = (get_cnt_at_lev(DEPTH, TOP_N) > 1) ? S'(tree_sig[DEPTH][1]) : '0;
endmodule
module VX_ks_adder #(
    parameter N = 16,
    parameter BYPASS = 0
) (
    input  wire [N-1:0] dataa,
    input  wire [N-1:0] datab,
    input  wire         cin,
    output wire [N-1:0] sum,
    output wire         cout
);
    if (BYPASS) begin : g_bypass
        assign {cout, sum} = dataa + datab + N'(cin);
    end else begin : g_KS
        localparam LEVELS = $clog2(N);
        wire [LEVELS:0][N-1:0] G;
        wire [LEVELS:0][N-1:0] P;
        for (genvar i = 0; i < N; i++) begin : g_initial_gp
            assign G[0][i] = dataa[i] & datab[i];
            assign P[0][i] = dataa[i] ^ datab[i];
        end
        for (genvar k = 1; k <= LEVELS; k++) begin : g_ks_levels
            localparam STEP = 1 << (k - 1);
            for (genvar i = 0; i < N; i++) begin : g_ks_nodes
                if (i >= STEP) begin : g_compute_gp
                    assign G[k][i] = G[k-1][i] | (P[k-1][i] & G[k-1][i-STEP]);
                    assign P[k][i] = P[k-1][i] & P[k-1][i-STEP];
                end else begin : g_passthrough_gp
                    assign G[k][i] = G[k-1][i];
                    assign P[k][i] = P[k-1][i];
                end
            end
        end
        assign sum[0] = P[0][0] ^ cin;
        for (genvar i = 1; i < N; i++) begin : g_sum
            wire carry_in_i = G[LEVELS][i-1] | (P[LEVELS][i-1] & cin);
            assign sum[i] = P[0][i] ^ carry_in_i;
        end
        assign cout = G[LEVELS][N-1] | (P[LEVELS][N-1] & cin);
    end
endmodule
module VX_popcount63(
    input  wire [5:0] data_in,
    output wire [2:0] data_out
);
    reg [2:0] sum;
    always @(*) begin
        case (data_in)
         6'd0: sum=3'd0;   6'd1: sum=3'd1;   6'd2: sum=3'd1;   6'd3: sum=3'd2;
         6'd4: sum=3'd1;   6'd5: sum=3'd2;   6'd6: sum=3'd2;   6'd7: sum=3'd3;
         6'd8: sum=3'd1;   6'd9: sum=3'd2;  6'd10: sum=3'd2;  6'd11: sum=3'd3;
        6'd12: sum=3'd2;  6'd13: sum=3'd3;  6'd14: sum=3'd3;  6'd15: sum=3'd4;
        6'd16: sum=3'd1;  6'd17: sum=3'd2;  6'd18: sum=3'd2;  6'd19: sum=3'd3;
        6'd20: sum=3'd2;  6'd21: sum=3'd3;  6'd22: sum=3'd3;  6'd23: sum=3'd4;
        6'd24: sum=3'd2;  6'd25: sum=3'd3;  6'd26: sum=3'd3;  6'd27: sum=3'd4;
        6'd28: sum=3'd3;  6'd29: sum=3'd4;  6'd30: sum=3'd4;  6'd31: sum=3'd5;
        6'd32: sum=3'd1;  6'd33: sum=3'd2;  6'd34: sum=3'd2;  6'd35: sum=3'd3;
        6'd36: sum=3'd2;  6'd37: sum=3'd3;  6'd38: sum=3'd3;  6'd39: sum=3'd4;
        6'd40: sum=3'd2;  6'd41: sum=3'd3;  6'd42: sum=3'd3;  6'd43: sum=3'd4;
        6'd44: sum=3'd3;  6'd45: sum=3'd4;  6'd46: sum=3'd4;  6'd47: sum=3'd5;
        6'd48: sum=3'd2;  6'd49: sum=3'd3;  6'd50: sum=3'd3;  6'd51: sum=3'd4;
        6'd52: sum=3'd3;  6'd53: sum=3'd4;  6'd54: sum=3'd4;  6'd55: sum=3'd5;
        6'd56: sum=3'd3;  6'd57: sum=3'd4;  6'd58: sum=3'd4;  6'd59: sum=3'd5;
        6'd60: sum=3'd4;  6'd61: sum=3'd5;  6'd62: sum=3'd5;  6'd63: sum=3'd6;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_popcount32(
    input  wire [2:0] data_in,
    output wire [1:0] data_out
);
    reg [1:0] sum;
    always @(*) begin
        case (data_in)
        3'd0: sum=2'd0;   3'd1: sum=2'd1;   3'd2: sum=2'd1;   3'd3: sum=2'd2;
        3'd4: sum=2'd1;   3'd5: sum=2'd2;   3'd6: sum=2'd2;   3'd7: sum=2'd3;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_sum33(
    input  wire [2:0] data_in1,
    input  wire [2:0] data_in2,
    output wire [3:0] data_out
);
    reg [3:0] sum;
    always @(*) begin
        case ({data_in1, data_in2})
        6'd0:  sum=4'd0;   6'd1: sum=4'd1;   6'd2: sum=4'd2;   6'd3: sum=4'd3;
        6'd4:  sum=4'd4;   6'd5: sum=4'd5;   6'd6: sum=4'd6;   6'd7: sum=4'd7;
        6'd8:  sum=4'd1;   6'd9: sum=4'd2;  6'd10: sum=4'd3;  6'd11: sum=4'd4;
        6'd12: sum=4'd5;  6'd13: sum=4'd6;  6'd14: sum=4'd7;  6'd15: sum=4'd8;
        6'd16: sum=4'd2;  6'd17: sum=4'd3;  6'd18: sum=4'd4;  6'd19: sum=4'd5;
        6'd20: sum=4'd6;  6'd21: sum=4'd7;  6'd22: sum=4'd8;  6'd23: sum=4'd9;
        6'd24: sum=4'd3;  6'd25: sum=4'd4;  6'd26: sum=4'd5;  6'd27: sum=4'd6;
        6'd28: sum=4'd7;  6'd29: sum=4'd8;  6'd30: sum=4'd9;  6'd31: sum=4'd10;
        6'd32: sum=4'd4;  6'd33: sum=4'd5;  6'd34: sum=4'd6;  6'd35: sum=4'd7;
        6'd36: sum=4'd8;  6'd37: sum=4'd9;  6'd38: sum=4'd10; 6'd39: sum=4'd11;
        6'd40: sum=4'd5;  6'd41: sum=4'd6;  6'd42: sum=4'd7;  6'd43: sum=4'd8;
        6'd44: sum=4'd9;  6'd45: sum=4'd10; 6'd46: sum=4'd11; 6'd47: sum=4'd12;
        6'd48: sum=4'd6;  6'd49: sum=4'd7;  6'd50: sum=4'd8;  6'd51: sum=4'd9;
        6'd52: sum=4'd10; 6'd53: sum=4'd11; 6'd54: sum=4'd12; 6'd55: sum=4'd13;
        6'd56: sum=4'd7;  6'd57: sum=4'd8;  6'd58: sum=4'd9;  6'd59: sum=4'd10;
        6'd60: sum=4'd11; 6'd61: sum=4'd12; 6'd62: sum=4'd13; 6'd63: sum=4'd14;
        endcase
    end
    assign data_out = sum;
endmodule
module VX_popcount #(
    parameter MODEL = 1,
    parameter N     = 1,
    parameter M     = $clog2(N+1)
) (
    input  wire [N-1:0] data_in,
    output wire [M-1:0] data_out
);
    if (N == 1) begin : g_passthru
        assign data_out = data_in;
    end else if (N <= 3) begin : g_popcount3
        reg [2:0] t_in;
        wire [1:0] t_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount32 pc32(t_in, t_out);
        assign data_out = t_out[M-1:0];
    end else if (N <= 6) begin : g_popcount6
        reg [5:0] t_in;
        wire [2:0] t_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63(t_in, t_out);
        assign data_out = t_out[M-1:0];
    end else if (N <= 9) begin : g_popcount9
        reg [8:0] t_in;
        wire [4:0] t1_out;
        wire [3:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63(t_in[5:0], t1_out[2:0]);
        VX_popcount32 pc32(t_in[8:6], t1_out[4:3]);
        VX_sum33 sum33(t1_out[2:0], {1'b0, t1_out[4:3]}, t2_out);
        assign data_out = t2_out[M-1:0];
    end else if (N <= 12) begin : g_popcount12
        reg [11:0] t_in;
        wire [5:0] t1_out;
        wire [3:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63a(t_in[5:0],  t1_out[2:0]);
        VX_popcount63 pc63b(t_in[11:6], t1_out[5:3]);
        VX_sum33 sum33(t1_out[2:0], t1_out[5:3], t2_out);
        assign data_out = t2_out[M-1:0];
    end else if (N <= 18) begin : g_popcount18
        reg [17:0] t_in;
        wire [8:0] t1_out;
        wire [5:0] t2_out;
        always @(*) begin
            t_in = '0;
            t_in[N-1:0] = data_in;
        end
        VX_popcount63 pc63a(t_in[5:0],   t1_out[2:0]);
        VX_popcount63 pc63b(t_in[11:6],  t1_out[5:3]);
        VX_popcount63 pc63c(t_in[17:12], t1_out[8:6]);
        VX_popcount32 pc32a({t1_out[0], t1_out[3], t1_out[6]}, t2_out[1:0]);
        VX_popcount32 pc32b({t1_out[1], t1_out[4], t1_out[7]}, t2_out[3:2]);
        VX_popcount32 pc32c({t1_out[2], t1_out[5], t1_out[8]}, t2_out[5:4]);
        assign data_out = {2'b0,t2_out[1:0]} + {1'b0,t2_out[3:2],1'b0} + {t2_out[5:4],2'b0};
    end else if (MODEL == 1) begin : g_model1
        localparam PN = 1 << $clog2(N);
        localparam LOGPN = $clog2(PN);
        wire [M-1:0] tmp [LOGPN-1:0][PN-1:0];
        for (genvar j = 0; j < LOGPN; ++j) begin
            localparam D = j + 1;
            localparam Q = (D < LOGPN) ? (D + 1) : M;
            for (genvar i = 0; i < (1 << (LOGPN-j-1)); ++i) begin
                localparam l = i * 2;
                localparam r = i * 2 + 1;
                wire [Q-1:0] res;
                if (j == 0) begin
                    if (r < N) begin
                        assign res = data_in[l] + data_in[r];
                    end else if (l < N) begin
                        assign res = 2'(data_in[l]);
                    end else begin
                        assign res = 2'b0;
                    end
                end else begin
                    assign res = D'(tmp[j-1][l]) + D'(tmp[j-1][r]);
                end
                assign tmp[j][i] = M'(res);
            end
        end
        assign data_out = tmp[LOGPN-1][0];
    end else begin : g_model2
        reg [M-1:0] cnt_w;
        always @(*) begin
            cnt_w = '0;
            for (integer i = 0; i < N; ++i) begin
                cnt_w = cnt_w + M'(data_in[i]);
            end
        end
        assign data_out = cnt_w;
    end
endmodule
module VX_tcu_tfr_acc import VX_tcu_pkg::*; #(
    parameter  INSTANCE_ID = "",
    parameter N  = 5,
    parameter WO = 30
) (
    input  wire                 clk,
    input  wire                 valid_in,
    input  wire [31:0]          req_id,
    input  wire [N-1:0][WO-1:0] sigs_in,
    input  wire [N-1:0]         sticky_in,
    input  wire [N-1:0]         fp_negs,
    output wire [WO-1:0]        sum_out,
    output wire [WO-1:0]        sig_out,    
    output wire                 sign_out,   
    output wire                 sticky_out
);
    wire [$clog2(N+1)-1:0] fp_neg_count;
    VX_popcount #(
        .N (N)
    ) fp_neg_popcount (
        .data_in  (fp_negs),
        .data_out (fp_neg_count)
    );
    wire [N:0][WO-1:0] sig_operands;
    for (genvar i = 0; i < N; ++i) begin : g_ops
        assign sig_operands[i] = sigs_in[i];
    end
    assign sig_operands[N] = WO'(fp_neg_count);
    wire [WO-1:0] sum_vec;
    wire [WO-1:0] carry_vec;
    VX_csa_tree #(
        .N (N+1),
        .W (WO),
        .S (WO)
    ) sig_csa (
        .operands (sig_operands),
        .sum      (sum_vec),
        .carry    (carry_vec)
    );
    wire [WO-1:0] sig_pos;
    VX_ks_adder #(
        .N (WO),
        .BYPASS (0)
    ) final_adder (
        .cin   (1'b0),
        .dataa (sum_vec),
        .datab (carry_vec),
        .sum   (sig_pos),
        . cout ()
    );
    wire [WO-1:0] sig_neg_raw;
    VX_ks_adder #(
        .N (WO),
        .BYPASS (0)
    ) neg_adder (
        .cin   (1'b1),
        .dataa (~sum_vec),
        .datab (~carry_vec),
        .sum   (sig_neg_raw),
        . cout ()
    );
    wire [WO-1:0] sig_neg = sig_neg_raw + WO'(1);
    assign sign_out = sig_pos[WO-1];
    assign sum_out  = sig_pos;
    assign sig_out  = sign_out ? sig_neg : sig_pos;
    assign sticky_out = |sticky_in;
endmodule
module VX_ucc_float_to_int #(
    parameter W = 80
) (
    input  wire [31:0]           a,
    input  wire                 unsigned_result,
    input  wire [1:0]           rm,
    output wire [W-1:0]         align_data,
    output wire signed [11:0]   align_distance,
    input  wire [W-1:0]         aligned,
    input  wire                 sticky,
    output wire [1:0][W-1:0]    operands,
    output wire [1:0]           negatives,
    input  wire [W-1:0]         sum,
    output wire [31:0]          result,
    output wire [4:0]           flags
);
    wire [7:0] e = a[30:23];
    wire sign = a[31];
    wire signed [11:0] exponent = e == 0 ? -12'sd126 : 12'(e) - 12'sd127;
    assign align_data = W'({(|e), a[22:0]});
    assign align_distance = 12'sd20 - exponent;
    wire [31:0] kept = aligned[34:3];
    wire guard_bit = aligned[2];
    wire tail = (|aligned[1:0]) || sticky;
    wire inexact = guard_bit || tail;
    wire increment = (rm == 0 && guard_bit && (tail || kept[0]))
                   || (rm == 2 && sign && inexact)
                   || (rm == 3 && !sign && inexact);
    assign operands[0] = sign ? ~W'(kept) : W'(kept);
    assign operands[1] = sign ? ~W'(increment) : W'(increment);
    assign negatives = {2{sign}};
    wire nan_input = (&e) && (|a[22:0]);
    wire invalid_unsigned = exponent >= 32 || (sign && (|sum));
    wire invalid_signed = exponent > 31
                       || (exponent == 31 && (!sign || sum != W'($signed(32'h80000000))));
    wire invalid = (&e) || (unsigned_result ? invalid_unsigned : invalid_signed);
    wire [31:0] saturated = nan_input ? 32'd0
                         : unsigned_result ? (sign ? 32'd0 : 32'hffffffff)
                         : sign ? 32'h80000000 : 32'h7fffffff;
    assign result = invalid ? saturated : sum[31:0];
    assign flags = {invalid, 3'd0, (inexact && !invalid)};
endmodule
module VX_ucc_fp_compare (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [7:0]  op,
    input  wire        unsigned_less,
    output wire [31:0] result,
    output wire        predicate,
    output wire [4:0]  flags
);
    wire an = (&a[30:23]) && (|a[22:0]);
    wire bn = (&b[30:23]) && (|b[22:0]);
    wire nan_input = an || bn;
    wire zeros = a[30:0] == 0 && b[30:0] == 0;
    wire equal = a == b || zeros;
    wire less = !zeros && ((a[31] != b[31]) ? a[31]
                       : a[31] ? (!unsigned_less && a != b) : unsigned_less);
    logic compare;
    always_comb begin
        case (op[2:0])
            3'd0: compare = !nan_input && equal;
            3'd1: compare = nan_input || !equal;
            3'd2: compare = !nan_input && less;
            3'd3: compare = !nan_input && (less || equal);
            3'd4: compare = !nan_input && !(less || equal);
            3'd5: compare = !nan_input && !less;
            default: compare = !nan_input && less;
        endcase
    end
    wire minmax = op[2:1] == 3;
    wire zero_sign = op[0] ? a[31] && b[31] : a[31] || b[31];
    wire [31:0] ordered = zeros ? {zero_sign, 31'd0} : (less ^ op[0]) ? a : b;
    wire [31:0] minimum_maximum = an && bn ? 32'h7fc00000 : an ? b : bn ? a : ordered;
    assign result = minmax ? minimum_maximum : {31'd0, compare};
    assign predicate = compare;
    assign flags = {((an && !a[22]) || (bn && !b[22])), 4'd0};
endmodule
module VX_find_first #(
    parameter N       = 1,
    parameter DATAW   = 1,
    parameter REVERSE = 0  
) (
    input  wire [N-1:0][DATAW-1:0] data_in,
    input  wire [N-1:0]            valid_in,
    output wire [DATAW-1:0]        data_out,
    output wire                    valid_out
);
    localparam LOGN = $clog2(N);
    localparam TL   = (1 << LOGN) - 1;
    localparam TN   = (1 << (LOGN+1)) - 1;
    reg             valid_r;
    reg [DATAW-1:0] data_r;
    always @(*) begin : g_scan
        reg [TN-1:0]       s_n;
        reg [TN*DATAW-1:0] d_n;
        s_n = '0;
        d_n = '0;
        for (integer i = 0; i < N; ++i) begin
            s_n[TL+i] = REVERSE ? valid_in[N-1-i] : valid_in[i];
            d_n[(TL+i)*DATAW +: DATAW] = REVERSE ? data_in[N-1-i] : data_in[i];
        end
        for (integer k = TL-1; k >= 0; --k) begin
            s_n[k] = s_n[2*k+2] | s_n[2*k+1];
            d_n[k*DATAW +: DATAW] = s_n[2*k+1] ? d_n[(2*k+1)*DATAW +: DATAW] : d_n[(2*k+2)*DATAW +: DATAW];
        end
        valid_r = s_n[0];
        data_r  = d_n[0 +: DATAW];
    end
    assign valid_out = valid_r;
    assign data_out  = data_r;
endmodule
module VX_lzc #(
    parameter N       = 2,
    parameter REVERSE = 0,   
    parameter LOGN    = (((N) > 1) ? $clog2(N) : 1)
) (
    input  wire [N-1:0]    data_in,
    output wire [LOGN-1:0] data_out,
    output wire            valid_out
);
    if (N == 1) begin : g_passthru
        assign data_out  = '0;
        assign valid_out = data_in;
    end else begin : g_lzc
        wire [N-1:0][LOGN-1:0] indices;
        for (genvar i = 0; i < N; ++i) begin : g_indices
            assign indices[i] = REVERSE ? LOGN'(i) : LOGN'(N-1-i);
        end
        VX_find_first #(
            .N       (N),
            .DATAW   (LOGN),
            .REVERSE (!REVERSE)
        ) find_first (
            .valid_in  (data_in),
            .data_in   (indices),
            .data_out  (data_out),
            .valid_out (valid_out)
        );
    end
endmodule
module VX_ucc_shift_jam #(
    parameter W = 80,
    parameter SW = 10
) (
    input  wire [W-1:0]  data_in,
    input  wire [SW-1:0] amount,
    input  wire          left,
    input  wire          fill,
    output wire [W-1:0] data_out,
    output wire          sticky
);
    localparam LEVELS = $clog2(W);
    wire [LEVELS:0][W-1:0] stage;
    wire [LEVELS:0] lost;
    wire [W-1:0] shifted;
    wire over = amount >= SW'(W);
    assign lost[0] = 1'b0;
    for (genvar i = 0; i < W; ++i) begin : g_reverse
        assign stage[0][i] = left ? data_in[W-1-i] : data_in[i];
        assign shifted[i] = left ? stage[LEVELS][W-1-i] : stage[LEVELS][i];
    end
    for (genvar s = 0; s < LEVELS; ++s) begin : g_stage
        localparam D = 1 << s;
        assign stage[s+1] = amount[s] ? {{D{fill && !left}}, stage[s][W-1:D]} : stage[s];
        assign lost[s+1] = lost[s] | (amount[s] && (|stage[s][D-1:0]));
    end
    assign data_out = over ? {W{fill && !left}} : shifted;
    assign sticky = !left && (over ? (|data_in) : lost[LEVELS]);
endmodule
module VX_ucc_round #(
    parameter W = 80
) (
    input  wire [W-1:0]       magnitude,
    input  wire signed [11:0] base_exp,
    input  wire               sign,
    input  wire [1:0]         rm,
    input  wire               sticky_in,
    input  wire               dpa,
    input  wire               shift_mode,
    input  wire               shift_left,
    input  wire               shift_signed,
    input  wire [4:0]         shift_count,
    output wire [31:0]        shift_result,
    output wire [31:0]        clz_result,
    output wire [31:0]        result,
    output wire [4:0]         flags
);
    wire [$clog2(W)-1:0] lz;
    wire nonzero;
    VX_lzc #(
        .N (W)
    ) lzc (
        .data_in   (magnitude),
        .data_out  (lz),
        .valid_out (nonzero)
    );
    wire signed [11:0] exponent = base_exp + 12'(W-1) - 12'(lz);
    wire subnormal = !dpa && (exponent < -12'sd126);
    wire signed [11:0] quantum = subnormal ? -12'sd149 : exponent - 12'sd23;
    wire signed [11:0] distance = quantum - base_exp - 12'sd3;
    wire left = shift_mode ? shift_left : distance < 0;
    wire [11:0] shift_amount = shift_mode ? 12'(shift_count)
                            : left ? 12'(-distance) : 12'(distance);
    wire [W-1:0] shifted;
    wire shift_sticky;
    VX_ucc_shift_jam #(
        .W  (W),
        .SW (12)
    ) shifter (
        .data_in  (magnitude),
        .amount   (shift_amount),
        .left     (left),
        .fill     (shift_mode && shift_signed),
        .data_out (shifted),
        .sticky   (shift_sticky)
    );
    assign shift_result = shifted[31:0];
    assign clz_result = nonzero ? 32'(lz) - 32'(W-32) : 32'd32;
    wire [23:0] kept = shifted[26:3];
    wire guard_bit = shifted[2];
    wire round_bit = shifted[1];
    wire tail = shifted[0] | shift_sticky | sticky_in;
    wire inexact = guard_bit | round_bit | tail;
    wire increment = ((rm == 0) && guard_bit && (round_bit || tail || kept[0]))
                   || ((rm == 2) && sign && inexact)
                   || ((rm == 3) && !sign && inexact);
    wire [24:0] rounded = {1'b0, kept} + 25'(increment);
    wire [23:0] significand = rounded[24] ? rounded[24:1] : rounded[23:0];
    wire signed [11:0] out_exp = quantum + 12'sd150 + 12'(rounded[24]);
    wire overflow = out_exp >= 255;
    wire to_inf = (rm == 0) || ((rm == 2) && sign) || ((rm == 3) && !sign);
    wire ub_inexact = round_bit | tail;
    wire ub_increment = ((rm == 0) && round_bit && (tail || guard_bit))
                      || ((rm == 2) && sign && ub_inexact)
                      || ((rm == 3) && !sign && ub_inexact);
    wire [24:0] ub_rounded = {1'b0, kept[22:0], guard_bit} + 25'(ub_increment);
    wire tiny = (exponent < -127) || ((exponent == -127) && !ub_rounded[24]);
    wire [7:0] packed_exp = significand[23] ? 8'(out_exp) : 8'd0;
    wire [31:0] finite_result = {sign, packed_exp, significand[22:0]};
    wire [31:0] overflow_result = {sign, (to_inf ? 31'h7f800000 : 31'h7f7fffff)};
    wire flush = dpa && out_exp <= 0;
    assign result = !nonzero || flush ? {sign, 31'd0}
                  : overflow ? overflow_result : finite_result;
    assign flags = dpa || !nonzero ? 5'd0 : {2'b00, overflow, (tiny && inexact), (inexact || overflow)};
endmodule
module VX_ucc_fma_standalone #(
    parameter W = 80,
    parameter ENABLE_AUX = 0
) (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [31:0] c,
    input  wire [7:0]  op,
    input  wire [1:0]  rm,
    output wire [31:0] result,
    output wire [4:0]  flags,
    output wire        predicate
);
    wire int_to_float = ENABLE_AUX && (op == 8'h40 || op == 8'h41);
    wire float_to_int = ENABLE_AUX && (op == 8'h42 || op == 8'h43);
    wire compare_mode = ENABLE_AUX && op >= 8'h08 && op <= 8'h0f;
    wire sign_mode = ENABLE_AUX && (op == 8'h04 || op == 8'h05);
    wire [W-1:0] conversion_data, raw_sum;
    wire signed [11:0] conversion_distance;
    wire [1:0][W-1:0] conversion_operands;
    wire [1:0] conversion_negatives;
    wire [31:0] conversion_result, comparison_result;
    wire [4:0] conversion_flags, comparison_flags;
    wire comparison_predicate;
    wire [31:0] x = a;
    wire [31:0] y = op[1] ? 32'h3f800000 : b;
    wire psign = x[31] ^ y[31];
    wire [31:0] z = op[1] ? {b[31] ^ op[0], b[30:0]}
                         : op[0] ? {psign, 31'd0} : c;
    wire [7:0] ex = x[30:23], ey = y[30:23], ez = z[30:23];
    wire [23:0] mx = {(|ex), x[22:0]}, my = {(|ey), y[22:0]}, mz = {(|ez), z[22:0]};
    wire xzero = x[30:0] == 0, yzero = y[30:0] == 0, zzero = z[30:0] == 0;
    wire xnan = (&ex) && (|x[22:0]), ynan = (&ey) && (|y[22:0]), znan = (&ez) && (|z[22:0]);
    wire xinf = (&ex) && !(|x[22:0]), yinf = (&ey) && !(|y[22:0]), zinf = (&ez) && !(|z[22:0]);
    wire snan = (xnan && !x[22]) || (ynan && !y[22]) || (znan && !z[22]);
    wire bad_product = (xinf && yzero) || (yinf && xzero);
    wire pinf = (xinf || yinf) && !(xnan || ynan || bad_product);
    wire bad_sum = pinf && zinf && (psign != z[31]);
    wire invalid = snan || bad_product || bad_sum;
    wire nan_result = xnan || ynan || znan || invalid;
    wire special = nan_result || pinf || zinf;
    wire [31:0] special_result = nan_result ? 32'h7fc00000
                          : {pinf ? psign : z[31], 8'hff, 23'd0};
    wire [4:0] special_flags = {invalid, 4'd0};
    wire pzero = xzero || yzero;
    wire zero_sign = pzero && zzero && (psign == z[31]) ? psign : rm == 2;
    wire signed [11:0] xe = (ex == 0) ? -12'sd149 : 12'({1'b0, ex}) - 12'sd150;
    wire signed [11:0] ye = (ey == 0) ? -12'sd149 : 12'({1'b0, ey}) - 12'sd150;
    wire signed [11:0] ze = (ez == 0) ? -12'sd149 : 12'({1'b0, ez}) - 12'sd150;
    wire signed [11:0] pe = xe + ye;
    wire signed [11:0] ptop = pzero ? -12'sd1024 : pe + 12'sd47;
    wire signed [11:0] ctop = zzero ? -12'sd1024 : ze + 12'sd23;
    wire signed [11:0] base_exp = ((ptop > ctop) ? ptop : ctop) - 12'(W-3);
    wire [47:0] product = mx * my;
    wire [1:0][W-1:0] aligned, operands;
    wire [1:0] negative_terms, align_sticky;
    for (genvar i = 0; i < 2; ++i) begin : g_align
        wire signed [11:0] distance = i == 1 && float_to_int ? conversion_distance : base_exp - (i == 0 ? pe : ze);
        wire left = distance < 0;
        wire [11:0] amount = left ? 12'(-distance) : 12'(distance);
        VX_ucc_shift_jam #(
            .W  (W),
            .SW (12)
        ) shifter (
            .data_in  (i == 0 ? W'(product) : float_to_int ? conversion_data : W'(mz)),
            .amount   (amount),
            .left     (left),
            .fill     (1'b0),
            .data_out (aligned[i]),
            .sticky   (align_sticky[i])
        );
        wire [W-1:0] jammed = aligned[i] | W'(align_sticky[i]);
        wire fma_negative = i == 0 ? psign : z[31];
        assign negative_terms[i] = float_to_int ? conversion_negatives[i]
                                  : int_to_float ? 1'b0 : compare_mode ? (i == 1) : fma_negative;
        assign operands[i] = float_to_int ? conversion_operands[i]
                           : int_to_float ? (i == 0 ? (op[0] ? W'(a) : W'($signed(a))) : '0)
                           : compare_mode ? (i == 0 ? W'(a) : ~W'(b))
                           : fma_negative ? ~jammed : jammed;
    end
    if (ENABLE_AUX) begin : g_auxiliary
        VX_ucc_float_to_int #(.W (W)) convert (
            .a (a), .unsigned_result (op[0]), .rm (rm),
            .align_data (conversion_data), .align_distance (conversion_distance),
            .aligned (aligned[1]), .sticky (align_sticky[1]),
            .operands (conversion_operands), .negatives (conversion_negatives),
            .sum (raw_sum), .result (conversion_result), .flags (conversion_flags)
        );
        VX_ucc_fp_compare compare (
            .a (a), .b (b), .op (op), .unsigned_less (raw_sum[32]),
            .result (comparison_result), .predicate (comparison_predicate), .flags (comparison_flags)
        );
    end else begin : g_no_auxiliary
        assign conversion_data = '0;
        assign conversion_distance = '0;
        assign conversion_operands = '0;
        assign conversion_negatives = '0;
        assign conversion_result = '0;
        assign conversion_flags = '0;
        assign comparison_result = '0;
        assign comparison_predicate = 1'b0;
        assign comparison_flags = '0;
    end
    wire [W-1:0] magnitude;
    wire sign;
    VX_tcu_tfr_acc #(
        .N  (2),
        .WO (W)
    ) accumulator (
        .clk        (1'b0),
        .valid_in   (1'b0),
        .req_id     (32'd0),
        .sigs_in    (operands),
        .sticky_in  (2'd0),
        .fp_negs    (negative_terms),
        .sum_out    (raw_sum),
        .sig_out    (magnitude),
        .sign_out   (sign),
        .sticky_out ()
    );
    wire [31:0] finite_result;
    wire [4:0] finite_flags;
    VX_ucc_round #(
        .W (W)
    ) rounder (
        .magnitude   (magnitude),
        .base_exp    (int_to_float ? 12'sd0 : base_exp),
        .sign        (int_to_float || (|magnitude) ? sign : zero_sign),
        .rm          (rm),
        .sticky_in   (1'b0),
        .dpa         (1'b0),
        .shift_mode  (1'b0),
        .shift_left  (1'b0),
        .shift_signed (1'b0),
        .shift_count (5'd0),
        .shift_result (),
        .clz_result  (),
        .result      (finite_result),
        .flags       (finite_flags)
    );
    assign result = sign_mode ? {op[0] ? 1'b0 : !a[31], a[30:0]}
                  : compare_mode ? comparison_result
                  : float_to_int ? conversion_result
                  : int_to_float ? finite_result : special ? special_result : finite_result;
    assign flags = sign_mode ? 5'd0 : compare_mode ? comparison_flags
                 : float_to_int ? conversion_flags
                 : int_to_float ? finite_flags : special ? special_flags : finite_flags;
    assign predicate = compare_mode && comparison_predicate;
endmodule
module VX_ucc_fpu_standalone #(
    parameter W = 80
) (
    input  wire [31:0] a,
    input  wire [31:0] b,
    input  wire [31:0] c,
    input  wire [7:0]  op,
    input  wire [1:0]  rm,
    output wire [31:0] result,
    output wire [4:0]  flags,
    output wire        predicate
);
    VX_ucc_fma_standalone #(.W (W), .ENABLE_AUX (1)) core (
        .a (a), .b (b), .c (c), .op (op), .rm (rm),
        .result (result), .flags (flags), .predicate (predicate)
    );
endmodule
